import React, { Suspense } from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
// import { i18nPromise } from './i18n'; // <-- This was the error, it's now removed.
import Preloader from './components/Preloader';

const fallback = <Preloader />;

const root = ReactDOM.createRoot(document.getElementById("root"));

// The I18nextProvider is now in App.jsx to ensure correct context nesting.
// This file becomes simpler, only concerned with rendering the App.
root.render(
  <>
    <Suspense fallback={fallback}>
      <App />
    </Suspense>
  </>
);