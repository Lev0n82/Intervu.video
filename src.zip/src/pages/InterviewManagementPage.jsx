import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Briefcase, PlusCircle, Edit, Trash2, Eye, Loader2, BellRing } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const demoInterviews = [
    { id: 'demo-int-1', title: 'Senior Frontend Developer', status: 'completed', created_at: new Date(Date.now() - 86400000 * 3).toISOString(), interview_templates: { name: 'Frontend Dev Template' }, interview_submissions: [{ candidate_name: 'Jane Doe', candidate_email: 'jane.doe@example.com' }] },
    { id: 'demo-int-2', title: 'UX/UI Designer', status: 'in_progress', created_at: new Date(Date.now() - 86400000).toISOString(), interview_templates: { name: 'Design Role Template' }, interview_submissions: [{ candidate_name: 'John Smith', candidate_email: 'john.smith@example.com' }] },
    { id: 'demo-int-3', title: 'Product Manager', status: 'draft', created_at: new Date().toISOString(), interview_templates: { name: 'PM Template' }, interview_submissions: [] },
];

const InterviewManagementPage = () => {
  const { activeOrganization, loading: authLoading } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchInterviews = useCallback(async () => {
    if (isDemo) {
        setInterviews(demoInterviews);
        setLoading(false);
        return;
    }
    if (!activeOrganization?.id) {
        setLoading(false);
        return;
    }
    setLoading(true);

    // With RLS in place, we no longer need to manually filter by organization_id.
    // The database handles security automatically.
    const { data, error } = await supabase
      .from('interviews')
      .select(`
        id,
        title,
        status,
        created_at,
        interview_templates (name),
        interview_submissions ( candidate_name, candidate_email )
      `)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Error fetching interviews', description: error.message, variant: 'destructive' });
    } else {
      setInterviews(data || []);
    }
    setLoading(false);
  }, [activeOrganization, toast, isDemo]);

  useEffect(() => {
    if (!authLoading) {
      fetchInterviews();
    }
  }, [authLoading, fetchInterviews]);

  // REAL-TIME SUBSCRIPTION!
  useEffect(() => {
    if (isDemo || !activeOrganization?.id) return;

    const channel = supabase.channel(`interviews-org-${activeOrganization.id}`)
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'interviews', 
          filter: `organization_id=eq.${activeOrganization.id}`
        }, 
        (payload) => {
          console.log('Realtime update received!', payload);
          toast({
            title: <div className="flex items-center"><BellRing className="w-4 h-4 mr-2"/>Real-time Update</div>,
            description: `Interview status has been updated. Refreshing list.`,
          });
          // A simple and effective way to get the latest data.
          // For more complex scenarios, we could update the state directly.
          fetchInterviews();
        }
      )
      .subscribe();

    // Cleanup function to remove the subscription
    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeOrganization, isDemo, fetchInterviews, toast]);
  
  const showNotImplementedToast = (feature) => {
    if (promptSave()) return;
    toast({
      title: '🚧 Feature Not Implemented',
      description: `${feature} isn't available yet, but you can request it in a future prompt!`,
    });
  };

  const getStatusVariant = (status) => {
    switch (status) {
        case 'completed': return 'success';
        case 'in_progress': return 'info';
        case 'draft': return 'secondary';
        case 'pending': return 'default';
        default: return 'outline';
    }
  };

  const getCreatePath = (path) => isDemo ? `/demo${path}` : path;
  
  const EmptyState = () => (
     <TableRow>
        <TableCell colSpan={5} className="py-20 text-center">
            <div className="flex flex-col items-center gap-4">
                 <Briefcase className="w-16 h-16 text-muted-foreground" />
                 <h3 className="text-xl font-semibold">No interviews yet</h3>
                 <p className="text-muted-foreground">Get started by creating your first interview.</p>
                 <Button onClick={() => navigate(getCreatePath('/interviews/new'))}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Create Interview
                 </Button>
            </div>
        </TableCell>
    </TableRow>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6"
    >
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <CardTitle className="text-primary flex items-center text-2xl">
              <Briefcase className="mr-3 h-6 w-6" aria-hidden="true" /> Manage Interviews
            </CardTitle>
            <CardDescription className="mt-1">
              View, track, and manage all interviews for your organization. Updates happen in real-time!
            </CardDescription>
          </div>
          <Button onClick={() => navigate(getCreatePath('/interviews/new'))} className="mt-3 sm:mt-0">
            <PlusCircle className="mr-2 h-4 w-4" aria-hidden="true" /> Create Interview
          </Button>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Interview Title</TableHead>
                  <TableHead>Candidate</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading || authLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-10"><div role="status" className="flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin mr-2 text-primary" aria-hidden="true" />Loading interviews...</div></TableCell></TableRow>
                ) : interviews.length > 0 ? (
                  interviews.map(interview => {
                    const submission = Array.isArray(interview.interview_submissions) ? interview.interview_submissions[0] : interview.interview_submissions;
                    const candidateInfo = submission ? `${submission.candidate_name} (${submission.candidate_email})` : 'Not Assigned';
                    return (
                      <TableRow key={interview.id}>
                        <TableCell className="font-medium text-foreground">{interview.title || interview.interview_templates?.name || 'Untitled'}</TableCell>
                        <TableCell>{candidateInfo}</TableCell>
                        <TableCell>
                           <Badge variant={getStatusVariant(interview.status)}>
                            {interview.status ? (interview.status.charAt(0).toUpperCase() + interview.status.slice(1).replace('_', ' ')) : 'Unknown'}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(interview.created_at).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right space-x-1">
                           <Button variant="ghost" size="icon" onClick={() => showNotImplementedToast('Viewing submissions')} aria-label={`View submission for ${interview.title}`}>
                            <Eye className="h-4 w-4 text-muted-foreground hover:text-primary" aria-hidden="true" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => showNotImplementedToast('Editing interviews')} aria-label={`Edit interview ${interview.title}`}>
                            <Edit className="h-4 w-4 text-muted-foreground hover:text-primary" aria-hidden="true" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => showNotImplementedToast('Deleting interviews')} aria-label={`Delete interview ${interview.title}`}>
                            <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" aria-hidden="true" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })
                ) : (
                  <EmptyState />
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default InterviewManagementPage;