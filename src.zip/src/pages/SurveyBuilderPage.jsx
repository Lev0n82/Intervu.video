import React, { useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PlusCircle, Save, ClipboardCheck, Loader2, FileUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import SurveyQuestionBuilder from '@/components/SurveyQuestionBuilder';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import TemplateSelector from '@/components/TemplateSelector';
import { commonTextSurveyTemplates } from '@/lib/predefinedTemplates';

const SurveyBuilderPage = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([{ id: Date.now(), text: '', type: 'text', options: [], isRequired: true }]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeSubmitType, setActiveSubmitType] = useState(null);
  
  const { activeOrganization, user } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: Date.now(), text: '', type: 'text', options: [], isRequired: true }]);
  };

  const handleQuestionChange = (id, field, value) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, [field]: value } : q));
  };

  const handleRemoveQuestion = (id) => {
    if (questions.length <= 1) {
      toast({ title: "Minimum Questions", description: "A survey must have at least one question.", variant: "destructive" });
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
  };

  const handleSelectTemplate = (template) => {
    const { title, description, questions } = template.data;
    setTitle(title);
    setDescription(description);
    setQuestions(questions.map(q => ({...q, id: `temp-${Date.now()}-${Math.random()}`})));
    toast({ title: "Template Applied!", description: `The "${template.name}" template has been loaded.` });
  };

  const handleSave = async (submitType) => {
    if (promptSave()) return;

    setActiveSubmitType(submitType);
    setIsSubmitting(true);

    if (!activeOrganization?.id || !user?.id) {
      toast({ title: 'Error', description: 'Active organization or user not found.', variant: 'destructive' });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }

    if (!title.trim()) {
      toast({ title: 'Validation Error', description: 'Survey title is required.', variant: 'destructive' });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }
    
    // Strict validation for question text to prevent DB errors
    // The 'question_text' column is NOT NULL in the database, so we must validate it exists
    const invalidQuestionIndex = questions.findIndex(q => !q.text || !q.text.trim());
    if (invalidQuestionIndex !== -1) {
      toast({ 
        title: 'Validation Error', 
        description: `Question ${invalidQuestionIndex + 1} cannot be empty. Please add text to all questions before saving.`, 
        variant: 'destructive' 
      });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }

    try {
        const { data: surveyData, error: surveyError } = await supabase
          .from('surveys')
          .insert({
            title,
            description,
            organization_id: activeOrganization.id,
            created_by: user.id,
            survey_type: 'text',
            allow_resubmission: false,
            status: submitType === 'activate' ? 'active' : 'draft',
          })
          .select()
          .single();

        if (surveyError) throw surveyError;

        const surveyId = surveyData.id;
        const questionInserts = questions.map((q, index) => ({
          survey_id: surveyId,
          question_text: q.text.trim(), // Ensure trimmed text is sent
          question_type: q.type,
          options: ['multiple-choice', 'likert', 'yes-no'].includes(q.type) && q.options.length > 0 ? { options: q.options.filter(Boolean) } : null,
          sequence_order: index + 1,
          is_required: q.isRequired,
        }));

        const { error: questionsError } = await supabase.from('survey_questions').insert(questionInserts);

        if (questionsError) {
          // Attempt cleanup if question insertion fails
          await supabase.from('surveys').delete().eq('id', surveyId); 
          throw questionsError;
        }

        toast({ title: submitType === 'activate' ? 'Survey Activated!' : 'Draft Saved!', description: 'Your survey has been saved.', className: 'bg-green-500 text-white' });
        navigate(isDemo ? '/demo/surveys' : '/surveys');
    } catch (error) {
        console.error('Survey Save Error:', error);
        toast({ title: 'Error Saving Survey', description: error.message, variant: 'destructive' });
    } finally {
        setIsSubmitting(false);
        setActiveSubmitType(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8"
    >
      <TemplateSelector templates={commonTextSurveyTemplates} onSelectTemplate={handleSelectTemplate} />

      <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-primary text-2xl">
              <ClipboardCheck className="w-6 h-6 mr-3" aria-hidden="true"/>
              Text Survey Builder
            </CardTitle>
            <CardDescription>Create a custom survey from scratch or customize a selected template.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="surveyTitle">Survey Title</Label>
              <Input
                id="surveyTitle"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Post-Interview Candidate Feedback"
                required
                className="mt-1"
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="surveyDescription">Description (Optional)</Label>
              <Textarea
                id="surveyDescription"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A brief description of the survey's purpose."
                className="mt-1 min-h-[80px]"
                disabled={isSubmitting}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Survey Questions</CardTitle>
                <CardDescription>Build the questions for your survey below.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {questions.map((q, index) => (
                    <SurveyQuestionBuilder
                      key={q.id}
                      question={q}
                      index={index}
                      onQuestionChange={handleQuestionChange}
                      onRemoveQuestion={handleRemoveQuestion}
                      disabled={isSubmitting}
                    />
                  ))}
                  <Button type="button" variant="outline" onClick={handleAddQuestion} className="w-full border-dashed" disabled={isSubmitting}>
                    <PlusCircle className="w-5 h-5 mr-2" aria-hidden="true" /> Add Question
                  </Button>
            </CardContent>
        </Card>

        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" onClick={() => navigate(isDemo ? '/demo/surveys' : '/surveys')} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="button" variant="secondary" onClick={() => handleSave('draft')} disabled={isSubmitting}>
            {isSubmitting && activeSubmitType === 'draft' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
            Save as Draft
          </Button>
          <Button type="button" onClick={() => handleSave('activate')} disabled={isSubmitting}>
            {isSubmitting && activeSubmitType === 'activate' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <FileUp className="w-5 h-5 mr-2" />}
            Save & Activate
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default SurveyBuilderPage;