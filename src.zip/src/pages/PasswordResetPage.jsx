import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Lock, Eye, EyeOff, KeyRound, Loader2, ArrowLeft } from 'lucide-react';

const PasswordResetPage = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [hasValidToken, setHasValidToken] = useState(false);
  const [isCheckingToken, setIsCheckingToken] = useState(true);

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (event === 'PASSWORD_RECOVERY') {
          if (session?.user) {
            setHasValidToken(true);
            toast({
              title: 'Ready to Reset',
              description: 'Please enter your new password.',
            });
          } else {
            handleInvalidToken('Failed to establish a recovery session.');
          }
          setIsCheckingToken(false);
          // Clean the URL
          navigate(location.pathname, { replace: true });
        }
      }
    );
    
    // Fallback check in case the event doesn't fire as expected
    const timer = setTimeout(() => {
        if(isCheckingToken) {
             const hash = location.hash;
             if (!hash.includes('access_token')) {
                handleInvalidToken("No recovery token found. The link may be invalid or expired.");
             }
             // If token exists, we let the onAuthStateChange handle it.
             // If it fails after a few seconds, we show an error.
             setTimeout(() => {
                if(isCheckingToken) setIsCheckingToken(false);
             }, 3000);
        }
    }, 1000);


    return () => {
      authListener?.subscription?.unsubscribe();
      clearTimeout(timer);
    };
  }, [navigate, location.pathname, isCheckingToken]);

  const handleInvalidToken = (message) => {
    setHasValidToken(false);
    setIsCheckingToken(false);
    toast({
      title: 'Invalid or Expired Link',
      description: message || 'The password reset link is invalid or has expired. Please request a new one.',
      variant: 'destructive',
      duration: 7000,
    });
    navigate('/forgot-password', { replace: true });
  };


  const handlePasswordReset = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (password.length < 6) {
      toast({
        title: 'Password Too Short',
        description: 'Password must be at least 6 characters long.',
        variant: 'destructive',
      });
      setIsLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: 'Passwords Do Not Match',
        description: 'Please ensure both password fields are identical.',
        variant: 'destructive',
      });
      setIsLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;

      toast({
        title: 'Password Reset Successful! 🎉',
        description: 'Your password has been updated. You can now log in.',
      });
      
      await supabase.auth.signOut();
      navigate('/auth', { replace: true, state: { message: 'Password successfully reset. Please log in.'} });

    } catch (error) {
      console.error('Password reset error:', error);
      toast({
        title: 'Password Reset Failed 🙁',
        description: error.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const pageVariants = {
    initial: { opacity: 0, scale: 0.95 },
    in: { opacity: 1, scale: 1 },
    out: { opacity: 0, scale: 0.95 },
  };

  if (isCheckingToken) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-transparent p-4 text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-lg">Verifying reset link...</p>
      </div>
    );
  }
  
  if (!hasValidToken) {
     return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-transparent p-4">
        <motion.div variants={pageVariants} initial="initial" animate="in" className="w-full max-w-md text-center">
          <div className="bg-card/80 backdrop-blur-sm p-8 rounded-xl shadow-2xl border border-border/20">
            <h1 className="text-2xl font-bold text-destructive">Invalid Link</h1>
            <p className="text-muted-foreground mt-2 mb-6">This link has expired or is invalid. Please request a new one.</p>
            <Button asChild><Link to="/forgot-password">Request New Link</Link></Button>
          </div>
        </motion.div>
      </div>
    );
  }


  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-transparent p-4">
      <motion.div variants={pageVariants} initial="initial" animate="in" className="w-full max-w-md">
        <div className="bg-card/80 backdrop-blur-sm p-8 rounded-xl shadow-2xl border border-border/20">
          <div className="text-center mb-8">
            <div className="inline-block p-3 bg-primary rounded-full shadow-lg mb-4">
              <KeyRound className="w-10 h-10 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground">Reset Your Password</h1>
            <p className="text-muted-foreground mt-2">Enter your new password below. Make sure it's secure!</p>
          </div>

          <form onSubmit={handlePasswordReset} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input id="new-password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="pl-10 pr-10" disabled={isLoading} />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2" disabled={isLoading}>{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm New Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input id="confirm-password" type={showConfirmPassword ? 'text' : 'password'} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={6} className="pl-10 pr-10" disabled={isLoading} />
                <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-3 top-1/2 -translate-y-1/2" disabled={isLoading}>{showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Set New Password
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default PasswordResetPage;