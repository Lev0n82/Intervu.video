import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import { User, Building, Palette, Globe, Save, Loader2, Bot, Phone } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

const SettingsPage = () => {
  const { user, userProfile, activeOrganization, refreshUserProfile } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const { i18n } = useTranslation();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [orgName, setOrgName] = useState('');
  const [storageProvider, setStorageProvider] = useState('');
  
  const [isUserSaving, setIsUserSaving] = useState(false);
  const [isOrgSaving, setIsOrgSaving] = useState(false);

  // Load data from profile into state when profile is available
  useEffect(() => {
    if (userProfile) {
      setFullName(userProfile.full_name || '');
      setPhoneNumber(userProfile.phone_number || '');
      setAvatarUrl(userProfile.avatar_url || '');
    }
    if (activeOrganization) {
      setOrgName(activeOrganization.name || '');
      // Placeholder for reading org settings if available in the future
    }
  }, [userProfile, activeOrganization]);

  const handleUserSave = async (e) => {
    e.preventDefault();
    setIsUserSaving(true);

    // Basic validation for phone number if provided
    if (phoneNumber && phoneNumber.length < 7) {
        toast({
            title: "Invalid Phone Number",
            description: "Please enter a valid phone number.",
            variant: "destructive"
        });
        setIsUserSaving(false);
        return;
    }

    try {
        const { data, error } = await supabase.rpc('update_user_settings', {
          user_id_input: user.id,
          full_name_input: fullName,
          phone_number_input: phoneNumber,
          avatar_url_input: avatarUrl,
          preferred_theme_input: theme,
          preferred_language_input: i18n.language,
        });

        if (error) throw error;

        if (!data || !data.success) {
            throw new Error(data?.message || "Failed to update settings.");
        }

        toast({ 
            title: 'User Settings Saved!', 
            description: 'Your profile has been successfully updated.',
            className: "bg-green-600 text-white" 
        });
        
        // Refresh the global context so other components reflect changes immediately
        await refreshUserProfile();

    } catch (error) {
        console.error("Error updating user settings:", error);
        toast({ 
            title: 'Error saving user settings', 
            description: error.message || "An unexpected error occurred.", 
            variant: 'destructive' 
        });
    } finally {
        setIsUserSaving(false);
    }
  };

  const handleOrgSave = async (e) => {
    e.preventDefault();
    setIsOrgSaving(true);
    
    try {
        const { data, error } = await supabase.rpc('update_organization_settings', {
          organization_id_input: activeOrganization.id,
          organization_name_input: orgName,
          storage_provider_input: storageProvider,
        });

        if (error) throw error;

        toast({ 
            title: 'Organization Settings Saved!', 
            description: 'Your organization details have been updated.',
            className: "bg-green-600 text-white"
        });
        
        await refreshUserProfile();
    } catch (error) {
        console.error("Error updating org settings:", error);
        toast({ 
            title: 'Error saving organization settings', 
            description: error.message, 
            variant: 'destructive' 
        });
    } finally {
        setIsOrgSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 max-w-4xl mx-auto p-4 md:p-0"
    >
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold text-primary">Settings</h1>
        <p className="text-muted-foreground">Manage your account preferences and organization details.</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><User className="mr-2 h-5 w-5 text-primary" /> User Profile</CardTitle>
          <CardDescription>Manage your personal information and preferences.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUserSave} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input 
                    id="fullName" 
                    placeholder="e.g. Jane Doe"
                    value={fullName} 
                    onChange={(e) => setFullName(e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <div className="relative">
                    <Phone className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                        id="phoneNumber" 
                        type="tel" 
                        className="pl-8"
                        placeholder="+1 (555) 000-0000"
                        value={phoneNumber} 
                        onChange={(e) => setPhoneNumber(e.target.value)} 
                    />
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="avatarUrl">Avatar URL</Label>
              <Input 
                id="avatarUrl" 
                type="url" 
                placeholder="https://example.com/avatar.png"
                value={avatarUrl} 
                onChange={(e) => setAvatarUrl(e.target.value)} 
              />
              <p className="text-xs text-muted-foreground">Link to a public image file to use as your profile picture.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="theme" className="flex items-center"><Palette className="mr-2 h-4 w-4" /> Theme</Label>
                <Select value={theme} onValueChange={setTheme}>
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light Mode</SelectItem>
                    <SelectItem value="dark">Dark Mode</SelectItem>
                    <SelectItem value="system">System Default</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="language" className="flex items-center"><Globe className="mr-2 h-4 w-4" /> Language</Label>
                <Select value={i18n.language} onValueChange={(lang) => i18n.changeLanguage(lang)}>
                  <SelectTrigger id="language">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="fr">Français</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={isUserSaving}>
                {isUserSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Changes
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {activeOrganization && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center"><Building className="mr-2 h-5 w-5 text-primary" /> Organization</CardTitle>
            <CardDescription>Manage your organization's settings.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleOrgSave} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="orgName">Organization Name</Label>
                <Input 
                    id="orgName" 
                    value={orgName} 
                    onChange={(e) => setOrgName(e.target.value)} 
                />
              </div>
              
              <div className="flex flex-col sm:flex-row sm:justify-between items-start sm:items-center gap-4 pt-2">
                <Button type="button" variant="outline" onClick={() => navigate('/personas')}>
                    <Bot className="mr-2 h-4 w-4" /> Manage AI Personas
                </Button>

                <Button type="submit" disabled={isOrgSaving}>
                  {isOrgSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Save Organization
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
};

export default SettingsPage;