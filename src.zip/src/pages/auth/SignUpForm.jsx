import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, User, Loader2, Building, Briefcase, Users } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import GoogleIcon from '@/components/icons/GoogleIcon';
import { Card } from '@/components/ui/card';

const SignUpForm = ({ onSignUpSuccess }) => {
  const { signUpAndOnboard, signInWithGoogle } = useAuth();
  const { toast } = useToast();
  
  const [step, setStep] = useState(1);
  const [userType, setUserType] = useState(null);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [organizationName, setOrganizationName] = useState('');
  const [department, setDepartment] = useState('');
  
  const [showPassword, setShowPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleUserTypeSelect = (type) => {
    setUserType(type);
    setStep(2);
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    if (!agreedToTerms) {
      toast({ variant: "destructive", title: "Terms Required", description: "Please agree to the terms and conditions." });
      return;
    }

    if (!email || !password || !fullName || (userType === 'Hiring' && !organizationName)) {
        toast({ variant: "destructive", title: "Missing Information", description: "Please fill out all required fields." });
        return;
    }

    setIsLoading(true);
    
    // We intentionally do NOT use try/catch here because signUpAndOnboard handles its own errors
    // and returns { user, error }.
    const { user, error } = await signUpAndOnboard(email, password, fullName, userType, organizationName, department);
    
    if (user && !error) {
      toast({ title: "Account Created!", description: "Please check your email to verify your account." });
      onSignUpSuccess();
    }
    // If error exists, it's already toasted in context, we just stop loading.
    setIsLoading(false);
  };
  
  const handleGoogleSignIn = async () => {
    const signUpData = {
      userType,
      fullName,
      organizationName,
      department,
    };
    await signInWithGoogle(signUpData);
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 10, height: 0, pointerEvents: "none" },
    visible: { opacity: 1, y: 0, height: 'auto', pointerEvents: "auto", transition: { duration: 0.3 } },
    exit: { opacity: 0, y: -10, height: 0, pointerEvents: "none", transition: { duration: 0.2 } }
  };

  const isStep2Valid = () => {
    if (!fullName || fullName.length < 2) return false;
    if (userType === 'Hiring' && (!organizationName || organizationName.length < 2)) return false;
    return true;
  };

  return (
    <motion.div
      id="signup-content"
      role="tabpanel"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* 
         We add noValidate to prevent default browser tooltips which can cause 
         "Some errors were found" generic messages if fields are hidden/animated out.
         We handle validation manually via isStep2Valid and handleSignUp checks.
      */}
      <div className="space-y-4">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="step1" variants={sectionVariants} initial="hidden" animate="visible" exit="exit">
              <Label className="mb-3 block font-semibold text-center text-lg">First, what brings you here?</Label>
              <div className="grid grid-cols-2 gap-4">
                <motion.div whileHover={{ y: -5 }} onClick={() => handleUserTypeSelect('Hiring')}>
                  <Card className="p-6 text-center cursor-pointer transition-all border-2 border-transparent hover:border-primary">
                    <Building className="w-10 h-10 mx-auto mb-3 text-primary"/>
                    <p className="font-semibold">I'm here to Hire</p>
                  </Card>
                </motion.div>
                <motion.div whileHover={{ y: -5 }} onClick={() => handleUserTypeSelect('Candidate')}>
                  <Card className="p-6 text-center cursor-pointer transition-all border-2 border-transparent hover:border-primary">
                    <Briefcase className="w-10 h-10 mx-auto mb-3 text-primary"/>
                    <p className="font-semibold">I'm a Candidate</p>
                  </Card>
                </motion.div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" variants={sectionVariants} initial="hidden" animate="visible" exit="exit">
              <div className="flex items-center gap-2 mb-4">
                <button onClick={() => setStep(1)} className="text-sm text-muted-foreground hover:text-primary">&larr; Back</button>
                <Label className="font-semibold text-center text-lg">Tell us about yourself</Label>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-fullname">Full Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input id="signup-fullname" type="text" placeholder="John Doe" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="pl-10" />
                  </div>
                </div>
                {userType === 'Hiring' && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="signup-orgname">Organization Name</Label>
                      <div className="relative">
                        <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input id="signup-orgname" type="text" placeholder="Your Company, Inc." value={organizationName} onChange={(e) => setOrganizationName(e.target.value)} required className="pl-10" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-department">Department (Optional)</Label>
                      <div className="relative">
                        <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input id="signup-department" type="text" placeholder="e.g., Engineering, HR" value={department} onChange={(e) => setDepartment(e.target.value)} className="pl-10" />
                      </div>
                    </div>
                  </>
                )}
                <Button onClick={() => setStep(3)} className="w-full" disabled={!isStep2Valid()}>Continue</Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.form 
                key="step3" 
                onSubmit={handleSignUp} 
                variants={sectionVariants} 
                initial="hidden" 
                animate="visible" 
                exit="exit" 
                className="space-y-4"
                noValidate
            >
              <div className="flex items-center gap-2 mb-4">
                <button type="button" onClick={() => setStep(2)} className="text-sm text-muted-foreground hover:text-primary">&larr; Back</button>
                <Label className="font-semibold text-center text-lg">Create your account</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input id="signup-email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10" disabled={isLoading} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input id="signup-password" type={showPassword ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="pl-10 pr-10" disabled={isLoading} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-primary p-1" disabled={isLoading}>
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="terms" checked={agreedToTerms} onCheckedChange={setAgreedToTerms} disabled={isLoading} />
                <label htmlFor="terms" className="text-sm text-muted-foreground leading-none">
                  I agree to the{' '}
                  <Link to="/terms-and-conditions" target="_blank" rel="noopener noreferrer" className="underline text-primary hover:text-primary/80">
                    Terms and Conditions
                  </Link>.
                </label>
              </div>
              <Button type="submit" className="w-full" disabled={isLoading || !agreedToTerms}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </Button>
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/40"></span></div>
                <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">Or</span></div>
              </div>
              <Button variant="outline" className="w-full" type="button" onClick={handleGoogleSignIn} disabled={isLoading}>
                <GoogleIcon className="mr-2 h-5 w-5" />
                Sign up with Google
              </Button>
            </motion.form>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default SignUpForm;