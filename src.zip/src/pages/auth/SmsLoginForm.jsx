import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Phone, MessageSquare, Loader2 } from 'lucide-react';

const SmsLoginForm = ({ setIsLoading, isLoading }) => {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const { toast } = useToast();

  const handleSendOtp = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    let formattedPhone = phone.trim();
    if (!formattedPhone.startsWith('+')) {
      formattedPhone = `+${formattedPhone}`;
    }

    try {
      const { error } = await supabase.auth.signInWithOtp({
        phone: formattedPhone,
      });

      if (error) throw error;
      
      toast({
        title: 'Code Sent! 📬',
        description: `A one-time password has been sent to ${formattedPhone}.`,
      });
      setIsOtpSent(true);
    } catch (error) {
      console.error('SMS OTP send error:', error);
      toast({
        title: 'Error Sending Code',
        description: error.message || 'Could not send OTP. Please check the phone number and ensure it includes the country code.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    let formattedPhone = phone.trim();
    if (!formattedPhone.startsWith('+')) {
      formattedPhone = `+${formattedPhone}`;
    }

    try {
      const { error } = await supabase.auth.verifyOtp({
        phone: formattedPhone,
        token: otp,
        type: 'sms',
      });

      if (error) throw error;

      toast({
        title: 'Login Successful! 🎉',
        description: 'Welcome! Redirecting you now...',
      });
    } catch (error) {
      console.error('SMS OTP verify error:', error);
      toast({
        title: 'Verification Failed',
        description: error.message || 'The code is incorrect or has expired. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const formVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4, ease: "easeInOut" } },
    exit: { opacity: 0, x: -20, transition: { duration: 0.3, ease: "easeInOut" } }
  };

  return (
    <div className="overflow-hidden" id="sms-content" role="tabpanel" aria-labelledby="sms-tab">
      {!isOtpSent ? (
        <motion.form 
            key="phone-form"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onSubmit={handleSendOtp} 
            className="space-y-6"
        >
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                placeholder="+1234567890 (with country code)"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="pl-10"
                aria-label="Phone Number with country code"
                disabled={isLoading}
              />
            </div>
          </div>
          <Button type="submit" className="w-full py-3 text-base" disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isLoading ? 'Sending...' : 'Send Code'}
          </Button>
        </motion.form>
      ) : (
        <motion.form 
            key="otp-form"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onSubmit={handleVerifyOtp} 
            className="space-y-6"
        >
          <p className="text-center text-sm text-muted-foreground">
            Enter the code sent to {phone}.
          </p>
          <div className="space-y-2">
            <Label htmlFor="otp">One-Time Code</Label>
            <div className="relative">
              <MessageSquare className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                id="otp"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="123456"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
                className="pl-10"
                aria-label="One-Time Password"
                disabled={isLoading}
              />
            </div>
          </div>
          <Button type="submit" className="w-full py-3 text-base" disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isLoading ? 'Verifying...' : 'Verify & Login'}
          </Button>
          <div className="text-center">
            <Button
              type="button"
              variant="link"
              onClick={() => {
                  setIsOtpSent(false);
                  setOtp('');
              }}
              className="text-primary hover:text-primary/80 text-sm p-0 h-auto"
              aria-label="Go back to enter phone number"
              disabled={isLoading}
            >
              Use a different phone number
            </Button>
          </div>
        </motion.form>
      )}
    </div>
  );
};

export default SmsLoginForm;