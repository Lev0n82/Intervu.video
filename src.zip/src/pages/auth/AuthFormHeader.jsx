import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Logo from '@/components/Logo';

const AuthFormHeader = () => {
  return (
    <div className="text-center mb-8">
      <Link to="/" aria-label="intervu.video Home">
        <motion.div 
          className="inline-block"
          whileHover={{ scale: 1.1, rotate: 5 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          <Logo className="h-12 w-auto" />
        </motion.div>
      </Link>
      <h1 className="text-3xl sm:text-4xl font-extrabold text-primary tracking-tight mt-4">
        Welcome
      </h1>
      <p className="text-muted-foreground mt-2 text-sm sm:text-base">
        Access your account or create a new one to begin.
      </p>
    </div>
  );
};

export default AuthFormHeader;