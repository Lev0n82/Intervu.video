import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, Mail, Lock, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Link } from 'react-router-dom';
import GoogleIcon from '@/components/icons/GoogleIcon';

const LoginForm = () => {
  const { signIn, signInWithGoogle, resendVerification } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showResend, setShowResend] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setShowResend(false);
    
    try {
      const { error: signInError } = await signIn(email, password);
      
      if (signInError) {
        setError(signInError.message || 'Failed to sign in');
        if (signInError.message.includes("Email not confirmed")) {
            setShowResend(true);
        }
        setIsLoading(false);
      }
    } catch (err) {
      console.error("Login error:", err);
      setError('An unexpected error occurred');
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
      setIsLoading(true);
      await resendVerification(email, password);
      setIsLoading(false);
      setShowResend(false);
      setError('');
  };

  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error("Google sign in error:", error);
      setError('Failed to initiate Google sign in');
    }
  };

  return (
    <motion.div
      id="login-content"
      role="tabpanel"
      aria-labelledby="login-tab"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
    >
      <form onSubmit={handleLogin} className="space-y-6" noValidate>
        {error && (
          <div role="alert" className="p-3 text-sm text-red-500 bg-red-50 border border-red-200 rounded-md flex flex-col gap-2">
            <span>{error}</span>
            {showResend && (
                <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={handleResend}
                    className="self-start border-red-200 hover:bg-red-100 text-red-700"
                >
                    Resend Verification Email
                </Button>
            )}
          </div>
        )}
        
        <div className="space-y-2">
          <Label htmlFor="login-email">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" aria-hidden="true" />
            <Input
              id="login-email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="pl-10"
              disabled={isLoading}
              aria-invalid={!!error}
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="login-password">Password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" aria-hidden="true" />
            <Input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="pl-10 pr-10"
              disabled={isLoading}
              aria-invalid={!!error}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-primary p-1 rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={showPassword ? "Hide password" : "Show password"}
              disabled={isLoading}
            >
              {showPassword ? <EyeOff size={20} aria-hidden="true" /> : <Eye size={20} aria-hidden="true" />}
            </button>
          </div>
        </div>
        
        <Button type="submit" className="w-full py-3 text-base" disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" /> : null}
          {isLoading ? 'Processing...' : 'Login'}
        </Button>
        
        <div className="text-center">
          <Link
            to="/forgot-password"
            state={{ email: email }}
            className="text-primary hover:text-primary/80 text-sm p-0 h-auto inline-flex items-center focus-visible:ring-2 focus-visible:ring-ring rounded"
          >
            Forgot Password?
          </Link>
        </div>
      </form>
      
      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <span className="w-full border-t border-border/40"></span>
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
        </div>
      </div>
      
      <Button
        variant="outline"
        className="w-full py-3 text-base"
        onClick={handleGoogleSignIn}
        disabled={isLoading}
        type="button"
      >
        <GoogleIcon className="mr-2 h-5 w-5" aria-hidden="true" />
        Sign in with Google
      </Button>

    </motion.div>
  );
};

export default LoginForm;