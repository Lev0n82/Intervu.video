
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

const TeamJoinSuccessPage = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Fire confetti
    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 2,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#22c55e', '#3b82f6'] 
      });
      confetti({
        particleCount: 2,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#22c55e', '#3b82f6']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    // Auto redirect
    const timer = setTimeout(() => {
        navigate('/dashboard');
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-green-50/50 p-4">
      <Card className="max-w-md w-full text-center p-8 shadow-xl border-green-100">
        <CardContent className="space-y-6 pt-6">
            <div className="mx-auto bg-green-100 p-4 rounded-full w-fit animate-bounce">
                <CheckCircle2 className="h-12 w-12 text-green-600" />
            </div>
            
            <div className="space-y-2">
                <h1 className="text-3xl font-bold text-green-900">Welcome Aboard!</h1>
                <p className="text-gray-600">
                    You've successfully joined the team. Your account is ready.
                </p>
            </div>

            <Button className="w-full bg-green-600 hover:bg-green-700 text-white" onClick={() => navigate('/dashboard')}>
                Go to Dashboard <ArrowRight className="ml-2 w-4 h-4"/>
            </Button>
            
            <p className="text-xs text-gray-400">Redirecting automatically in a few seconds...</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default TeamJoinSuccessPage;
