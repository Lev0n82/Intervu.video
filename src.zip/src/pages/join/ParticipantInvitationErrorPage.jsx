
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle2, Clock, HelpCircle } from 'lucide-react';
import { getParticipantErrorMessage } from '@/lib/ParticipantSessionValidator';
import Logo from '@/components/Logo';

const ParticipantInvitationErrorPage = () => {
    const { errorType } = useParams();

    const getIcon = () => {
        switch (errorType) {
            case 'COMPLETED': return <CheckCircle2 className="w-12 h-12 text-green-500" />;
            case 'EXPIRED': return <Clock className="w-12 h-12 text-orange-500" />;
            case 'INVALID': 
            case 'NOT_FOUND': return <AlertCircle className="w-12 h-12 text-red-500" />;
            default: return <HelpCircle className="w-12 h-12 text-gray-500" />;
        }
    };

    const getTitle = () => {
         switch (errorType) {
            case 'COMPLETED': return "Already Completed";
            case 'EXPIRED': return "Invitation Expired";
            case 'INVALID': 
            case 'NOT_FOUND': return "Invalid Link";
            default: return "Access Error";
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
            <div className="mb-8">
                <Logo />
            </div>
            <Card className="w-full max-w-md text-center shadow-lg border-t-4 border-t-primary">
                <CardHeader className="pb-2">
                    <div className="flex justify-center mb-4">
                        {getIcon()}
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-800">
                        {getTitle()}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 pt-4">
                    <p className="text-slate-600">
                        {getParticipantErrorMessage(errorType)}
                    </p>
                    
                    <div className="bg-slate-100 p-4 rounded-lg text-sm text-slate-500 text-left">
                        <p className="font-semibold mb-1">Need help?</p>
                        <p>If you believe this is an error, please contact the organization that invited you directly.</p>
                    </div>

                    <div className="flex flex-col gap-2">
                         <Button asChild variant="default">
                            <Link to="/">Return to Home</Link>
                         </Button>
                    </div>
                </CardContent>
            </Card>
            <p className="mt-8 text-xs text-slate-400">
                &copy; {new Date().getFullYear()} Intervu.video
            </p>
        </div>
    );
};

export default ParticipantInvitationErrorPage;
