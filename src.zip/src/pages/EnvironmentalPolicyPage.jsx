import React from 'react';
import { motion } from 'framer-motion';
import { Leaf, Recycle, Lightbulb, Server, Cloud } from 'lucide-react';

const PolicySection = ({ icon, title, children }) => (
  <motion.div 
    className="flex items-start space-x-4 p-6 bg-card rounded-xl border border-border shadow-sm"
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true, amount: 0.5 }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
      {React.cloneElement(icon, { className: "w-6 h-6 text-primary" })}
    </div>
    <div>
      <h3 className="text-xl font-semibold text-card-foreground mb-2">{title}</h3>
      <div className="text-muted-foreground space-y-2">{children}</div>
    </div>
  </motion.div>
);

const EnvironmentalPolicyPage = () => {
  return (
    <div className="container mx-auto max-w-4xl py-12 sm:py-16 px-4">
      <motion.header 
        className="text-center mb-12"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Leaf className="w-16 h-16 mx-auto text-primary mb-4" />
        <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight">
          Environmental Policy
        </h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          intervu.video is committed to minimizing our environmental impact and promoting sustainable practices in all aspects of our business.
        </p>
      </motion.header>

      <div className="space-y-8">
        <PolicySection title="Our Commitment" icon={<Leaf />}>
          <p>We recognize our responsibility to protect the environment. As a digital-first company, we focus on reducing our carbon footprint through efficient technology, responsible resource management, and promoting environmental awareness among our employees and users.</p>
        </PolicySection>

        <PolicySection title="Energy Efficiency" icon={<Lightbulb />}>
          <p>Our platform is designed for optimal performance to reduce energy consumption on both server and client-side devices. We continuously work on code optimization and efficient data processing to minimize computational overhead.</p>
        </PolicySection>

        <PolicySection title="Sustainable Infrastructure" icon={<Server />}>
          <p>We partner with cloud infrastructure providers (like Supabase, which runs on AWS) that are committed to sustainability and powering their data centers with renewable energy. We prioritize providers who share our environmental goals and demonstrate a clear path towards carbon neutrality.</p>
        </PolicySection>

        <PolicySection title="Waste Reduction & Recycling" icon={<Recycle />}>
          <p>As a primarily digital business, we aim for a paperless office environment. We encourage digital communication and documentation. Any physical hardware is used to its maximum lifespan and responsibly recycled or disposed of at its end-of-life.</p>
        </PolicySection>

        <PolicySection title="Promoting Remote Work" icon={<Cloud />}>
          <p>Our core product facilitates remote interviews, which inherently reduces the need for travel and its associated carbon emissions. We champion remote work for our own team, further contributing to a lower collective environmental footprint.</p>
        </PolicySection>
      </div>

      <motion.footer 
        className="mt-16 text-center text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <p>This policy is reviewed annually to ensure its effectiveness and to incorporate new sustainability initiatives. Last updated: {new Date().toLocaleDateString()}.</p>
      </motion.footer>
    </div>
  );
};

export default EnvironmentalPolicyPage;