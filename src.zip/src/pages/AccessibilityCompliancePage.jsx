
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';

const ComplianceStatus = ({ status }) => {
    const { t } = useTranslation();
    if (status === 'Compliant') {
        return <span className="flex items-center text-green-500"><CheckCircle className="w-4 h-4 mr-1" aria-hidden="true" /> {t('accessibilityPage.status.compliant')}</span>;
    }
    if (status === 'Partially Compliant') {
        return <span className="flex items-center text-yellow-500"><AlertCircle className="w-4 h-4 mr-1" aria-hidden="true" /> {t('accessibilityPage.status.partially')}</span>;
    }
    return <span className="flex items-center text-red-500"><XCircle className="w-4 h-4 mr-1" aria-hidden="true" /> {t('accessibilityPage.status.not')}</span>;
};

const AccessibilityCompliancePage = () => {
    const { toast } = useToast();
    const { t } = useTranslation();

    const wcagSections = [
        { id: '1.1', title: t('accessibilityPage.guidelines.textAlternatives'), status: 'Compliant', notes: t('accessibilityPage.guidelines.textAlternatives') },
        { id: '1.2', title: t('accessibilityPage.guidelines.timeBasedMedia'), status: 'Partially Compliant', notes: t('accessibilityPage.guidelines.timeBasedMedia') },
        { id: '1.3', title: t('accessibilityPage.guidelines.adaptable'), status: 'Compliant', notes: t('accessibilityPage.guidelines.adaptable') },
        { id: '1.4', title: t('accessibilityPage.guidelines.distinguishable'), status: 'Compliant', notes: t('accessibilityPage.guidelines.distinguishable') },
        { id: '2.1', title: t('accessibilityPage.guidelines.keyboard'), status: 'Compliant', notes: t('accessibilityPage.guidelines.keyboard') },
        { id: '2.2', title: t('accessibilityPage.guidelines.enoughTime'), status: 'Compliant', notes: t('accessibilityPage.guidelines.enoughTime') },
        { id: '2.3', title: t('accessibilityPage.guidelines.seizures'), status: 'Compliant', notes: t('accessibilityPage.guidelines.seizures') },
        { id: '2.4', title: t('accessibilityPage.guidelines.navigable'), status: 'Compliant', notes: t('accessibilityPage.guidelines.navigable') },
        { id: '2.5', title: t('accessibilityPage.guidelines.inputModalities'), status: 'Compliant', notes: t('accessibilityPage.guidelines.inputModalities') },
        { id: '3.1', title: t('accessibilityPage.guidelines.readable'), status: 'Compliant', notes: t('accessibilityPage.guidelines.readable') },
        { id: '3.2', title: t('accessibilityPage.guidelines.predictable'), status: 'Compliant', notes: t('accessibilityPage.guidelines.predictable') },
        { id: '3.3', title: t('accessibilityPage.guidelines.inputAssistance'), status: 'Compliant', notes: t('accessibilityPage.guidelines.inputAssistance') },
        { id: '4.1', title: t('accessibilityPage.guidelines.compatible'), status: 'Compliant', notes: t('accessibilityPage.guidelines.compatible') },
    ];

    const pageCompliance = [
        { name: t('accessibilityPage.pages.dashboard.name'), status: 'Compliant' },
        { name: t('accessibilityPage.pages.auth.name'), status: 'Compliant' },
        { name: t('accessibilityPage.pages.team.name'), status: 'Compliant' },
        { name: t('accessibilityPage.pages.surveyBuilder.name'), status: t('accessibilityPage.pages.surveyBuilder.status'), notes: t('accessibilityPage.pages.surveyBuilder.notes') },
        { name: t('accessibilityPage.pages.interviewBuilder.name'), status: 'Compliant' },
        { name: t('accessibilityPage.pages.candidateExperience.name'), status: t('accessibilityPage.pages.candidateExperience.status'), notes: t('accessibilityPage.pages.candidateExperience.notes') },
        { name: t('accessibilityPage.pages.settings.name'), status: 'Compliant' },
        { name: t('accessibilityPage.pages.static.name'), status: 'Compliant' },
    ];

    const handleContactClick = () => {
        toast({
            title: t('accessibilityPage.feedback.button'),
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    return (
        <>
            <Helmet>
                <title>{t('accessibilityPage.helmet.title')}</title>
                <meta name="description" content={t('accessibilityPage.helmet.description')} />
            </Helmet>
            <motion.div
                className="max-w-5xl mx-auto p-4 sm:p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
            >
                <header className="mb-8 text-center">
                    <ShieldCheck className="w-16 h-16 mx-auto text-primary mb-4" aria-hidden="true" />
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-foreground">{t('accessibilityPage.header.title')}</h1>
                    <p className="mt-2 text-lg text-muted-foreground">
                        {t('accessibilityPage.header.subtitle')}
                    </p>
                    <p className="mt-2 text-base text-muted-foreground max-w-2xl mx-auto">
                        {t('accessibilityPage.header.description')}
                    </p>
                </header>

                <motion.section
                    className="mb-10 p-6 bg-card border border-border rounded-xl shadow-sm"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    aria-labelledby="accessibility-statement-heading"
                >
                    <h2 id="accessibility-statement-heading" className="text-2xl font-bold text-primary mb-4">{t('accessibilityPage.commitment.heading')}</h2>
                    <p className="text-muted-foreground">
                        {t('accessibilityPage.commitment.text')}
                    </p>
                </motion.section>

                <motion.section
                    className="mb-10"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    aria-labelledby="wcag-status-heading"
                >
                    <h2 id="wcag-status-heading" className="text-2xl font-bold text-primary mb-4">{t('accessibilityPage.selfEvaluation.heading')}</h2>
                    <div className="overflow-x-auto bg-card border border-border rounded-xl shadow-sm">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-secondary">
                                <tr>
                                    <th scope="col" className="px-6 py-3 font-semibold w-24">{t('accessibilityPage.selfEvaluation.guideline')}</th>
                                    <th scope="col" className="px-6 py-3 font-semibold">{t('accessibilityPage.selfEvaluation.notes')}</th>
                                    <th scope="col" className="px-6 py-3 font-semibold w-40">{t('accessibilityPage.selfEvaluation.status')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {wcagSections.map(section => (
                                    <tr key={section.id} className="border-b border-border hover:bg-secondary/50 transition-colors">
                                        <td className="px-6 py-4 font-medium align-top">{section.id}</td>
                                        <td className="px-6 py-4 text-muted-foreground align-top">{section.notes}</td>
                                        <td className="px-6 py-4 align-top"><ComplianceStatus status={section.status} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </motion.section>

                <motion.section
                    className="mb-10"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.6 }}
                    aria-labelledby="page-status-heading"
                >
                    <h2 id="page-status-heading" className="text-2xl font-bold text-primary mb-4">{t('accessibilityPage.pageStatus.heading')}</h2>
                    <div className="overflow-x-auto bg-card border border-border rounded-xl shadow-sm">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-secondary">
                                <tr>
                                    <th scope="col" className="px-6 py-3 font-semibold">{t('accessibilityPage.pageStatus.pageArea')}</th>
                                    <th scope="col" className="px-6 py-3 font-semibold">{t('accessibilityPage.pageStatus.status')}</th>
                                    <th scope="col" className="px-6 py-3 font-semibold">{t('accessibilityPage.pageStatus.notes')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {pageCompliance.map(page => (
                                    <tr key={page.name} className="border-b border-border hover:bg-secondary/50 transition-colors">
                                        <td className="px-6 py-4 font-medium">{page.name}</td>
                                        <td className="px-6 py-4"><ComplianceStatus status={page.status} /></td>
                                        <td className="px-6 py-4 text-muted-foreground">{page.notes || t('accessibilityPage.pageStatus.fullyCompliant')}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </motion.section>

                <motion.footer
                    className="mt-12 text-center p-6 bg-card border border-border rounded-xl shadow-sm"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    aria-labelledby="feedback-heading"
                >
                    <h2 id="feedback-heading" className="text-xl font-bold text-foreground mb-2">{t('accessibilityPage.feedback.heading')}</h2>
                    <p className="text-muted-foreground mb-4">
                        {t('accessibilityPage.feedback.text')}
                    </p>
                    <Button onClick={handleContactClick}>{t('accessibilityPage.feedback.button')}</Button>
                    <p className="mt-6 text-xs text-muted-foreground">
                        {t('accessibilityPage.meta.lastUpdated')}
                    </p>
                </motion.footer>
            </motion.div>
        </>
    );
};

export default AccessibilityCompliancePage;
