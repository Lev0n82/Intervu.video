
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PlusCircle, Save, Loader2, Video, CheckCircle, Upload, FileUp, Sparkles, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import VideoRecorder from '@/components/VideoRecorder';
import VideoGenerationQueue from '@/components/VideoGenerationQueue';
import QuestionBuilder from '@/components/interview/QuestionBuilder';
import AIGenerationDialog from '@/components/interview/AIGenerationDialog';
import { useVideoGeneration } from '@/hooks/useVideoGeneration';
import IntroductionInstructions from '@/components/interview/IntroductionInstructions';
import { Badge } from '@/components/ui/badge';
import AutoGenerationConfirmationModal from '@/components/AutoGenerationConfirmationModal';
import { useAutoGenerateVideos } from '@/hooks/useAutoGenerateVideos';
import logger from '@/lib/logger';

const EditTemplatePage = () => {
    const { templateId } = useParams();
    const { toast } = useToast();
    const navigate = useNavigate();
    const auth = useAuth();
    const { user, activeOrganization, loading: authLoading } = auth;
    const { isDemo, promptSave } = useDemo();

    const [templateName, setTemplateName] = useState('');
    const [templateDescription, setTemplateDescription] = useState('');
    const [introductionText, setIntroductionText] = useState('');
    const [introductionVideoUrl, setIntroductionVideoUrl] = useState('');
    const [introductionFileUrl, setIntroductionFileUrl] = useState('');
    const [uploadingFile, setUploadingFile] = useState(false);
    const introFileInputRef = useRef(null);
    const questionFileInputRef = useRef(null);
    const [questions, setQuestions] = useState([]);
    const [personas, setPersonas] = useState([]);
    const [saving, setSaving] = useState(false);
    const [loading, setLoading] = useState(true);
    const [activeSubmitType, setActiveSubmitType] = useState(null);

    const [isRecorderOpen, setIsRecorderOpen] = useState(false);
    const [recorderContext, setRecorderContext] = useState({ questionId: null, field: null });

    const [isAIGenOpen, setIsAIGenOpen] = useState(false);
    const [aiGenContext, setAIGenContext] = useState({ questionId: null, field: null, text: '', personaId: '' });
    
    const [uploadContext, setUploadContext] = useState({ questionId: null, field: null });
    const [isUploading, setIsUploading] = useState(false);

    // Auto Generation State
    const [showAutoConfirm, setShowAutoConfirm] = useState(false);
    const { 
        assignRandomPersonasAndQueueVideos, 
        isGenerating: isAutoGenerating, 
        progress: autoGenProgress, 
        total: autoGenTotal, 
        error: autoGenError 
    } = useAutoGenerateVideos(activeOrganization?.id);

    // AI Generation Hook (for single generations)
    const handleGenerationComplete = useCallback(async (questionId, field, url) => {
        // Optimistic update in UI
        if (questionId === 'introduction') {
            setIntroductionVideoUrl(url);
            if (templateId) {
                await supabase.from('interview_templates').update({ introduction_video_url: url }).eq('id', templateId);
            }
        } else {
            setQuestions(currentQuestions => 
                currentQuestions.map(q => q.id === questionId ? { ...q, [field]: url } : q)
            );
        }
        toast({ title: "Video Generated", description: "Your AI video is ready! Verify it matches your prompt." });
    }, [toast, templateId]);

    const { generations, startGeneration, trackQueueCompletion } = useVideoGeneration(activeOrganization?.id, handleGenerationComplete);

    const isPageDisabled = authLoading || saving || loading || isUploading || isAutoGenerating;

    useEffect(() => {
        const fetchTemplateData = async () => {
            if (!templateId) return;
            setLoading(true);
            try {
                const { data, error } = await supabase
                    .from('interview_templates')
                    .select('*, template_questions(*)')
                    .eq('id', templateId)
                    .single();

                if (error) throw error;

                setTemplateName(data.name);
                setTemplateDescription(data.description);
                setIntroductionText(data.introduction_text);
                setIntroductionVideoUrl(data.introduction_video_url);
                setIntroductionFileUrl(data.introduction_file_url);
                setQuestions(data.template_questions.sort((a, b) => a.order - b.order).map(q => ({...q, id: q.id})));
            } catch (error) {
                toast({ title: "Error fetching template", description: error.message, variant: "destructive" });
                navigate(isDemo ? '/demo/templates' : '/templates');
            } finally {
                setLoading(false);
            }
        };

        const fetchPersonas = async () => {
            if (!activeOrganization?.id) return;
            const { data, error } = await supabase
                .from('personas')
                .select('*')
                .eq('organization_id', activeOrganization.id);
            if (error) {
                toast({ title: "Error fetching personas", description: error.message, variant: "destructive" });
            } else {
                setPersonas(data);
            }
        };

        if (isDemo) {
            setLoading(false);
        } else if (activeOrganization && !authLoading) {
            fetchTemplateData();
            fetchPersonas();
        }
    }, [templateId, activeOrganization, authLoading, toast, navigate, isDemo]);

    const addQuestion = () => {
        const newQuestion = {
            id: `temp-${Date.now()}`,
            question_text: '',
            clarification_text: '',
            question_video_url: '',
            clarification_video_url: '',
            persona_id: '',
            order: questions.length,
        };
        setQuestions([...questions, newQuestion]);
    };

    const handleIntroFileChange = async (event) => {
        if (promptSave()) return;
        const file = event.target.files[0];
        if (!file || !activeOrganization?.id) return;

        setUploadingFile(true);
        const fileName = `introduction-docs/${activeOrganization.id}/${Date.now()}-${file.name}`;
        
        const { data, error } = await supabase.storage
            .from('template-videos')
            .upload(fileName, file);

        if (error) {
            toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
        } else {
            const { data: { publicUrl } } = supabase.storage.from('template-videos').getPublicUrl(data.path);
            setIntroductionFileUrl(publicUrl);
            toast({ title: "File Uploaded!", description: "The introduction document has been saved." });
        }
        setUploadingFile(false);
    };

    const removeQuestion = (id) => {
        setQuestions(questions.filter(q => q.id !== id));
    };

    const handleQuestionChange = (id, field, value) => {
        setQuestions(questions.map(q => q.id === id ? { ...q, [field]: value } : q));
    };

    const handleRecordVideo = (questionId, field) => {
        if (promptSave()) return;
        setRecorderContext({ questionId, field });
        setIsRecorderOpen(true);
    };

    const handleUploadVideo = (questionId, field) => {
        if (promptSave()) return;
        setUploadContext({ questionId, field });
        questionFileInputRef.current?.click();
    };

    const handleQuestionFileChange = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        setIsUploading(true);
        const fileName = `template-videos/video-${Date.now()}-${file.name}`;
        try {
            const { data, error } = await supabase.storage.from('template-videos').upload(fileName, file);
            if (error) throw error;
            const { data: { publicUrl } } = supabase.storage.from('template-videos').getPublicUrl(data.path);
            
            if (uploadContext.questionId === 'introduction') {
                 setIntroductionVideoUrl(publicUrl);
            } else if (uploadContext.questionId && uploadContext.field) {
                handleQuestionChange(uploadContext.questionId, uploadContext.field, publicUrl);
            }
            toast({ title: "Upload Complete!", description: "Your video has been saved." });
        } catch (error) {
            toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
        } finally {
            setIsUploading(false);
            event.target.value = '';
        }
    };

    const handleUploadComplete = (data) => {
        const url = data.url;
        const { questionId, field } = recorderContext;
        if (questionId === 'introduction') {
            setIntroductionVideoUrl(url);
        } else {
            handleQuestionChange(questionId, field, url);
        }
        setIsRecorderOpen(false);
    };

    const handleGenerateVideo = (questionId, field) => {
        if (promptSave()) return;
        
        let text = '';
        let personaId = '';

        if (questionId === 'introduction') {
            text = introductionText;
            if (!text || text.trim() === '') {
                toast({ title: "Introduction Text Required", description: "Please enter introduction text first.", variant: "destructive" });
                return;
            }
        } else {
            const question = questions.find(q => q.id === questionId);
            if (!question) return;
            text = field === 'question_video_url' ? question.question_text : question.clarification_text;
            personaId = question.persona_id;
            
            if (!text || text.trim() === '') {
                toast({ title: "Text Required", description: "Please enter text before generating.", variant: "destructive" });
                return;
            }
        }
        
        console.log(`[EditTemplate] Opening AI Dialog for: ${questionId}, text length: ${text.length}`);
        setAIGenContext({ questionId, field, text, personaId });
        setIsAIGenOpen(true);
    };

    const saveQuestions = async () => {
        const newQuestions = questions.filter(q => String(q.id).startsWith('temp-'));
        const updatedQuestions = questions.filter(q => !String(q.id).startsWith('temp-'));

        let allQuestions = [...updatedQuestions];

        if (newQuestions.length > 0) {
            const newQuestionInserts = newQuestions.map((q, i) => {
                const newId = crypto.randomUUID();
                return {
                    id: newId, 
                    template_id: templateId,
                    question_text: q.question_text || '',
                    clarification_text: q.clarification_text || '',
                    question_video_url: q.question_video_url,
                    clarification_video_url: q.clarification_video_url,
                    persona_id: q.persona_id || null,
                    order: updatedQuestions.length + i,
                };
            });
            
            const { data: insertedData, error: insertError } = await supabase.from('template_questions').insert(newQuestionInserts).select();
            
            if (insertError) throw insertError;
            allQuestions = [...updatedQuestions, ...insertedData];
        }

        const finalQuestionUpdates = allQuestions.map((q, index) => {
            return {
                id: q.id,
                template_id: templateId,
                question_text: q.question_text || '',
                clarification_text: q.clarification_text || '',
                question_video_url: q.question_video_url,
                clarification_video_url: q.clarification_video_url,
                persona_id: q.persona_id || null,
                order: index,
            };
        });

        if (finalQuestionUpdates.length > 0) {
            const { error: upsertError } = await supabase.from('template_questions').upsert(finalQuestionUpdates);
            if (upsertError) throw upsertError;
        }

        return allQuestions; // Return with real IDs
    };
    
    // Updated signature to accept options from AIGenerationDialog
    const handleStartGeneration = async (prompt, personaId, options = {}) => {
        if (promptSave()) return;
        if (!activeOrganization?.id || !user?.id) return;
        
        let targetQuestionId = aiGenContext.questionId;
        const fieldToGenerate = aiGenContext.field;
        
        setSaving(true);
        setIsAIGenOpen(false);
        
        // Log the exact prompt being used
        logger.video.request(prompt, { 
            context: 'EditTemplatePage', 
            targetQuestionId, 
            fieldToGenerate 
        });

        try {
            if (String(targetQuestionId).startsWith('temp-')) {
                 const updatedQs = await saveQuestions();
                 const originalQIndex = questions.findIndex(q => q.id === targetQuestionId);
                 if (originalQIndex !== -1 && updatedQs[originalQIndex]) {
                     targetQuestionId = updatedQs[originalQIndex].id;
                     setQuestions(updatedQs.sort((a,b) => a.order - b.order));
                 }
            }
            
            // Special handling for Intro
            if (targetQuestionId === 'introduction') {
                await startGeneration(
                    'introduction', 
                    'intro_video', 
                    prompt, 
                    user.id, 
                    null, 
                    personaId,
                    options // Pass provider/fallai options
                );
            } else {
                 await startGeneration(
                    targetQuestionId, 
                    fieldToGenerate, 
                    prompt, 
                    user.id, 
                    targetQuestionId,
                    personaId,
                    options // Pass provider/fallai options
                );
            }
            // Toast handled in hook
        } catch (error) {
            console.error("Queue Generation Error:", error);
            toast({ title: "Failed to queue generation", description: error.message, variant: "destructive" });
        } finally {
            setSaving(false);
        }
    };

    // --- AUTO GENERATION FLOW ---
    const runAutoGeneration = async () => {
        try {
            const savedQs = await saveQuestions();
            setQuestions(savedQs.sort((a,b) => a.order - b.order));
            
            const pendingTasks = [];
            
            // 1. Check Introduction
            if (!introductionVideoUrl) {
                pendingTasks.push({
                    type: 'intro',
                    id: null,
                    text: introductionText || "Welcome to the interview.",
                    label: "Introduction Video"
                });
            }

            // 2. Check Questions
            savedQs.forEach(q => {
                if (!q.question_video_url) {
                    pendingTasks.push({ 
                        type: 'question', 
                        id: q.id, 
                        text: q.question_text, 
                        label: `Question: ${q.question_text.substring(0, 30)}...` 
                    });
                }
                if (q.clarification_text && !q.clarification_video_url) {
                    pendingTasks.push({ 
                        type: 'clarification', 
                        id: q.id, 
                        text: q.clarification_text, 
                        label: `Clarification: ${q.question_text.substring(0, 30)}...` 
                    });
                }
            });

            if (pendingTasks.length === 0) {
                finishActivation();
                return;
            }

            const { success, queuedIds, assignedPersonasCount, error } = await assignRandomPersonasAndQueueVideos({
                templateId,
                userId: user.id,
                itemsToGenerate: pendingTasks,
                templateQuestions: savedQs
            });

            if (!success) {
                throw error;
            }
            
            // Track & Notify
            if (queuedIds && queuedIds.length > 0) {
                 trackQueueCompletion(queuedIds, {
                     templateId: templateId,
                     templateName: templateName,
                     creatorEmail: user.email,
                     previewUrl: `${window.location.origin}/preview/${templateId}`
                 });
                 if (assignedPersonasCount > 0) {
                     toast({ title: "Personas Assigned", description: `Automatically assigned AI personas to ${assignedPersonasCount} questions.` });
                 }
            }
            
            // Activate immediately as "Active (Processing)" effectively
            await finishActivation(true);

        } catch (err) {
            console.error("Auto Gen Fatal Error", err);
            // Error is handled by modal display state if we pass it
        }
    };

    const finishActivation = async (hasPendingVideos = false) => {
        try {
            const { error } = await supabase
                .from('interview_templates')
                .update({
                    status: 'active',
                    updated_at: new Date().toISOString()
                })
                .eq('id', templateId);

            if (error) throw error;

            let msg = 'Template Activated! Your template is live.';
            if (hasPendingVideos) {
                msg = 'Videos are generating. Candidates can access the interview once processing completes.';
            }

            toast({ 
                title: 'Success', 
                description: msg,
                className: "bg-green-600 text-white"
            });
            
            setTimeout(() => {
                navigate(isDemo ? '/demo/templates' : '/templates');
            }, 2000);

        } catch (error) {
             toast({ title: "Activation Failed", description: error.message, variant: "destructive" });
        }
    };

    const handleUpdateTemplate = async (submitType) => {
        if (promptSave()) return;

        setActiveSubmitType(submitType);
        setSaving(true);

        if (!activeOrganization?.id || !user?.id) {
            toast({ title: 'Error', description: 'Organization or user session missing. Please re-login.', variant: 'destructive' });
            setSaving(false);
            setActiveSubmitType(null);
            return;
        }

        if (!templateName) {
            toast({ title: "Template name is required", variant: "destructive" });
            setSaving(false);
            setActiveSubmitType(null);
            return;
        }

        try {
            const { error: templateError } = await supabase
                .from('interview_templates')
                .update({
                    name: templateName,
                    description: templateDescription,
                    introduction_text: introductionText,
                    introduction_video_url: introductionVideoUrl,
                    introduction_file_url: introductionFileUrl,
                    status: 'draft', 
                    updated_at: new Date().toISOString(),
                })
                .eq('id', templateId)
                .eq('organization_id', activeOrganization.id); // Extra safety check

            if (templateError) throw templateError;

            const savedQuestionsWithIds = await saveQuestions();
            setQuestions(savedQuestionsWithIds.sort((a,b) => a.order - b.order));

            if (submitType === 'active') {
                const missingIntro = !introductionVideoUrl;
                const missingQuestions = savedQuestionsWithIds.some(q => !q.question_video_url || (q.clarification_text && !q.clarification_video_url));

                // CONDITIONAL VALIDATION: If missing videos, show modal instead of blocking
                if (missingIntro || missingQuestions) {
                    setSaving(false); 
                    setShowAutoConfirm(true); 
                    return; 
                } else {
                    await finishActivation(false);
                }
            } else {
                toast({ title: 'Draft Saved!', description: `Your changes have been saved.` });
                navigate(isDemo ? '/demo/templates' : '/templates');
            }
        } catch (error) {
            console.error("Update Template Error:", error);
            toast({ title: "Error Updating Template", description: error.message, variant: "destructive" });
        } finally {
            setSaving(false);
            setActiveSubmitType(null);
        }
    };

    if (loading && !isDemo) {
        return <div className="flex justify-center items-center h-96"><Loader2 className="w-8 h-8 animate-spin" /></div>;
    }

    return (
        <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                <h1 className="text-3xl font-bold text-primary mb-2">Edit Interview Template</h1>
                <p className="text-muted-foreground mb-6">Modify your reusable interview format.</p>
            </motion.div>
            
            <IntroductionInstructions loading={loading} />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <fieldset disabled={isPageDisabled} className="lg:col-span-2 space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Template Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label htmlFor="template-name">Template Name</Label>
                                <Input id="template-name" value={templateName} onChange={e => setTemplateName(e.target.value)} placeholder="e.g., Senior Frontend Developer" />
                            </div>
                            <div>
                                <Label htmlFor="template-desc">Description</Label>
                                <Textarea id="template-desc" value={templateDescription} onChange={e => setTemplateDescription(e.target.value)} placeholder="Description..." />
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center justify-between">
                                <div className="flex items-center"><Video className="mr-2 h-5 w-5"/>Introduction</div>
                                {introductionVideoUrl ? 
                                    <Badge className="bg-green-100 text-green-700 hover:bg-green-200">Video Ready</Badge> : 
                                    <Badge variant="outline" className="text-slate-500">Missing Video</Badge>
                                }
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label htmlFor="intro-text">Introduction Script / Text</Label>
                                <Textarea id="intro-text" value={introductionText} onChange={e => setIntroductionText(e.target.value)} placeholder="Welcome message..." />
                            </div>
                            
                            <div className="flex flex-wrap gap-4 mt-2">
                                {introductionVideoUrl ? (
                                    <div className="w-full">
                                        <p className="text-sm text-gray-500 mb-1">Generated from: "{introductionText.substring(0,50)}..."</p>
                                        <video src={introductionVideoUrl} className="w-full max-h-60 bg-black rounded-lg mb-2" controls />
                                        <Button variant="ghost" size="sm" onClick={() => setIntroductionVideoUrl('')} className="text-red-500 hover:text-red-600 hover:bg-red-50">Remove Video</Button>
                                    </div>
                                ) : (
                                    <>
                                        <Button type="button" variant="outline" onClick={() => handleGenerateVideo('introduction', 'intro_video_url')}>
                                            <Sparkles className="w-4 h-4 mr-2 text-purple-600"/> Generate AI Video
                                        </Button>
                                        <Button type="button" variant="outline" onClick={() => handleRecordVideo('introduction', 'intro_video_url')}>
                                            <Video className="w-4 h-4 mr-2 text-red-600"/> Record
                                        </Button>
                                        <Button type="button" variant="outline" onClick={() => handleUploadVideo('introduction', 'intro_video_url')}>
                                            <Upload className="w-4 h-4 mr-2 text-blue-600"/> Upload
                                        </Button>
                                    </>
                                )}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Questions</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {questions.map((q, index) => (
                                <QuestionBuilder
                                    key={q.id}
                                    question={q}
                                    index={index}
                                    onQuestionChange={handleQuestionChange}
                                    onRemoveQuestion={removeQuestion}
                                    personas={personas}
                                    onRecordVideo={handleRecordVideo}
                                    onUploadVideo={handleUploadVideo}
                                    onGenerateVideo={handleGenerateVideo}
                                    disabled={isPageDisabled}
                                    generationStatus={{
                                        'question_video_url': generations[`${q.id}-question_video_url`],
                                        'clarification_video_url': generations[`${q.id}-clarification_video_url`]
                                    }}
                                />
                            ))}
                            <Button type="button" variant="outline" onClick={addQuestion} className="w-full border-dashed">
                                <PlusCircle className="w-4 h-4 mr-2" /> Add Question
                            </Button>
                        </CardContent>
                    </Card>

                    <div className="flex justify-end gap-3 pt-6">
                        <Button variant="secondary" onClick={() => handleUpdateTemplate('draft')} disabled={isPageDisabled}>
                            {saving && activeSubmitType === 'draft' && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                            Save Draft
                        </Button>
                        <Button onClick={() => handleUpdateTemplate('active')} disabled={isPageDisabled} className={isPageDisabled ? "" : "bg-blue-600 hover:bg-blue-700 text-white"}>
                            {saving && activeSubmitType === 'active' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 
                             <FileUp className="w-4 h-4 mr-2" />
                            }
                            Save & Activate
                        </Button>
                    </div>
                </fieldset>

                <div className="lg:col-span-1 space-y-6">
                    <VideoGenerationQueue />
                </div>
            </div>

            <VideoRecorder open={isRecorderOpen} onOpenChange={setIsRecorderOpen} onUploadComplete={handleUploadComplete} />
            <AIGenerationDialog open={isAIGenOpen} onOpenChange={setIsAIGenOpen} onStartGeneration={handleStartGeneration} questionText={aiGenContext.text} personaId={aiGenContext.personaId} personas={personas} isGenerating={saving} isClarification={aiGenContext.field === 'clarification_video_url'} />
            
            <AutoGenerationConfirmationModal
                open={showAutoConfirm}
                onOpenChange={setShowAutoConfirm}
                onConfirm={runAutoGeneration}
                questionCount={questions.filter(q => !q.question_video_url || (q.clarification_text && !q.clarification_video_url)).length}
                hasIntroMissing={!introductionVideoUrl}
                isGenerating={isAutoGenerating}
                progress={autoGenProgress}
                total={autoGenTotal}
                error={autoGenError}
                questions={questions}
                template={{ id: templateId, name: templateName }}
            />

            <input type="file" ref={questionFileInputRef} onChange={handleQuestionFileChange} className="hidden" accept="video/*" />
        </div>
    );
};

export default EditTemplatePage;
