import React, { useState, useEffect } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import Logo from '@/components/Logo';
    import { ArrowRight, Info, CheckCircle, Video, Users, Languages, UserPlus, FileText, UserCheck, Eye } from 'lucide-react';
    import { Helmet } from 'react-helmet-async';
    import { useTranslation } from 'react-i18next';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Button } from '@/components/ui/button';
    import {
      Dialog,
      DialogContent,
      DialogDescription,
      DialogHeader,
      DialogTitle,
      DialogTrigger,
    } from "@/components/ui/dialog"
    import { Card, CardContent, CardHeader } from '@/components/ui/card';

    const FeatureCard = ({ icon, title, description, delay }) => (
      <motion.div
        className="bg-card p-6 rounded-xl border border-border shadow-sm text-left"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay }}
      >
        <div className="flex items-center mb-3">
          <div className="p-2 bg-primary/10 rounded-full mr-4" aria-hidden="true">
            {icon}
          </div>
          <h3 className="font-semibold text-lg text-card-foreground">{title}</h3>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </motion.div>
    );

    const LanguageSelector = () => {
        const { t, i18n } = useTranslation();
        const [rememberLanguage, setRememberLanguage] = useState(true);
        const [showSelector, setShowSelector] = useState(false);

        useEffect(() => {
            const storedLang = localStorage.getItem('i18nextLng');
            if (!storedLang) {
                setShowSelector(true);
            }
        }, []);

        const changeLanguage = (lng) => {
            i18n.changeLanguage(lng);
            if (rememberLanguage) {
                localStorage.setItem('i18nextLng', lng);
            } else {
                localStorage.removeItem('i18nextLng');
            }
            setShowSelector(false);
        };
        
        if (!showSelector) return null;

        return (
            <motion.div
                className="fixed bottom-4 right-4 bg-background border border-border p-4 rounded-lg shadow-xl z-50 w-80"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                role="dialog"
                aria-label="Language Selection"
            >
                <div className="flex items-center mb-3">
                    <Languages className="w-5 h-5 mr-2 text-primary" aria-hidden="true" />
                    <h2 className="font-semibold text-foreground">{t('landingPage.languageSelector.title')}</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-4">{t('landingPage.languageSelector.description')}</p>
                <div className="flex gap-2 mb-4">
                    <Button onClick={() => changeLanguage('en')} variant={i18n.language === 'en' ? 'default' : 'outline'} className="flex-1">English</Button>
                    <Button onClick={() => changeLanguage('fr')} variant={i18n.language === 'fr' ? 'default' : 'outline'} className="flex-1">Français</Button>
                </div>
                <div className="flex items-center space-x-2">
                    <Checkbox 
                        id="remember-language" 
                        checked={rememberLanguage}
                        onCheckedChange={setRememberLanguage}
                    />
                    <label
                        htmlFor="remember-language"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                        {t('landingPage.languageSelector.remember')}
                    </label>
                </div>
            </motion.div>
        );
    }
    
    const GetStartedDialog = () => {
        const navigate = useNavigate();

        const ActionCard = ({ icon, title, description, onClick }) => (
            <Button 
                variant="outline" 
                className="h-auto py-4 px-4 flex items-center justify-start gap-4 w-full hover:border-primary transition-colors group whitespace-normal text-left" 
                onClick={onClick}
            >
                <div className="p-3 bg-muted rounded-full group-hover:bg-primary/10 transition-colors shrink-0" aria-hidden="true">
                    {icon}
                </div>
                <div>
                    <h4 className="font-semibold text-foreground text-base">{title}</h4>
                    <p className="text-sm text-muted-foreground font-normal">{description}</p>
                </div>
            </Button>
        );

        return (
             <Dialog>
                <DialogTrigger asChild>
                    <Button
                      className="group flex items-center justify-center px-8 py-4 bg-primary text-primary-foreground font-bold text-lg rounded-full transition-all duration-300 ease-in-out hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 transform hover:-translate-y-1"
                    >
                      Get Started <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" aria-hidden="true"/>
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>How are you joining us?</DialogTitle>
                        <DialogDescription>
                            Select one of the options below to get started.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="flex flex-col gap-4 py-4">
                       <ActionCard 
                            icon={<FileText className="w-6 h-6 text-primary"/>}
                            title="I'm a participant"
                            description="I have a link or code for an interview or survey."
                            onClick={() => navigate('/interview/start/token-entry')}
                       />
                        <ActionCard 
                            icon={<UserCheck className="w-6 h-6 text-primary"/>}
                            title="I have a team invitation"
                            description="I was invited to join an organization as a team member."
                             onClick={() => navigate('/auth')}
                       />
                       <ActionCard 
                            icon={<UserPlus className="w-6 h-6 text-primary"/>}
                            title="I'm new here"
                            description="Sign up to create your own organization and start interviewing."
                             onClick={() => navigate('/auth')}
                       />
                    </div>
                </DialogContent>
            </Dialog>
        );
    }

    const LandingPage = () => {
      const { t } = useTranslation();

      return (
        <>
          <Helmet>
            <title>{t('landingPage.meta.title')}</title>
            <meta name="description" content={t('landingPage.meta.description')} />
          </Helmet>
          <div className="min-h-screen flex flex-col bg-background text-foreground">
            <main className="flex-grow flex flex-col items-center justify-center text-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, ease: [0.25, 1, 0.5, 1] }}
              >
                <Logo className="h-20 md:h-24 w-auto mx-auto" aria-hidden="true" />
                <span className="sr-only">Intervu.video Logo</span>
              </motion.div>

              <motion.h1 
                className="mt-8 text-4xl md:text-6xl font-extrabold tracking-tight text-foreground"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                {t('landingPage.title')}
              </motion.h1>

              <motion.p 
                className="mt-4 max-w-2xl text-lg md:text-xl text-muted-foreground"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                {t('landingPage.subtitle')}
              </motion.p>

              <motion.div 
                className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <GetStartedDialog />
                <Button
                  asChild
                  variant="outline"
                  className="group flex items-center justify-center px-8 py-4 text-lg rounded-full transition-all duration-300 h-auto"
                >
                  <Link to="/demo/dashboard">
                    <Eye className="w-5 h-5 mr-2" aria-hidden="true" /> Live Demo
                  </Link>
                </Button>
              </motion.div>

              <div className="mt-20 max-w-5xl w-full grid md:grid-cols-3 gap-8">
                <FeatureCard 
                  icon={<Video className="text-primary w-6 h-6" />}
                  title={t('landingPage.features.video.title')}
                  description={t('landingPage.features.video.description')}
                  delay={0.8}
                />
                <FeatureCard 
                  icon={<CheckCircle className="text-primary w-6 h-6" />}
                  title={t('landingPage.features.standardized.title')}
                  description={t('landingPage.features.standardized.description')}
                  delay={0.9}
                />
                <FeatureCard 
                  icon={<Users className="text-primary w-6 h-6" />}
                  title={t('landingPage.features.collaborative.title')}
                  description={t('landingPage.features.collaborative.description')}
                  delay={1.0}
                />
              </div>
            </main>
            <LanguageSelector />
          </div>
        </>
      );
    };

    export default LandingPage;