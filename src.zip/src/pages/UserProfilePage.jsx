import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { User, Building, Save, Loader2, Edit3, PlusCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import CreateOrganizationDialog from '@/components/organization/CreateOrganizationDialog';

const UserProfilePage = () => {
  const { userProfile, refreshUserProfile, activeOrganization, loading: authLoading } = useAuth();
  const { toast } = useToast();

  const [isEditing, setIsEditing] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [isCreateOrgOpen, setIsCreateOrgOpen] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    avatarUrl: '',
    orgName: '',
    title: '',
  });

  const activeMembership = userProfile?.team_memberships?.find(
    (m) => m.organization_id === activeOrganization?.id
  );

  useEffect(() => {
    if (userProfile) {
      setFormData({
        fullName: userProfile.full_name || '',
        avatarUrl: userProfile.avatar_url || '',
        orgName: activeOrganization?.name || '',
        title: activeMembership?.title || '',
      });
    }
  }, [userProfile, activeOrganization, activeMembership]);

  const handleProfileUpdate = async () => {
    try {
      const { error: usersError } = await supabase
        .from('users')
        .update({ full_name: formData.fullName, avatar_url: formData.avatarUrl, updated_at: new Date() })
        .eq('id', userProfile.id);
      if (usersError) throw usersError;

      const { error: authError } = await supabase.auth.updateUser({
        data: { full_name: formData.fullName, avatar_url: formData.avatarUrl }
      });
      if (authError) throw authError;

      return true;
    } catch (error) {
      toast({ variant: 'destructive', title: 'Profile Update Failed', description: error.message });
      return false;
    }
  };

  const handleOrgUpdate = async () => {
    if (!activeOrganization || !activeMembership) return true;
    try {
      const { error: orgError } = await supabase
        .from('organizations')
        .update({ name: formData.orgName, updated_at: new Date() })
        .eq('id', activeOrganization.id);
      if (orgError) throw orgError;

      const { error: memberError } = await supabase
        .from('team_members')
        .update({ title: formData.title, updated_at: new Date() })
        .eq('id', activeMembership.team_member_id);
      if (memberError) throw memberError;

      return true;
    } catch (error) {
      toast({ variant: 'destructive', title: 'Organization Update Failed', description: error.message });
      return false;
    }
  };

  const handleSaveAll = async (e) => {
    e.preventDefault();
    setUpdating(true);

    const profileSuccess = await handleProfileUpdate();
    const orgSuccess = await handleOrgUpdate();

    if (profileSuccess && orgSuccess) {
      await refreshUserProfile();
      toast({ title: 'Success!', description: 'All changes have been saved.' });
      setIsEditing(false);
    }
    
    setUpdating(false);
  };

  if (authLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8"
      >
        <motion.div variants={itemVariants} className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-primary">Manage Profile</h1>
          {!isEditing && (
              <Button onClick={() => setIsEditing(true)}>
                  <Edit3 className="mr-2 h-4 w-4" /> Edit
              </Button>
          )}
        </motion.div>

        <motion.div variants={itemVariants}>
          <form onSubmit={handleSaveAll}>
            <Card className="bg-background/80 border-border shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center"><User className="mr-3" /> Personal Information</CardTitle>
                <CardDescription>This information is consistent across all your organizations.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <img src={formData.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.fullName)}&background=random`} alt="User Avatar" className="w-16 h-16 rounded-full object-cover border-2 border-primary" />
                  <div className="w-full space-y-1">
                    <Label htmlFor="avatarUrl">Avatar URL</Label>
                    <Input id="avatarUrl" type="text" value={formData.avatarUrl} onChange={(e) => setFormData({...formData, avatarUrl: e.target.value})} placeholder="https://example.com/avatar.png" disabled={!isEditing}/>
                  </div>
                </div>
                <div>
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" type="text" value={formData.fullName} onChange={(e) => setFormData({...formData, fullName: e.target.value})} disabled={!isEditing}/>
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={userProfile?.id} disabled />
                </div>
              </CardContent>
            </Card>
          </form>
        </motion.div>

        {activeOrganization ? (
          <motion.div variants={itemVariants}>
            <form onSubmit={handleSaveAll}>
              <Card className="bg-background/80 border-border shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center"><Building className="mr-3" /> Organization Information</CardTitle>
                  <CardDescription>This information is specific to <strong>{activeOrganization.name}</strong>.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="orgName">Organization Name</Label>
                    <Input id="orgName" type="text" value={formData.orgName} onChange={(e) => setFormData({...formData, orgName: e.target.value})} disabled={!isEditing}/>
                  </div>
                  <div>
                    <Label htmlFor="title">Your Title</Label>
                    <Input id="title" type="text" value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} placeholder="e.g., Senior Recruiter" disabled={!isEditing}/>
                  </div>
                </CardContent>
              </Card>
            </form>
          </motion.div>
        ) : (
          <motion.div variants={itemVariants}>
            <Card className="text-center bg-background/80 border-border border-dashed shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center justify-center"><Building className="mr-3"/>Join or Create an Organization</CardTitle>
                <CardDescription>You're not part of any organization yet. Create one to get started!</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={() => setIsCreateOrgOpen(true)}>
                  <PlusCircle className="mr-2 h-4 w-4" /> Create New Organization
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
        
        {isEditing && (
            <motion.div variants={itemVariants} className="flex justify-end space-x-3 pt-4 border-t border-border/20">
                <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                <Button onClick={handleSaveAll} disabled={updating}>
                    {updating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                    Save All Changes
                </Button>
            </motion.div>
        )}
      </motion.div>
      <CreateOrganizationDialog isOpen={isCreateOrgOpen} setIsOpen={setIsCreateOrgOpen} />
    </>
  );
};

export default UserProfilePage;