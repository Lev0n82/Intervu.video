import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import Logo from '@/components/Logo';
import { Loader2 } from 'lucide-react';

const AcceptInvitationPage = () => {
  const { token } = useParams();
  const { session, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [status, setStatus] = useState('loading');
  const [message, setMessage] = useState('Verifying your invitation...');

  const handleAcceptInvitation = useCallback(async () => {
    setStatus('loading');
    setMessage('Accepting your invitation...');
    const { data, error } = await supabase.rpc('accept_team_invitation', {
      invitation_token: token,
    });

    if (error) {
      const errorMessage = `Failed to accept invitation: ${error.message}`;
      setStatus('error');
      setMessage(errorMessage);
      toast({ variant: 'destructive', title: 'Error', description: errorMessage });
    } else if (data && !data.success) {
      const errorMessage = `Failed to accept invitation: ${data.message}`;
      setStatus('error');
      setMessage(errorMessage);
      toast({ variant: 'destructive', title: 'Error', description: errorMessage });
    } else {
      setStatus('success');
      setMessage('Invitation accepted! Redirecting you to your team dashboard...');
      toast({ title: 'Success!', description: 'You have successfully joined the team.' });
      setTimeout(() => navigate('/dashboard'), 2000);
    }
  }, [token, toast, navigate]);

  useEffect(() => {
    if (!authLoading) {
      if (!session) {
        setStatus('requires_auth');
        setMessage('You need to sign in or create an account to accept this invitation.');
        localStorage.setItem('postAuthRedirect', `/accept-invitation/${token}`);
      } else {
        handleAcceptInvitation();
      }
    }
  }, [token, session, authLoading, navigate, handleAcceptInvitation]);
  
  const renderContent = () => {
    switch (status) {
      case 'loading':
        return (
          <>
            <CardTitle>Processing Invitation</CardTitle>
            <CardDescription>{message}</CardDescription>
            <CardContent className="flex justify-center items-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary"/>
            </CardContent>
          </>
        );
      case 'requires_auth':
        return (
          <>
            <CardTitle>Invitation to Join Team</CardTitle>
            <CardDescription>{message}</CardDescription>
            <CardFooter className="flex justify-center pt-4">
              <Button asChild>
                <Link to="/auth">Sign In or Sign Up</Link>
              </Button>
            </CardFooter>
          </>
        );
      case 'success':
        return (
          <>
            <CardTitle>Success!</CardTitle>
            <CardDescription>{message}</CardDescription>
            <CardContent className="flex justify-center items-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary"/>
            </CardContent>
          </>
        );
      case 'error':
        return (
          <>
            <CardTitle>Invitation Error</CardTitle>
            <CardDescription>{message}</CardDescription>
            <CardFooter className="flex justify-center pt-4">
               <Button onClick={() => navigate('/dashboard')}>Go to Dashboard</Button>
            </CardFooter>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4">
       <div className="absolute top-8">
         <Logo />
       </div>
       <Card className="w-full max-w-md">
        <CardHeader className="text-center">
            {renderContent()}
        </CardHeader>
       </Card>
    </div>
  );
};

export default AcceptInvitationPage;