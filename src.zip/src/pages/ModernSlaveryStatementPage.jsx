import React from 'react';
import { motion } from 'framer-motion';
import { Hand, Users, Link as LinkIcon, Building, Search } from 'lucide-react';

const StatementSection = ({ icon, title, children }) => (
  <motion.div 
    className="flex items-start space-x-4 p-6 bg-card rounded-xl border border-border shadow-sm"
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true, amount: 0.5 }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
      {React.cloneElement(icon, { className: "w-6 h-6 text-primary" })}
    </div>
    <div>
      <h3 className="text-xl font-semibold text-card-foreground mb-2">{title}</h3>
      <div className="text-muted-foreground space-y-2">{children}</div>
    </div>
  </motion.div>
);

const ModernSlaveryStatementPage = () => {
  return (
    <div className="container mx-auto max-w-4xl py-12 sm:py-16 px-4">
      <motion.header 
        className="text-center mb-12"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Hand className="w-16 h-16 mx-auto text-primary mb-4" />
        <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight">
          Modern Slavery Statement
        </h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          This statement is made pursuant to section 54(1) of the Modern Slavery Act 2015 and constitutes our slavery and human trafficking statement for the current financial year.
        </p>
      </motion.header>

      <div className="space-y-8">
        <StatementSection title="Our Commitment" icon={<Hand />}>
          <p>intervu.video is committed to preventing acts of modern slavery and human trafficking from occurring within its business and supply chain. We believe in acting ethically and with integrity in all our business relationships.</p>
        </StatementSection>

        <StatementSection title="Our Business & Supply Chains" icon={<Building />}>
          <p>As a software-as-a-service (SaaS) provider, our business operations are primarily digital. Our supply chain is relatively simple and consists mainly of technology service providers (e.g., cloud hosting, software tools) and professional services (e.g., legal, accounting).</p>
          <p>We consider our direct operations to be low risk, but we remain vigilant about the risks that may exist in our wider supply chain.</p>
        </StatementSection>

        <StatementSection title="Due Diligence & Risk Assessment" icon={<Search />}>
          <p>We conduct due diligence on our key suppliers to ensure they share our commitment to human rights and ethical practices. This includes:</p>
          <ul className="list-disc list-inside pl-4">
            <li>Reviewing suppliers' own modern slavery statements and policies.</li>
            <li>Prioritizing partnerships with reputable, global technology companies that have robust ethical frameworks.</li>
            <li>Including anti-slavery and human trafficking clauses in our supplier contracts where appropriate.</li>
          </ul>
        </StatementSection>

        <StatementSection title="Our Policies" icon={<Users />}>
          <p>We have implemented internal policies to ensure we are conducting business in an ethical and transparent manner. This includes our employee code of conduct, which sets out the standards we expect from our team.</p>
        </StatementSection>

        <StatementSection title="Training & Awareness" icon={<LinkIcon />}>
          <p>We are committed to raising awareness among our staff about the risks of modern slavery. Relevant employees receive training on this policy and are encouraged to report any concerns without fear of retaliation.</p>
        </StatementSection>
      </div>

      <motion.footer 
        className="mt-16 text-center text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <p>This statement has been approved by our leadership team and will be reviewed and updated annually.</p>
        <p>Last updated: {new Date().toLocaleDateString()}.</p>
      </motion.footer>
    </div>
  );
};

export default ModernSlaveryStatementPage;