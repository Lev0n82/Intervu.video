import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Globe, Check } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const LanguageSelector = () => {
  const { i18n, t } = useTranslation();
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [rememberChoice, setRememberChoice] = useState(true);

  const languages = [
    { code: 'en', name: t('landingPage.languageSelector.english') },
    { code: 'fr', name: t('landingPage.languageSelector.french') },
    { code: 'fr-CA', name: t('landingPage.languageSelector.french_ca') },
  ];

  useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    if (rememberChoice) {
      localStorage.setItem('i18nextLng', lng);
    }
    navigate('/');
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-background p-4"
    >
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit">
            <Globe className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold mt-4">{t('landingPage.languageSelector.title')}</CardTitle>
          <CardDescription>{t('landingPage.languageSelector.description')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            {languages.map((lang) => (
              <Button
                key={lang.code}
                variant="outline"
                className="w-full justify-start text-lg py-6"
                onClick={() => changeLanguage(lang.code)}
              >
                {lang.name}
              </Button>
            ))}
          </div>
          <div className="flex items-center space-x-2 pt-2">
            <motion.div
              className="w-5 h-5 rounded-sm border-2 border-primary flex items-center justify-center cursor-pointer"
              onClick={() => setRememberChoice(!rememberChoice)}
              whileTap={{ scale: 0.9 }}
            >
              {rememberChoice && <Check className="w-4 h-4 text-primary" />}
            </motion.div>
            <label
              htmlFor="remember-choice"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              onClick={() => setRememberChoice(!rememberChoice)}
            >
              {t('landingPage.languageSelector.remember')}
            </label>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default LanguageSelector;