
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PlusCircle, Save, Video, Loader2, FileUp } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import VideoSurveyQuestion from '@/components/VideoSurveyQuestion';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import VideoRecorder from '@/components/VideoRecorder';
import AIGenerationDialog from '@/components/interview/AIGenerationDialog';
import { useVideoGeneration } from '@/hooks/useVideoGeneration';
import logger from '@/lib/logger';

const EditVideoSurveyPage = () => {
  const { surveyId } = useParams();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeSubmitType, setActiveSubmitType] = useState(null);
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [isAiDialogOpen, setIsAiDialogOpen] = useState(false);
  const [activeQuestionId, setActiveQuestionId] = useState(null);
  const [activeVideoField, setActiveVideoField] = useState(null);
  const [personas, setPersonas] = useState([]); 
  const fileInputRef = React.useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  const [savingForAI, setSavingForAI] = useState(false);
  
  const { activeOrganization, user } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleGenerationComplete = useCallback((questionId, field, url) => {
    setQuestions(currentQuestions => 
        currentQuestions.map(q => q.id === questionId ? { ...q, [field]: url } : q)
    );
    toast({ title: "Video Generated", description: "Your AI video is ready!" });
  }, [toast]);

  const { generations, startGeneration } = useVideoGeneration(activeOrganization?.id, handleGenerationComplete);

  useEffect(() => {
    const fetchSurvey = async () => {
      if (!surveyId || !activeOrganization) return;
      setLoading(true);
      try {
        const { data: surveyData, error: surveyError } = await supabase
          .from('surveys')
          .select('*, survey_questions(*)')
          .eq('id', surveyId)
          .single();

        if (surveyError) throw surveyError;
        if (surveyData.survey_type !== 'video') {
            toast({ title: "Wrong Editor", description: "You are trying to edit a text survey with the wrong editor.", variant: "destructive" });
            navigate(isDemo ? '/demo/surveys' : '/surveys');
            return;
        }

        setTitle(surveyData.title);
        setDescription(surveyData.description);
        setQuestions(surveyData.survey_questions.sort((a, b) => a.sequence_order - b.sequence_order).map(q => ({
          id: q.id,
          question_text: q.question_text || '',
          question_video_url: q.question_video_url,
          clarification_video_url: q.clarification_video_url,
        })));
      } catch (error) {
        toast({ title: 'Error fetching survey', description: error.message, variant: 'destructive' });
        navigate(isDemo ? '/demo/surveys' : '/surveys');
      } finally {
        setLoading(false);
      }
    };
    fetchSurvey();
  }, [surveyId, toast, navigate, isDemo, activeOrganization]);

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: `temp-${Date.now()}`, question_text: '', question_video_url: null, clarification_video_url: null }]);
  };

  const handleQuestionChange = (id, field, value) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, [field]: value } : q));
  };

  const handleRemoveQuestion = (id) => {
    if (questions.length <= 1) {
      toast({ title: "Minimum Questions", description: "A survey must have at least one question.", variant: "destructive" });
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
  };

  const openRecorder = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    setIsRecorderOpen(true);
  };
  
  const handleUploadClick = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    fileInputRef.current.click();
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    const fileName = `template-videos/video-${Date.now()}-${file.name}`;
    try {
        const { data, error } = await supabase.storage.from('template-videos').upload(fileName, file);
        if (error) throw error;
        const { data: { publicUrl } } = supabase.storage.from('template-videos').getPublicUrl(data.path);
        
        // Pass the url to completion handler manually since this isn't via recorder
        if (activeQuestionId && activeVideoField) {
           handleQuestionChange(activeQuestionId, activeVideoField, publicUrl);
        }
        
        toast({ title: "Upload Complete!", description: "Your video has been saved." });
    } catch (error) {
        toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
    } finally {
        setIsUploading(false);
        event.target.value = '';
    }
  };

  const handleRecorderUploadComplete = (data) => {
    if (activeQuestionId && activeVideoField) {
      handleQuestionChange(activeQuestionId, activeVideoField, data.url);
    }
    setIsRecorderOpen(false);
    setActiveQuestionId(null);
    setActiveVideoField(null);
  };
  
  const openAiGenerator = (questionId, videoField) => {
      setActiveQuestionId(questionId);
      setActiveVideoField(videoField);
      setIsAiDialogOpen(true);
  };
  
  const handleStartGeneration = async (prompt, personaId, options = {}) => {
    if (promptSave()) return;
    
    if (!activeOrganization?.id || !user?.id) {
        toast({ title: "Error", description: "Cannot start AI generation. Missing context.", variant: "destructive" });
        return;
    }
    
    // Explicit validation based on provider
    const provider = options.provider || 'luma';
    let isValid = false, error = '';

    if (provider === 'fallai') {
        const res = await import('@/lib/fallaiConfig').then(m => m.validateFallaiPayload({ prompt, ...options }));
        isValid = res.isValid;
        error = res.error;
    } else {
        const res = await import('@/lib/lumaApiConfig').then(m => m.validateLumaPayload(prompt));
        isValid = res.isValid;
        error = res.error;
    }

    if (!isValid) {
         toast({ title: "Validation Error", description: error, variant: "destructive" });
         return;
    }

    setSavingForAI(true);
    setIsAiDialogOpen(false);
    
    logger.video.request(prompt, { 
        context: 'EditVideoSurveyPage',
        activeQuestionId, 
        activeVideoField,
        provider
    });

    try {
        await startGeneration(
            activeQuestionId, 
            activeVideoField, 
            prompt, 
            user.id, 
            null,
            personaId, // This might be null for surveys if persona not supported in same way yet
            options
        );
        toast({ title: "AI Generation Queued", description: `Your video is being generated by ${provider === 'fallai' ? 'Fall.ai' : 'Luma'}.` });
    } catch (err) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
        setSavingForAI(false);
    }
  };
  
  const handleUpdate = async (submitType) => {
    if (promptSave()) return;
    setActiveSubmitType(submitType);
    setIsSubmitting(true);
    
    if (!title.trim()) {
      toast({ title: 'Validation Error', description: 'Survey title is required.', variant: 'destructive' });
      setIsSubmitting(false);
      return;
    }
    
    if (submitType === 'activate') {
        if (questions.some(q => !q.question_text || !q.question_text.trim())) {
            toast({ title: 'Validation Error', description: 'All questions must have summary text to activate.', variant: 'destructive' });
            setIsSubmitting(false);
            setActiveSubmitType(null);
            return;
        }
        if (questions.some(q => !q.question_video_url)) {
            toast({ title: 'Validation Error', description: 'To activate, all questions must have a recorded question video.', variant: 'destructive' });
            setIsSubmitting(false);
            setActiveSubmitType(null);
            return;
        }
    }

    try {
      const { error: surveyError } = await supabase
        .from('surveys')
        .update({
          title,
          description,
          status: submitType === 'activate' ? 'active' : 'draft',
          updated_at: new Date().toISOString(),
        })
        .eq('id', surveyId);

      if (surveyError) throw surveyError;

      // Ensure all questions have valid UUIDs (generate for new 'temp-' ones)
      const preparedQuestions = questions.map(q => {
          if (String(q.id).startsWith('temp-')) {
              console.log("Generating UUID for new question:", q.question_text);
              return { ...q, id: crypto.randomUUID() };
          }
          return q;
      });

      const questionUpserts = preparedQuestions.map((q, index) => {
        if (!q.id) {
             console.error("Null ID detected during save:", q);
             throw new Error("Cannot save question with null ID");
        }
        return {
            id: q.id,
            survey_id: surveyId,
            question_text: q.question_text ? q.question_text.trim() : '',
            question_type: 'video',
            sequence_order: index + 1,
            is_required: true,
            question_video_url: q.question_video_url,
            clarification_video_url: q.clarification_video_url,
        };
      });
      
      console.log("Upserting survey questions:", questionUpserts.length);
      const { error: questionsError } = await supabase.from('survey_questions').upsert(questionUpserts);

      if (questionsError) throw questionsError;

      // Update local state with real IDs to prevent duplicates on next save
      setQuestions(preparedQuestions);

      toast({ title: 'Survey Updated!', description: 'Your changes have been saved successfully.' });
      navigate(isDemo ? '/demo/surveys' : '/surveys');

    } catch (error) {
        console.error("Survey Update Error:", error);
        let msg = error.message;
        if (error.code === '23505') msg = "A survey with this name already exists in your organization.";
        if (msg.includes("null value in column id")) msg = "System Error: Failed to generate question ID. Please try again.";
        toast({ title: 'Error Updating Survey', description: msg, variant: 'destructive' });
    } finally {
        setIsSubmitting(false);
        setActiveSubmitType(null);
    }
  };
  
  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8"
      >
        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-primary text-2xl">
                <Video className="w-6 h-6 mr-3" aria-hidden="true"/>
                Edit Video Survey
              </CardTitle>
              <CardDescription>Modify your existing video-based survey.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="surveyTitle">Survey Title</Label>
                <Input id="surveyTitle" value={title} onChange={(e) => setTitle(e.target.value)} required className="mt-1" disabled={isSubmitting}/>
              </div>
              <div>
                <Label htmlFor="surveyDescription">Description (Optional)</Label>
                <Textarea id="surveyDescription" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 min-h-[80px]" disabled={isSubmitting}/>
              </div>
            </CardContent>
          </Card>

          <Card>
              <CardHeader>
                  <CardTitle>Survey Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                   {questions.map((q, index) => (
                      <VideoSurveyQuestion
                        key={q.id} question={q} index={index} onQuestionChange={handleQuestionChange}
                        onRemoveQuestion={handleRemoveQuestion} onRecordVideo={openRecorder}
                        onUploadVideo={handleUploadClick} onGenerateVideo={openAiGenerator}
                        disabled={isSubmitting || isUploading || savingForAI}
                        generationStatus={{
                            'question_video_url': generations[`${q.id}-question_video_url`],
                            'clarification_video_url': generations[`${q.id}-clarification_video_url`]
                        }}
                      />
                    ))}
                    <Button type="button" variant="outline" onClick={handleAddQuestion} className="w-full border-dashed" disabled={isSubmitting || isUploading}>
                      <PlusCircle className="w-5 h-5 mr-2" aria-hidden="true" /> Add Question
                    </Button>
              </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline" onClick={() => navigate(isDemo ? '/demo/surveys' : '/surveys')} disabled={isSubmitting}>Cancel</Button>
            <Button type="button" variant="secondary" onClick={() => handleUpdate('draft')} disabled={isSubmitting}>
              {isSubmitting && activeSubmitType === 'draft' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
              Save as Draft
            </Button>
            <Button type="button" onClick={() => handleUpdate('activate')} disabled={isSubmitting}>
              {isSubmitting && activeSubmitType === 'activate' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <FileUp className="w-5 h-5 mr-2" />}
              Save & Activate
            </Button>
          </div>
        </form>
      </motion.div>
      <VideoRecorder 
        open={isRecorderOpen} 
        onOpenChange={setIsRecorderOpen} 
        onUploadComplete={handleRecorderUploadComplete} 
      />
       <AIGenerationDialog
          open={isAiDialogOpen} onOpenChange={setIsAiDialogOpen} onStartGeneration={handleStartGeneration}
          questionText={questions.find(q => q.id === activeQuestionId)?.question_text || ''}
          personaId={null} personas={personas}
       />
       <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="video/*" disabled={isUploading}/>
    </>
  );
};

export default EditVideoSurveyPage;
