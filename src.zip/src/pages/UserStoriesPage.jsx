
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import { Users } from 'lucide-react';
// eslint-disable-next-line import/no-unresolved
import staticUserStories from '../../UserStories.md?raw';

const UserStoriesPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto p-4 sm:p-6 lg:p-8"
    >
      <div className="bg-slate-800/50 backdrop-blur-lg p-6 sm:p-8 rounded-2xl shadow-2xl border border-slate-700">
        <header className="flex items-center justify-between mb-6 pb-4 border-b border-slate-700 flex-wrap gap-4">
          <div className="flex items-center">
            <Users className="w-8 h-8 text-cyan-400 mr-4" />
            <h1 className="text-2xl sm:text-3xl font-bold text-cyan-400 tracking-tight">User Stories</h1>
          </div>
          <p className="text-slate-400 italic text-sm">Use scenarios for different roles</p>
        </header>

        <article className="prose prose-invert prose-sm sm:prose-base max-w-none 
          prose-headings:text-cyan-400 prose-h1:text-2xl prose-h2:text-xl prose-h3:text-lg
          prose-a:text-cyan-400 hover:prose-a:text-cyan-300
          prose-strong:text-slate-100
          prose-blockquote:border-cyan-500 prose-blockquote:text-slate-300
          prose-code:bg-slate-700 prose-code:text-cyan-300 prose-code:p-1 prose-code:rounded-md
          prose-ul:list-disc prose-li:marker:text-cyan-400
          prose-table:border-slate-600 prose-th:bg-slate-700 prose-th:text-slate-100 prose-tr:border-slate-600">
          <ReactMarkdown>{staticUserStories}</ReactMarkdown>
        </article>
      </div>
    </motion.div>
  );
};

export default UserStoriesPage;
