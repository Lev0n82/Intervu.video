import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import VideoProfileBuilder from '@/components/candidate/VideoProfileBuilder';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Calendar, CheckCircle2, AlertCircle } from 'lucide-react';

const CandidateDashboardPage = () => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const userName = userProfile?.full_name || 'Candidate';

  // Variants for stagger animation
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const handleViewPastInterviews = () => {
    toast({
      title: "Coming Soon",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Dashboard - Candidate Portal | intervu.video</title>
        <meta name="description" content="Manage your video profile and upcoming interviews." />
      </Helmet>
      
      <div className="min-h-screen bg-background pb-20">
        {/* Hero Welcome Section */}
        <div className="bg-primary/5 border-b border-border">
            <div className="container mx-auto px-4 py-12">
                <motion.div 
                    initial={{ opacity: 0, x: -20 }} 
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <h1 className="text-4xl font-extrabold tracking-tight text-primary mb-2">
                        Welcome back, {userName.split(' ')[0]}!
                    </h1>
                    <p className="text-xl text-muted-foreground max-w-2xl">
                        Your video profile is your digital handshake. Keep it updated to stand out to potential employers.
                    </p>
                </motion.div>
            </div>
        </div>

        <div className="container mx-auto px-4 py-8 space-y-8">
            
            {/* Main content area, currently VideoProfileBuilder */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <motion.div 
                    className="md:col-span-2"
                    variants={item}
                    initial="hidden"
                    animate="show"
                >
                    <VideoProfileBuilder />
                </motion.div>

                {/* Sidebar / Quick Actions */}
                <motion.div 
                    className="space-y-6"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center">
                                <Calendar className="w-5 h-5 mr-2 text-primary" /> Upcoming Interviews
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-sm text-muted-foreground text-center py-8 border border-dashed rounded-md bg-muted/20">
                                No interviews scheduled yet.
                            </div>
                            <Button variant="link" className="w-full mt-2 text-primary" onClick={handleViewPastInterviews}>View Past Interviews</Button>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center">
                                <AlertCircle className="w-5 h-5 mr-2 text-amber-500" /> Profile Tips
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex gap-3 items-start text-sm">
                                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                                <p>Record in a well-lit room facing a window for the best lighting.</p>
                            </div>
                            <div className="flex gap-3 items-start text-sm">
                                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                                <p>Keep your introduction under 60 seconds to maintain engagement.</p>
                            </div>
                            <div className="flex gap-3 items-start text-sm">
                                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                                <p>Use tags to highlight specific skills shown in your videos (e.g., "Communication", "React").</p>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
      </div>
    </>
  );
};

export default CandidateDashboardPage;