import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Loader2, Play, ShieldCheck, UserCheck, Clock } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import Logo from '@/components/Logo';

const InterviewStartPage = () => {
    const { submissionToken } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();

    const [submission, setSubmission] = useState(null);
    const [interview, setInterview] = useState(null);
    const [loading, setLoading] = useState(true);
    const [consentGiven, setConsentGiven] = useState(false);

    useEffect(() => {
        const fetchInterviewDetails = async () => {
            if (!submissionToken) {
                toast({ title: 'Invalid Link', description: 'The interview link is missing a token.', variant: 'destructive' });
                navigate('/landing');
                return;
            }

            setLoading(true);
            
            const { data: submissionData, error: submissionError } = await supabase
                .from('interview_submissions')
                .select('*, interviews(*, interview_templates(*))')
                .eq('submission_token', submissionToken)
                .single();

            if (submissionError || !submissionData) {
                toast({ title: 'Interview Not Found', description: 'The interview link is invalid or has expired.', variant: 'destructive' });
                navigate('/landing');
                return;
            }
            
            if (submissionData.status === 'completed') {
                toast({ title: 'Interview Already Completed', description: 'You have already submitted your responses for this interview.' });
                navigate('/landing');
                return;
            }

            setSubmission(submissionData);
            setInterview(submissionData.interviews);
            setLoading(false);
        };

        fetchInterviewDetails();
    }, [submissionToken, navigate, toast]);

    const handleStart = async () => {
        if (!consentGiven) {
            toast({ title: 'Consent Required', description: 'You must agree to the terms to proceed.', variant: 'destructive' });
            return;
        }
        
        try {
            const { error } = await supabase
                .from('interview_submissions')
                .update({ consent_given_at: new Date().toISOString() })
                .eq('id', submission.id);

            if (error) throw error;

            navigate(`/interview/check-device/${submission.id}`);

        } catch (error) {
            toast({ title: 'Error Saving Consent', description: error.message, variant: 'destructive' });
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-slate-100 p-4">
                <Loader2 className="w-12 h-12 animate-spin text-sky-400" />
                <p className="mt-4 text-lg">Loading your interview...</p>
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>Start Interview: {interview?.title}</title>
            </Helmet>
            <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-4">
                <div className="absolute top-8"><Logo /></div>
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="w-full max-w-2xl"
                >
                    <Card className="bg-slate-800 border-slate-700 shadow-2xl">
                        <CardHeader className="text-center">
                            <CardTitle className="text-3xl font-bold text-sky-400">
                                You're Invited to an Interview
                            </CardTitle>
                            <CardDescription className="text-slate-400 text-lg mt-2">
                                for the position of <span className="font-semibold text-slate-200">{interview?.title}</span>
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                                <div className="p-4 bg-slate-700/50 rounded-lg">
                                    <UserCheck className="w-8 h-8 mx-auto text-sky-400 mb-2" />
                                    <h3 className="font-semibold">One-Way Video</h3>
                                    <p className="text-xs text-slate-400">Record your answers at your own pace.</p>
                                </div>
                                <div className="p-4 bg-slate-700/50 rounded-lg">
                                    <Clock className="w-8 h-8 mx-auto text-sky-400 mb-2" />
                                    <h3 className="font-semibold">~{interview?.interview_templates?.questions?.length * 3 || 15} Minutes</h3>
                                    <p className="text-xs text-slate-400">Estimated completion time.</p>
                                </div>
                                <div className="p-4 bg-slate-700/50 rounded-lg">
                                    <ShieldCheck className="w-8 h-8 mx-auto text-sky-400 mb-2" />
                                    <h3 className="font-semibold">Private & Secure</h3>
                                    <p className="text-xs text-slate-400">Your responses are confidential.</p>
                                </div>
                            </div>

                            <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                                <h3 className="font-semibold text-slate-200 mb-2">Before you begin:</h3>
                                <ul className="list-disc list-inside text-slate-400 text-sm space-y-1">
                                    <li>Find a quiet, well-lit space.</li>
                                    <li>Ensure you have a stable internet connection.</li>
                                    <li>Use a device with a working camera and microphone.</li>
                                    <li>You will have time to review each question before recording.</li>
                                </ul>
                            </div>

                            <div className="flex items-start space-x-3 mt-4 p-4 rounded-md bg-slate-700/30">
                                <input
                                    type="checkbox"
                                    id="consent"
                                    checked={consentGiven}
                                    onChange={(e) => setConsentGiven(e.target.checked)}
                                    className="mt-1 h-4 w-4 rounded border-slate-500 text-sky-500 focus:ring-sky-500"
                                />
                                <label htmlFor="consent" className="text-sm text-slate-300">
                                    I consent to my video and audio being recorded and shared with the hiring team for evaluation purposes. I understand this data will be handled according to the privacy policy.
                                </label>
                            </div>
                        </CardContent>
                        <CardFooter>
                            <Button onClick={handleStart} disabled={!consentGiven} className="w-full text-lg py-6">
                                <Play className="mr-2 h-5 w-5" />
                                Let's Begin
                            </Button>
                        </CardFooter>
                    </Card>
                </motion.div>
            </div>
        </>
    );
};

export default InterviewStartPage;