import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart, FileText } from 'lucide-react';

const StateOfHiringReportPage = () => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: { y: 0, opacity: 1 },
    };

    const Section = ({ title, children, className }) => (
        <motion.section variants={itemVariants} className={`mb-10 ${className}`}>
            <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">{title}</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none text-muted-foreground space-y-4">
                {children}
            </div>
        </motion.section>
    );

    return (
        <>
            <Helmet>
                <title>The State of Hiring: 2025 Annual Report</title>
                <meta name="description" content="A comprehensive overview of the key trends shaping the recruitment landscape in 2025, including AI adoption, remote hiring, and the candidate experience." />
            </Helmet>
            <motion.div
                initial="hidden"
                animate="visible"
                variants={containerVariants}
                className="max-w-4xl mx-auto p-4 sm:p-6"
            >
                <motion.header variants={itemVariants} className="text-center mb-12">
                     <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-4 border border-primary/20">
                        <FileText className="w-10 h-10 text-primary" />
                    </div>
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight mb-3">The State of Hiring: 2025 Annual Report</h1>
                    <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto">
                        An in-depth look at the trends shaping recruitment, from AI integration to the global talent pool.
                    </p>
                </motion.header>

                <Section title="Introduction">
                    <p>
                        The world of work is in a constant state of flux, and the ways we attract, screen, and hire talent are evolving at a breakneck pace. As we move through 2025, several key trends are shaping the recruitment landscape, driven by technological innovation, shifting employee expectations, and a truly global talent pool. This report synthesizes the latest data and insights to provide a comprehensive overview of the state of hiring today.
                    </p>
                    <p>
                        For HR professionals and business leaders, understanding these trends is not just a matter of staying current—it's a strategic imperative for building a competitive and thriving workforce.
                    </p>
                </Section>
                
                <Section title="Trend 1: The Unstoppable Rise of AI in Recruitment">
                    <p>
                        Artificial intelligence is no longer a futuristic concept in HR; it's a reality. The adoption of AI in hiring has surged, with 72% of HR professionals now using AI-powered tools, a significant jump from 58% in 2024 [1]. This rapid integration is a direct response to one of the most persistent challenges in recruitment: inefficiency.
                    </p>
                    <p>
                        With 60% of companies reporting an increase in their time-to-hire [2], the need for automation has never been more acute. AI-powered platforms are stepping in to automate the most time-consuming aspects of the hiring process.
                    </p>
                     <Card className="bg-background my-6">
                        <CardContent className="p-0">
                           <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="font-bold">Area of Impact</TableHead>
                                        <TableHead className="font-bold">Key Statistic</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>Interview Scheduling</TableCell>
                                        <TableCell>Recruiters spend up to 35% of their time on manual scheduling. AI automates this, freeing up valuable time. [2]</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Candidate Screening</TableCell>
                                        <TableCell>AI can analyze thousands of applications and interviews to identify top candidates, reducing manual review time by hours.</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Data-Driven Decisions</TableCell>
                                        <TableCell>AI provides objective data points to support hiring decisions, helping to improve the quality of hire.</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                    <blockquote className="border-l-4 border-primary pl-4 italic text-muted-foreground">
                        "By automating time-consuming recruiting tasks, generative AI (GAI) is speeding up the hiring process, allowing recruiters to spend more time on strategic initiatives." - LinkedIn Talent Solutions [3]
                    </blockquote>
                    <p>
                       However, the rise of AI is not without its challenges. 65% of employers express concern that AI-generated resumes are contributing to an increase in underqualified candidates [2]. This highlights the importance of using AI not just for resume screening, but for more robust assessments like video interviews, where a candidate's true skills and communication abilities can be more accurately evaluated.
                    </p>
                </Section>
                
                <Section title="Trend 2: Remote and Global Hiring is the New Standard">
                    <p>
                        The pandemic may have been the catalyst, but remote and hybrid work models are now a permanent fixture of the employment landscape. This has fundamentally changed how companies think about talent pools, moving from a local to a global mindset.
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                        <li>73% of companies are increasing international hiring with a remote work model [2].</li>
                        <li>85% of employers have hired senior-level employees internationally in the past year [2].</li>
                    </ul>
                    <p>
                        This shift is a win-win. Companies gain access to a wider pool of talent, while employees gain the flexibility they desire. However, it also introduces new complexities, particularly around compliance and process standardization. 43% of employers report struggling with complying with international labor laws [2]. This underscores the need for hiring processes and platforms that are designed for global scale, ensuring consistency and fairness for every candidate, regardless of their location.
                    </p>
                </Section>
                
                <Section title="Trend 3: The Candidate Experience is King">
                     <p>
                        In a competitive talent market, a positive candidate experience is a powerful differentiator. Today's job seekers expect a process that is modern, flexible, and respectful of their time. The data shows that video interviewing is a key component of this experience. An overwhelming 93% of companies that adopted virtual interviews plan to continue using them [4]. This is not just for the employer's convenience; it also benefits the candidate.
                    </p>
                    <Card className="bg-background my-6">
                         <CardContent className="p-0">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="font-bold">Candidate Benefit</TableHead>
                                        <TableHead className="font-bold">Description</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell>Flexibility</TableCell>
                                        <TableCell>On-demand video interviews allow candidates to interview at a time that suits their schedule, reducing the stress of taking time off from their current job.</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Accessibility</TableCell>
                                        <TableCell>Candidates can interview from anywhere in the world, leveling the playing field for global talent.</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Transparency</TableCell>
                                        <TableCell>Modern platforms provide clear instructions and practice sessions, helping candidates feel prepared and confident.</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                         </CardContent>
                    </Card>
                </Section>
                
                <Section title="Looking Ahead: The Future is Skilled, Flexible, and AI-Powered">
                    <p>
                        The state of hiring in 2025 is defined by a powerful convergence of technology and human-centric principles. The companies that will win the war for talent are those that embrace this new reality.
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                        <li><strong>Skills-based hiring is the future.</strong> 94% of recruitment professionals believe that hiring for skills, rather than just experience or education, is the way forward [2].</li>
                        <li><strong>Flexibility is non-negotiable.</strong> The demand for remote and hybrid options will continue to shape the job market.</li>
                        <li><strong>AI is an essential co-pilot.</strong> Leveraging AI to automate processes and provide data-driven insights will be the key to hiring efficiently and effectively at scale.</li>
                    </ul>
                    <p>
                        As we look to the future, the challenge for HR leaders is to build a hiring strategy that is not only technologically advanced but also deeply human. The goal is to use technology to remove friction and bias, freeing up time to focus on what truly matters: building meaningful connections with the people who will drive your organization forward.
                    </p>
                </Section>

                <motion.footer variants={itemVariants} className="mt-12 pt-8 border-t border-border">
                    <h3 className="text-xl font-semibold mb-3">References</h3>
                    <ol className="list-decimal list-inside text-sm text-muted-foreground space-y-2">
                        <li>HireVue's 2025 AI Report. <a href="https://www.hirevue.com/press-release/hirevues-2025-ai-report-shows-the-majority-of-hr-leaders-trust-ai-hiring-decisions" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Link</a></li>
                        <li>SelectSoftware Reviews, 100+ Recruitment Statistics Every HR Should Know in 2025. <a href="https://www.selectsoftwarereviews.com/blog/recruiting-statistics" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Link</a></li>
                        <li>LinkedIn Talent Solutions, The Future of Recruiting 2025. <a href="https://business.linkedin.com/talent-solutions/resources/future-of-recruiting" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Link</a></li>
                        <li>LLCBuddy, Video Interviewing Statistics (2025). <a href="https://llcbuddy.com/data/video-interviewing-statistics/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Link</a></li>
                    </ol>
                </motion.footer>

            </motion.div>
        </>
    );
};

export default StateOfHiringReportPage;