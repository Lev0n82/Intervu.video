import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FilePlus2, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const TemplateSetupPage = () => {
    const { toast } = useToast();
    const navigate = useNavigate();

    const handleComingSoon = () => {
        toast({
            title: '🚧 Feature Under Construction',
            description: "The template builder is not yet implemented. You can request this feature in a future prompt! 🚀",
        });
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 sm:p-6"
        >
            <Card className="bg-background/80 border-border shadow-lg">
                <CardHeader>
                    <CardTitle className="text-primary flex items-center text-2xl">
                        <FilePlus2 className="mr-3 h-6 w-6" /> Create New Template
                    </CardTitle>
                    <CardDescription className="text-muted-foreground mt-1">
                        Build a reusable template for your interviews.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="text-center py-12 px-6 bg-secondary/50 rounded-lg border border-dashed border-border">
                        <h3 className="text-xl font-semibold text-foreground">Template Builder Coming Soon!</h3>
                        <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                            This is where you will be able to add questions, set time limits, and customize your interview templates.
                        </p>
                        <Button onClick={handleComingSoon} className="mt-6">
                            Notify Me When Ready
                        </Button>
                    </div>

                    <div className="mt-8 p-4 bg-yellow-900/20 border border-yellow-700/50 rounded-lg flex items-center">
                        <AlertTriangle className="h-6 w-6 text-yellow-400 mr-4 flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold text-yellow-300">Under Development</h4>
                            <p className="text-sm text-yellow-400/80">
                                We are actively working on the template creation tools. Thank you for your patience!
                            </p>
                        </div>
                    </div>
                     <Button variant="outline" className="mt-8" onClick={() => navigate(-1)}>
                        Go Back
                    </Button>
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default TemplateSetupPage;