import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import LoginForm from '@/pages/auth/LoginForm';
import SignUpForm from '@/pages/auth/SignUpForm';
import AuthFormHeader from '@/pages/auth/AuthFormHeader';
import { UserPlus, LogIn } from 'lucide-react';
import { Helmet } from 'react-helmet-async';

const AuthPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Derive active tab directly from URL, defaulting to 'login'
  // This eliminates the need for complex useEffect synchronization
  const currentTab = searchParams.get('tab') === 'signup' ? 'signup' : 'login';
  
  // Local state for success message interaction
  const [showVerificationMessage, setShowVerificationMessage] = useState(false);

  const handleTabChange = (value) => {
    // Update URL without reloading the page
    setSearchParams({ tab: value }, { replace: true });
  };

  return (
    <>
      <Helmet>
        <title>{currentTab === 'signup' ? 'Sign Up' : 'Sign In'} - intervu.video</title>
        <meta name="description" content="Sign in or create an account to access your intervu.video dashboard." />
      </Helmet>
      <div className="min-h-screen flex items-center justify-center bg-transparent p-4">
        <motion.div
          className="w-full max-w-md"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="bg-card/80 backdrop-blur-sm p-6 sm:p-8 rounded-xl shadow-2xl border border-border/20">
            <AuthFormHeader />

            {showVerificationMessage ? (
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 text-center bg-primary/10 border border-primary/20 p-4 rounded-lg"
                >
                    <h3 className="font-bold text-primary">Registration Successful!</h3>
                    <p className="text-foreground mt-2">Please check your email inbox to find the verification link and complete your sign-up.</p>
                    <Button 
                      variant="link"
                      onClick={() => {
                        setShowVerificationMessage(false);
                        handleTabChange('login');
                      }}
                      className="mt-4"
                    >
                      Back to Sign In
                    </Button>
                </motion.div>
            ) : (
                <Tabs value={currentTab} onValueChange={handleTabChange} className="w-full mt-6">
                  <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger 
                        value="login" 
                        className="flex items-center justify-center gap-2 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm"
                      >
                        <LogIn className="w-4 h-4" /> Sign In
                      </TabsTrigger>
                      <TabsTrigger 
                        value="signup" 
                        className="flex items-center justify-center gap-2 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm"
                      >
                        <UserPlus className="w-4 h-4" /> Sign Up
                      </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="login" className="mt-6 focus-visible:outline-none focus-visible:ring-0 animate-in fade-in slide-in-from-top-2 duration-300">
                      <LoginForm />
                      <div className="mt-6 text-center text-sm text-muted-foreground">
                        Don't have an account?{' '}
                        <button
                            onClick={() => handleTabChange('signup')}
                            className="font-semibold text-primary underline-offset-4 hover:underline focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 rounded px-1"
                            type="button"
                        >
                            Create an account
                        </button>
                      </div>
                  </TabsContent>
                  
                  <TabsContent value="signup" className="mt-6 focus-visible:outline-none focus-visible:ring-0 animate-in fade-in slide-in-from-top-2 duration-300">
                      <SignUpForm onSignUpSuccess={() => setShowVerificationMessage(true)} />
                      <div className="mt-6 text-center text-sm text-muted-foreground">
                        Already have an account?{' '}
                        <button
                            onClick={() => handleTabChange('login')}
                            className="font-semibold text-primary underline-offset-4 hover:underline focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 rounded px-1"
                            type="button"
                        >
                            Sign In
                        </button>
                      </div>
                  </TabsContent>
                </Tabs>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
};

// Simple button component for internal use if needed, otherwise standard HTML button above works fine
const Button = ({ className, variant, ...props }) => {
  return <button className={`text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 ${className}`} {...props} />
}

export default AuthPage;