import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { PlusCircle, Edit, Trash2, Loader2, Bot, Sparkles } from 'lucide-react';

const defaultPersonas = [
    { name: 'Alex', role_title: 'Lead Interviewer', avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=800' },
    { name: 'Jordan', role_title: 'Technical Screener', avatar_url: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=800' },
    { name: 'Taylor', role_title: 'HR Coordinator', avatar_url: 'https://images.unsplash.com/photo-1580894742597-87bc8789db3d?q=80&w=800' },
    { name: 'Casey', role_title: 'Hiring Manager', avatar_url: 'https://images.unsplash.com/photo-1611432579699-484f7990b127?q=80&w=800' },
];

const PersonaManagementPage = () => {
    const { activeOrganization, user } = useAuth();
    const { toast } = useToast();
    const [personas, setPersonas] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isAddingDefaults, setIsAddingDefaults] = useState(false);
    const [editingPersona, setEditingPersona] = useState(null);

    const fetchPersonas = useCallback(async () => {
        if (!activeOrganization?.id) return;
        setLoading(true);
        const { data, error } = await supabase
            .from('personas')
            .select('*')
            .eq('organization_id', activeOrganization.id)
            .order('created_at', { ascending: false });

        if (error) {
            toast({ title: 'Error fetching personas', description: error.message, variant: 'destructive' });
        } else {
            setPersonas(data);
        }
        setLoading(false);
    }, [activeOrganization, toast]);

    useEffect(() => {
        fetchPersonas();
    }, [fetchPersonas]);

    const handleAddDefaults = async () => {
        if (!activeOrganization?.id || !user?.id) return;
        setIsAddingDefaults(true);
        const personasToAdd = defaultPersonas.map(p => ({
            ...p,
            organization_id: activeOrganization.id,
            created_by: user.id,
        }));

        const { error } = await supabase.from('personas').insert(personasToAdd);
        if (error) {
            toast({ title: 'Error adding default personas', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Default Personas Added!', description: 'A set of friendly AI personas are ready to use.' });
            fetchPersonas();
        }
        setIsAddingDefaults(false);
    };

    const handleOpenDialog = (persona = null) => {
        setEditingPersona(persona);
        setIsDialogOpen(true);
    };

    const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setEditingPersona(null);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!activeOrganization?.id || !user?.id) return;

        setIsSubmitting(true);
        const formData = new FormData(event.target);
        const personaData = {
            name: formData.get('name'),
            role_title: formData.get('role_title'),
            avatar_url: formData.get('avatar_url'),
            organization_id: activeOrganization.id,
            created_by: user.id,
        };

        let error;
        if (editingPersona) {
            ({ error } = await supabase.from('personas').update(personaData).eq('id', editingPersona.id));
        } else {
            ({ error } = await supabase.from('personas').insert(personaData));
        }

        if (error) {
            toast({ title: `Error ${editingPersona ? 'updating' : 'creating'} persona`, description: error.message, variant: 'destructive' });
        } else {
            toast({ title: `Persona ${editingPersona ? 'Updated' : 'Created'}!`, description: `Successfully ${editingPersona ? 'saved' : 'created'} ${personaData.name}.` });
            handleCloseDialog();
            fetchPersonas();
        }
        setIsSubmitting(false);
    };

    const handleDelete = async (personaId) => {
        if (!window.confirm('Are you sure you want to delete this persona?')) return;
        const { error } = await supabase.from('personas').delete().eq('id', personaId);
        if (error) {
            toast({ title: 'Error deleting persona', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Persona Deleted' });
            fetchPersonas();
        }
    };

    return (
        <>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <Card>
                    <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                        <div>
                            <CardTitle className="text-primary flex items-center text-2xl">
                                <Bot className="mr-3 h-6 w-6" /> AI Persona Management
                            </CardTitle>
                            <CardDescription className="mt-1">
                                Create, edit, and manage the AI personas for your interviews.
                            </CardDescription>
                        </div>
                        <div className="flex gap-2 mt-3 sm:mt-0">
                            <Button onClick={handleAddDefaults} disabled={isAddingDefaults}>
                                {isAddingDefaults ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                                Add Defaults
                            </Button>
                            <Button onClick={() => handleOpenDialog()}>
                                <PlusCircle className="mr-2 h-4 w-4" /> Create Persona
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                            <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
                        ) : personas.length === 0 ? (
                            <div className="text-center py-12">
                                <p className="text-muted-foreground mb-4">No personas created yet. Get started by adding the defaults or creating your own.</p>
                            </div>
                        ) : (
                            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                                {personas.map(persona => (
                                    <Card key={persona.id} className="flex flex-col">
                                        <CardHeader className="flex-row items-center gap-4">
                                            <Avatar className="h-16 w-16">
                                                <AvatarImage src={persona.avatar_url} alt={persona.name} />
                                                <AvatarFallback>{persona.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <CardTitle>{persona.name}</CardTitle>
                                                <CardDescription>{persona.role_title}</CardDescription>
                                            </div>
                                        </CardHeader>
                                        <CardFooter className="mt-auto flex justify-end gap-2">
                                            <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(persona)}><Edit className="h-4 w-4" /></Button>
                                            <Button variant="ghost" size="icon" onClick={() => handleDelete(persona.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                        </CardFooter>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </motion.div>

            <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
                <DialogContent>
                    <form onSubmit={handleSubmit}>
                        <DialogHeader>
                            <DialogTitle>{editingPersona ? 'Edit' : 'Create'} Persona</DialogTitle>
                            <DialogDescription>
                                {editingPersona ? 'Update the details for this AI persona.' : 'Define a new AI persona for your interviews.'}
                            </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="name" className="text-right">Name</Label>
                                <Input id="name" name="name" defaultValue={editingPersona?.name} className="col-span-3" required />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="role_title" className="text-right">Role Title</Label>
                                <Input id="role_title" name="role_title" defaultValue={editingPersona?.role_title} className="col-span-3" required />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="avatar_url" className="text-right">Avatar URL</Label>
                                <Input id="avatar_url" name="avatar_url" type="url" defaultValue={editingPersona?.avatar_url} className="col-span-3" required />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {editingPersona ? 'Save Changes' : 'Create Persona'}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default PersonaManagementPage;