
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from '@/components/ui/use-toast';
import { Progress } from "@/components/ui/progress";
import { Loader2, CheckCircle2, Video, AlertCircle, Star, Upload, Trash2, ArrowLeft, ArrowRight, Send, Home } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import VideoRecorder from '@/components/VideoRecorder';
import Logo from '@/components/Logo';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const SurveyCompletionPage = () => {
  const { token, id } = useParams();
  const navigate = useNavigate();
  const [surveyData, setSurveyData] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState(null);
  const { user } = useAuth(); // Check if logged in for "Back" navigation
  
  // Navigation State
  const [currentStep, setCurrentStep] = useState(0);
  
  // Video Recording State
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [activeQuestionId, setActiveQuestionId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const { toast } = useToast();

  useEffect(() => {
    const initSurvey = async () => {
      if (!token && !id) {
           setError("Invalid survey link.");
           setLoading(false);
           return;
      }
      
      setLoading(true);
      setError(null);
      try {
        let data, fetchError;

        if (token) {
           // Fetch by Invitation Token
           const result = await supabase.rpc('get_survey_by_invitation_token', {
              p_token: token
           });
           data = result.data;
           fetchError = result.error;
        } else if (id) {
           // Fetch by Public Survey ID
           const result = await supabase.rpc('get_public_survey', {
              p_id: id
           });
           data = result.data;
           fetchError = result.error;
        }

        if (fetchError) throw fetchError;
        if (!data || !data.survey) {
             setError("Survey not found or access is restricted.");
             setLoading(false);
             return;
        }

        // Check if survey is active if using public link (optional, but good UX)
        if (id && data.survey.status !== 'active') {
             // For owners (if we knew), we might allow preview. But for now, just show warning.
             // Actually, if it's a preview, we often want to see it even if draft.
             // Let's rely on the backend or just show it with a warning banner if we can detect it.
        }

        setSurveyData(data.survey);
        setQuestions(data.questions || []);

      } catch (err) {
        console.error("Survey Fetch Error:", err);
        setError("An unexpected error occurred while loading the survey.");
      } finally {
        setLoading(false);
      }
    };

    initSurvey();
  }, [token, id]);

  const handleAnswerChange = (questionId, value) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  // --- Video Handling ---
  const handleRecordClick = (questionId) => {
    setActiveQuestionId(questionId);
    setIsRecorderOpen(true);
  };

  const handleRecorderComplete = (data) => {
    handleAnswerChange(activeQuestionId, {
      video_url: data.url,
      thumbnail_url: data.thumbnail_url,
      duration: data.duration,
      transcription: data.transcription
    });
    setIsRecorderOpen(false);
    setActiveQuestionId(null);
  };

  const handleUploadClick = (questionId) => {
    setActiveQuestionId(questionId);
    if (fileInputRef.current) {
      fileInputRef.current.value = ''; // Reset
      fileInputRef.current.click();
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !activeQuestionId) return;

    if (file.size > 100 * 1024 * 1024) {
      toast({ title: "File too large", description: "Please upload a video smaller than 100MB.", variant: "destructive" });
      return;
    }

    setUploading(true);
    const fileName = `survey-responses/${surveyData.id}/${activeQuestionId}-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '')}`;
    
    try {
      const { data, error } = await supabase.storage
        .from('survey-responses')
        .upload(fileName, file, { cacheControl: '3600', upsert: false });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage.from('survey-responses').getPublicUrl(data.path);
      
      handleAnswerChange(activeQuestionId, {
        video_url: publicUrl,
        type: 'upload',
        original_name: file.name
      });
      
      toast({ title: "Video Uploaded", description: "Your video response has been attached." });

    } catch (err) {
      console.error("Upload error:", err);
      toast({ title: "Upload Failed", description: err.message || "Could not upload video.", variant: "destructive" });
    } finally {
      setUploading(false);
      setActiveQuestionId(null);
    }
  };

  const clearVideoAnswer = (questionId) => {
    setAnswers(prev => {
      const newAnswers = { ...prev };
      delete newAnswers[questionId];
      return newAnswers;
    });
  };

  // --- Navigation & Submission ---
  const handleNext = () => {
    const currentQ = questions[currentStep];
    const answer = answers[currentQ.id];

    // Validation
    if (currentQ.is_required) {
        if (!answer || (typeof answer === 'string' && !answer.trim())) {
            toast({ 
                title: "Response Required", 
                description: "Please answer this question to proceed.", 
                variant: "destructive" 
            });
            return;
        }
    }

    if (currentStep < questions.length - 1) {
        setCurrentStep(prev => prev + 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        handleSubmit();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
        setCurrentStep(prev => prev - 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const formattedAnswers = Object.entries(answers).map(([qId, val]) => {
         const question = questions.find(q => q.id === qId);
         let finalAnswer = {};
         if (question?.question_type === 'video' && typeof val === 'object') {
           finalAnswer = val; 
         } else {
           finalAnswer = { value: val };
         }
         return { question_id: qId, answer: finalAnswer };
      });

      // Submit via RPC
      // If token is null, it treats as public/anonymous submission (if ID was used)
      const { data, error } = await supabase.rpc('submit_survey_response', {
        p_survey_id: surveyData.id,
        p_answers: formattedAnswers,
        p_token: token || null
      });

      if (error) throw error;
      if (data && data.success === false) throw new Error(data.message);

      setCompleted(true);
    } catch (err) {
      console.error('Survey Submission Error:', err);
      toast({ title: "Submission Failed", description: "There was an error submitting your responses. Please try again.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900"><Loader2 className="w-8 h-8 animate-spin text-primary"/></div>;
  }

  if (error) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
             <Card className="w-full max-w-md text-center p-8 shadow-xl border-t-4 border-t-red-500">
                <div className="flex justify-center mb-6"><AlertCircle className="w-16 h-16 text-red-500"/></div>
                <h2 className="text-2xl font-bold mb-2">Unavailable</h2>
                <p className="text-muted-foreground mb-6">{error}</p>
                <div className="flex justify-center gap-4">
                    <Button onClick={() => window.location.reload()} variant="outline">Retry</Button>
                    <Button onClick={() => navigate('/')} variant="ghost">Go Home</Button>
                </div>
             </Card>
        </div>
    );
  }

  if (completed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
         <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
            <Card className="w-full max-w-md text-center p-8 shadow-xl border-t-4 border-t-green-500">
               <div className="flex justify-center mb-6"><CheckCircle2 className="w-16 h-16 text-green-500"/></div>
               <h2 className="text-2xl font-bold mb-2">Thank You!</h2>
               <p className="text-muted-foreground mb-6">Your response has been recorded successfully.</p>
               <div className="flex flex-col gap-3">
                   <Button onClick={() => window.close()} variant="outline">Close Window</Button>
                   {user && (
                       <Button onClick={() => navigate('/surveys')} variant="ghost">
                           <ArrowLeft className="w-4 h-4 mr-2" />
                           Back to Surveys
                       </Button>
                   )}
               </div>
            </Card>
         </motion.div>
      </div>
    );
  }

  const currentQ = questions[currentStep];
  const totalSteps = questions.length;
  const progressPercentage = ((currentStep) / totalSteps) * 100;

  return (
    <>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 py-8 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="flex justify-center mb-4"><Logo /></div>
          
          <div className="space-y-4">
              <div className="text-center space-y-2">
                  <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">{surveyData.title}</h1>
                  {surveyData.description && <p className="text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">{surveyData.description}</p>}
              </div>

              <div className="space-y-2 pt-4">
                  <div className="flex justify-between text-sm font-medium text-slate-600 dark:text-slate-400">
                      <span>Question {currentStep + 1} of {totalSteps}</span>
                      <span>{Math.round(progressPercentage)}%</span>
                  </div>
                  <Progress value={progressPercentage} className="h-2" />
              </div>
          </div>

          <AnimatePresence mode="wait">
              {currentQ && (
                 <motion.div
                    key={currentQ.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                 >
                     <Card className="overflow-hidden shadow-md border-slate-200 dark:border-slate-800">
                       <CardHeader className="bg-slate-50/50 dark:bg-slate-800/50 pb-6 border-b">
                         <CardTitle className="text-xl font-medium leading-normal">
                           {currentQ.question_text}
                           {currentQ.is_required && <span className="text-red-500 text-sm ml-1 align-top" title="Required">*</span>}
                         </CardTitle>
                         
                         <div className="grid gap-6 md:grid-cols-2 mt-4">
                             {currentQ.question_video_url && (
                                 <div className="space-y-2">
                                     <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Question Video</span>
                                     <div className="rounded-lg overflow-hidden border bg-black aspect-video relative shadow-sm">
                                          <video src={currentQ.question_video_url} controls className="w-full h-full object-contain" />
                                     </div>
                                 </div>
                             )}
                         </div>
                       </CardHeader>
                       
                       <CardContent className="pt-8 pb-8 min-h-[300px] flex flex-col justify-center">
                         {currentQ.question_type === 'text' && (
                           <Textarea 
                             placeholder="Type your answer here..." 
                             className="min-h-[200px] text-lg p-4 resize-none"
                             value={answers[currentQ.id] || ''}
                             onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                             autoFocus
                           />
                         )}
                         
                         {(currentQ.question_type === 'multiple-choice' || currentQ.question_type === 'likert' || currentQ.question_type === 'yes-no') && (
                           <RadioGroup value={answers[currentQ.id]} onValueChange={(val) => handleAnswerChange(currentQ.id, val)} className="space-y-3">
                              {currentQ.options?.options?.map((opt, i) => (
                                  <div key={i} className="flex items-center space-x-3 p-4 rounded-xl border-2 border-transparent bg-slate-50 dark:bg-slate-800 hover:border-primary/20 transition-all cursor-pointer has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                                      <RadioGroupItem value={opt} id={`${currentQ.id}-${i}`} className="w-5 h-5" />
                                      <Label htmlFor={`${currentQ.id}-${i}`} className="flex-1 cursor-pointer font-medium text-lg">{opt}</Label>
                                  </div>
                              ))}
                           </RadioGroup>
                         )}

                         {currentQ.question_type === 'video' && (
                             <div className="space-y-4 max-w-2xl mx-auto w-full">
                                 {!answers[currentQ.id] ? (
                                     <div className="flex flex-col gap-6 items-center justify-center p-10 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl bg-slate-50/50 dark:bg-slate-800/30">
                                         <div className="flex flex-col sm:flex-row gap-4 w-full">
                                             <Button 
                                               size="lg" 
                                               className="flex-1 h-auto py-8 flex flex-col gap-3 text-lg hover:scale-[1.02] transition-transform"
                                               onClick={() => handleRecordClick(currentQ.id)}
                                             >
                                                <Video className="w-8 h-8" />
                                                <span>Record Video</span>
                                             </Button>
                                             <Button 
                                               size="lg" 
                                               variant="outline"
                                               className="flex-1 h-auto py-8 flex flex-col gap-3 text-lg hover:bg-slate-100 dark:hover:bg-slate-800 hover:scale-[1.02] transition-transform"
                                               onClick={() => handleUploadClick(currentQ.id)}
                                               disabled={uploading}
                                             >
                                                {uploading ? <Loader2 className="w-8 h-8 animate-spin" /> : <Upload className="w-8 h-8" />}
                                                <span>Upload File</span>
                                             </Button>
                                         </div>
                                     </div>
                                 ) : (
                                     <div className="relative rounded-xl overflow-hidden border bg-black shadow-lg group">
                                         <video src={answers[currentQ.id].video_url} controls className="w-full aspect-video object-contain bg-black" />
                                         <Button 
                                            size="sm" variant="destructive" className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                                            onClick={() => clearVideoAnswer(currentQ.id)}
                                         >
                                             <Trash2 className="w-4 h-4 mr-2" /> Retake
                                         </Button>
                                     </div>
                                 )}
                             </div>
                         )}
                       </CardContent>

                       <CardFooter className="bg-slate-50/50 dark:bg-slate-800/50 p-6 border-t flex justify-between items-center">
                           <Button variant="ghost" onClick={handlePrevious} disabled={currentStep === 0} className="gap-2">
                              <ArrowLeft className="w-4 h-4" /> Previous
                           </Button>
                           <Button onClick={handleNext} disabled={submitting} className="gap-2 min-w-[140px]" size="lg">
                              {currentStep === totalSteps - 1 ? (
                                  submitting ? <Loader2 className="w-4 h-4 animate-spin"/> : <><Send className="w-4 h-4" /> Submit Survey</>
                              ) : (
                                  <>Next <ArrowRight className="w-4 h-4" /></>
                              )}
                           </Button>
                       </CardFooter>
                     </Card>
                 </motion.div>
              )}
          </AnimatePresence>
        </div>
      </div>

      <VideoRecorder
        open={isRecorderOpen}
        onOpenChange={setIsRecorderOpen}
        onUploadComplete={handleRecorderComplete}
        storagePath={`survey-responses/${surveyData?.id}`}
        bucketName="survey-responses"
      />
      <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="video/*" />
    </>
  );
};

export default SurveyCompletionPage;
