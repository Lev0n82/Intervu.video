
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, AlertTriangle, Video, FileText } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ReactMarkdown from 'react-markdown';
import ParticipantInterviewFlow from '@/components/interview/ParticipantInterviewFlow';

const PreviewPage = () => {
    const { type, id } = useParams();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const mode = searchParams.get('mode'); // 'participant' or null
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            setError(null);
            
            let query;
            if (type === 'interview') {
                query = supabase
                    .from('interview_templates')
                    .select('*, template_questions(*, personas(*))')
                    .eq('id', id)
                    .single();
            } else if (type === 'survey') {
                query = supabase
                    .from('surveys')
                    .select('*, survey_questions(*)')
                    .eq('id', id)
                    .single();
            } else {
                setError('Invalid preview type.');
                setLoading(false);
                return;
            }

            try {
                const { data: resultData, error: queryError } = await query;
                if (queryError) throw queryError;
                
                if(resultData) {
                    if (type === 'interview') {
                        resultData.template_questions.sort((a,b) => a.order - b.order);
                    } else if (type === 'survey') {
                        resultData.survey_questions.sort((a,b) => a.sequence_order - b.sequence_order);
                    }
                }
                setData(resultData);
            } catch (err) {
                setError(err.message);
                toast({
                    title: 'Error Fetching Preview Data',
                    description: err.message,
                    variant: 'destructive',
                });
            } finally {
                setLoading(false);
            }
        };

        if (id && type) {
            fetchData();
        }
    }, [id, type, toast]);

    if (loading) {
        return <div className="flex justify-center items-center h-screen bg-slate-50"><Loader2 className="h-12 w-12 animate-spin text-blue-600" /></div>;
    }

    if (error || !data) {
        return (
            <div className="flex flex-col justify-center items-center h-screen p-4 text-center">
                <AlertTriangle className="h-16 w-16 text-destructive mb-4" />
                <h1 className="text-2xl font-bold">Could not load preview</h1>
                <p className="text-muted-foreground mt-2">{error || 'The requested item could not be found.'}</p>
                <Button onClick={() => navigate('/dashboard')} className="mt-6">Go to Dashboard</Button>
            </div>
        );
    }
    
    // Interactive Participant Mode (Preview)
    if (mode === 'participant' && type === 'interview') {
        // Mock the structure expected by ParticipantInterviewFlow
        // Real structure has 'interviews' wrapping 'interview_templates'
        // We create a mock interview object wrapper
        const mockInterviewData = {
            interviews: {
                id: 'preview-id',
                status: 'preview',
                interview_templates: data
            }
        };

        return (
            <div className="min-h-screen bg-slate-950 text-slate-100">
                <div className="bg-blue-600/20 text-blue-200 p-2 text-center text-sm font-medium border-b border-blue-600/30 sticky top-0 z-50 backdrop-blur-sm">
                    👀 PREVIEW MODE: Your answers will not be saved.
                </div>
                <ParticipantInterviewFlow 
                    interviewData={mockInterviewData}
                    submissionId={null} // No submission ID for preview
                    submissionToken={null}
                />
            </div>
        );
    }

    // Static Preview Mode (Default)
    const renderInterviewPreview = () => (
        <div className="p-4 sm:p-6 max-w-3xl mx-auto space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="text-3xl">{data.name}</CardTitle>
                    <CardDescription>{data.description}</CardDescription>
                </CardHeader>
                <CardContent>
                    {data.introduction_video_url && (
                         <div className="aspect-video bg-black rounded-lg mb-4 overflow-hidden">
                             <video key={data.introduction_video_url} controls className="w-full h-full object-contain">
                                <source src={data.introduction_video_url} type="video/mp4" />
                            </video>
                         </div>
                    )}
                    {data.introduction_text && (
                        <div className="prose prose-slate max-w-none">
                            <ReactMarkdown>{data.introduction_text}</ReactMarkdown>
                        </div>
                    )}
                </CardContent>
            </Card>
            
            <div className="flex items-center gap-2 my-8">
                <div className="h-px flex-1 bg-border" />
                <span className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Interview Questions</span>
                <div className="h-px flex-1 bg-border" />
            </div>

            {data.template_questions.map((q, index) => (
                <Card key={q.id}>
                    <CardHeader>
                        <CardTitle className="text-xl flex justify-between items-start">
                            <span>Question {index + 1}</span>
                            {q.personas && <span className="text-xs bg-slate-100 px-2 py-1 rounded text-slate-600 font-normal">{q.personas.name}</span>}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {q.question_video_url ? (
                             <div className="aspect-video bg-black rounded-lg overflow-hidden">
                                <video key={q.question_video_url} controls className="w-full h-full object-contain">
                                    <source src={q.question_video_url} type="video/mp4" />
                                </video>
                             </div>
                        ) : (
                            <div className="aspect-video bg-slate-100 rounded-lg flex items-center justify-center text-slate-400 text-sm">
                                Video Pending
                            </div>
                        )}
                         <p className="text-lg font-medium text-slate-800">{q.question_text}</p>
                         
                         {q.clarification_text && (
                             <div className="bg-blue-50 p-3 rounded text-sm text-blue-700">
                                 <strong>Clarification available:</strong> {q.clarification_text}
                             </div>
                         )}

                        <Button disabled variant="secondary" className="w-full"><Video className="mr-2 h-4 w-4"/> Record Answer (Disabled in Static Preview)</Button>
                    </CardContent>
                </Card>
            ))}
             <div className="text-center pt-8 pb-12">
                <Button size="lg" onClick={() => navigate(`?mode=participant`)}>
                    Try Participant Experience
                </Button>
            </div>
        </div>
    );

    const renderSurveyPreview = () => (
         <div className="p-4 sm:p-6 max-w-3xl mx-auto space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="text-3xl">{data.title}</CardTitle>
                    <CardDescription>{data.description}</CardDescription>
                </CardHeader>
            </Card>
             <h2 className="text-2xl font-semibold mt-8">Questions</h2>
             {data.survey_questions.map((q, index) => (
                 <Card key={q.id}>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-xl">
                           {q.question_type === 'video' ? <Video/> : <FileText />} Question {index + 1}
                        </CardTitle>
                         <p className="font-normal pt-2">{q.question_text}</p>
                    </CardHeader>
                    <CardContent>
                        {q.question_type === 'video' ? (
                             <>
                                {q.question_video_url && <video key={q.question_video_url} controls className="w-full rounded-lg mb-4"><source src={q.question_video_url} type="video/mp4" /></video>}
                                <Button disabled><Video className="mr-2 h-4 w-4"/> Record Answer</Button>
                             </>
                        ) : (
                            <p className="text-muted-foreground p-4 bg-muted rounded-md">[Input for {q.question_type} question would appear here]</p>
                        )}
                    </CardContent>
                 </Card>
             ))}
        </div>
    );

    return (
        <div className="min-h-screen bg-slate-50 text-slate-900">
            {type === 'interview' ? renderInterviewPreview() : renderSurveyPreview()}
        </div>
    );
};

export default PreviewPage;
