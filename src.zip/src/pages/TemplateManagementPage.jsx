
import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { PlusCircle, Edit, Trash2, Loader2, FileText, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const TemplateManagementPage = () => {
  const { activeOrganization, loading: authLoading, user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTemplates = useCallback(async () => {
    if (!activeOrganization?.id) {
      if (!authLoading) setLoading(false);
      return;
    }
    
    setLoading(true);
    console.log('[TemplateManagement] Fetching templates for Org ID:', activeOrganization.id);
    
    try {
      const { data, error } = await supabase
        .from('interview_templates')
        .select('*')
        .eq('organization_id', activeOrganization.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[TemplateManagement] Error fetching templates:', error);
        toast({ variant: 'destructive', title: 'Error fetching templates', description: error.message });
      } else {
        console.log(`[TemplateManagement] Successfully fetched ${data?.length} templates.`);
        setTemplates(data || []);
      }
    } catch (err) {
      console.error('[TemplateManagement] Unexpected error:', err);
      toast({ variant: 'destructive', title: 'Error', description: 'An unexpected error occurred while loading templates.' });
    } finally {
      setLoading(false);
    }
  }, [activeOrganization, authLoading, toast]);

  useEffect(() => {
    if (!authLoading && activeOrganization) {
        fetchTemplates();
    } else if (!authLoading && !activeOrganization) {
        // Handle case where user might not have an org selected
        setLoading(false);
    }
  }, [authLoading, activeOrganization, fetchTemplates]);

  const handleDelete = async (templateId) => {
    if (!window.confirm("Are you sure you want to delete this template? This cannot be undone.")) return;
    
    console.log('[TemplateManagement] Deleting template:', templateId);
    
    const { error } = await supabase
        .from('interview_templates')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', templateId);
    
    if (error) {
      console.error('[TemplateManagement] Delete error:', error);
      toast({ variant: 'destructive', title: 'Error deleting template', description: error.message });
    } else {
      setTemplates(templates.filter(t => t.id !== templateId));
      toast({ title: 'Template deleted successfully' });
    }
  };

  const EmptyState = () => (
    <div className="text-center py-20 bg-secondary/30 rounded-lg border border-dashed border-border">
        <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-xl font-semibold">No Templates Found</h3>
        <p className="text-muted-foreground mt-2 mb-6">Get started by creating your first interview template.</p>
        <Button onClick={() => navigate("/templates/new")}>
            <PlusCircle className="mr-2 h-4 w-4" /> Create a Template
        </Button>
    </div>
  );

  return (
    <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 sm:p-6"
    >
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 pb-4 border-b border-border">
        <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-primary">Interview Templates</h1>
            <p className="text-muted-foreground mt-1">Manage, create, and reuse your interview formats.</p>
        </div>
        <Button asChild className="mt-4 sm:mt-0">
          <Link to="/templates/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Create New Template
          </Link>
        </Button>
      </header>
      
      {loading || authLoading ? (
         <div className="flex flex-col justify-center items-center py-20 gap-4">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm text-muted-foreground">Loading your templates...</p>
        </div>
      ) : templates.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence>
            {templates.map(template => (
              <motion.div
                key={template.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
              >
                <Card className="flex flex-col h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="truncate pr-4" title={template.name}>{template.name}</CardTitle>
                    <CardDescription className="line-clamp-2 min-h-[40px]">{template.description || 'No description provided.'}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                      <div className="text-xs text-muted-foreground mt-2 flex flex-col gap-1">
                        <span>Created: {new Date(template.created_at).toLocaleDateString()}</span>
                        <span className="text-[10px] opacity-50 font-mono">{template.id.slice(0,8)}...</span>
                      </div>
                      {template.status && (
                        <div className={`text-xs mt-3 inline-block px-2 py-0.5 rounded-full ${
                            template.status === 'active' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                        }`}>
                            {template.status.charAt(0).toUpperCase() + template.status.slice(1)}
                        </div>
                      )}
                  </CardContent>
                  <CardFooter className="flex justify-between items-center gap-2">
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <Link to={`/interviews/schedule/${template.id}`}>
                        <Play className="mr-2 h-4 w-4" /> Use
                      </Link>
                    </Button>
                    <div className="flex gap-1">
                       <Button variant="ghost" size="icon" asChild title="Edit">
                        <Link to={`/templates/edit/${template.id}`}>
                          <Edit className="h-4 w-4" />
                        </Link>
                      </Button>
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)} title="Delete" className="text-destructive hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </motion.div>
  );
};

export default TemplateManagementPage;
