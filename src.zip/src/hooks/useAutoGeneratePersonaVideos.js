
import { useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useAutoGeneratePersonaVideos = (activeOrganizationId) => {
    const [isAssigning, setIsAssigning] = useState(false);

    /**
     * Fetches personas and assigns them randomly to questions and clarifications.
     * Ensures fair distribution.
     * 
     * @param {Array} questions - Array of question objects
     * @returns {Promise<{questionPersonas: Map, clarificationPersonas: Map}>}
     */
    const assignPersonas = useCallback(async (questions) => {
        if (!activeOrganizationId) {
            throw new Error("Organization ID is required.");
        }

        setIsAssigning(true);
        try {
            // 1. Fetch all available personas
            const { data: personas, error } = await supabase
                .from('personas')
                .select('*')
                .eq('organization_id', activeOrganizationId)
                .is('deleted_at', null);

            if (error) throw error;

            if (!personas || personas.length === 0) {
                throw new Error("No personas found in this organization. Please create a persona first.");
            }

            const questionPersonas = new Map();
            const clarificationPersonas = new Map();
            
            // Helper to shuffle array
            const shuffle = (array) => {
                let currentIndex = array.length, randomIndex;
                const newArray = [...array];
                while (currentIndex > 0) {
                    randomIndex = Math.floor(Math.random() * currentIndex);
                    currentIndex--;
                    [newArray[currentIndex], newArray[randomIndex]] = [newArray[randomIndex], newArray[currentIndex]];
                }
                return newArray;
            };

            // Create a pool of personas to draw from to ensure fairness
            let personaPool = shuffle(personas);
            
            questions.forEach(question => {
                // --- Assign Question Persona ---
                // If pool is empty, refill and reshuffle
                if (personaPool.length === 0) {
                    personaPool = shuffle(personas);
                }
                const selectedForQuestion = personaPool.pop();
                questionPersonas.set(question.id, selectedForQuestion.id);

                // --- Assign Clarification Persona (if needed) ---
                if (question.clarification_text) {
                     // Try to pick a different persona for clarification if possible
                     let clarificationPool = personas.filter(p => p.id !== selectedForQuestion.id);
                     if (clarificationPool.length === 0) {
                         clarificationPool = [selectedForQuestion]; // Fallback to same if only 1 exists
                     }
                     
                     // Just pick random from available pool for clarification
                     const selectedForClarification = clarificationPool[Math.floor(Math.random() * clarificationPool.length)];
                     clarificationPersonas.set(question.id, selectedForClarification.id);
                }
            });

            return { questionPersonas, clarificationPersonas };

        } catch (error) {
            console.error("Error assigning personas:", error);
            throw error;
        } finally {
            setIsAssigning(false);
        }
    }, [activeOrganizationId]);

    return { 
        assignPersonas,
        isAssigning
    };
};
