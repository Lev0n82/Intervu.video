
import { useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Hook to handle auto-generation of videos for a template
 */
export const useAutoGenerateVideos = (organizationId) => {
    const [isGenerating, setIsGenerating] = useState(false);
    const [progress, setProgress] = useState(0);
    const [total, setTotal] = useState(0);
    const [error, setError] = useState(null);

    const assignRandomPersonasAndQueueVideos = async ({ 
        templateId, 
        userId,
        itemsToGenerate, // Array of { type: 'intro'|'question'|'clarification', id: string|null, text: string }
        templateQuestions 
    }) => {
        setIsGenerating(true);
        setProgress(0);
        setError(null);
        setTotal(itemsToGenerate.length);

        let assignedCount = 0;
        const queuedIds = [];

        try {
            // 1. Fetch Personas
            const { data: personas, error: personasError } = await supabase
                .from('personas')
                .select('*')
                .eq('organization_id', organizationId)
                .is('deleted_at', null);

            if (personasError) throw personasError;
            if (!personas || personas.length === 0) {
                throw new Error("No personas found. Please create at least one AI Persona first.");
            }

            const processedQuestions = new Map(); // Track updated persona assignments to avoid duplicates

            // 2. Process each item
            for (let i = 0; i < itemsToGenerate.length; i++) {
                const item = itemsToGenerate[i];
                
                // Select random persona
                const randomPersona = personas[Math.floor(Math.random() * personas.length)];
                let assignedPersonaId = randomPersona.id;

                // If it's a question/clarification (not intro), check if we need to assign or reuse a persona
                if (item.type !== 'intro' && item.id) {
                    if (processedQuestions.has(item.id)) {
                        // We already decided a persona for this question ID in this batch
                        assignedPersonaId = processedQuestions.get(item.id);
                    } else {
                        // Check if the question already has a persona assigned in DB
                        const existingQ = templateQuestions.find(q => q.id === item.id);
                        
                        if (existingQ && existingQ.persona_id) {
                            // Use existing
                            assignedPersonaId = existingQ.persona_id;
                        } else {
                            // Question has no persona, so we MUST assign one randomly and update DB
                            const { error: updateError } = await supabase
                                .from('template_questions')
                                .update({ persona_id: assignedPersonaId })
                                .eq('id', item.id);
                            
                            if (updateError) throw updateError;
                            assignedCount++;
                        }
                        processedQuestions.set(item.id, assignedPersonaId);
                    }
                }

                // Check for existing queue item to avoid duplicates (pending/processing)
                // Note: We use maybeSingle to avoid error if 0 rows found
                const { data: existingQueue } = await supabase
                    .from('video_generation_queue')
                    .select('id')
                    .eq('organization_id', organizationId)
                    .eq('template_question_id', item.id) // intro is null
                    .in('status', ['pending', 'processing'])
                    .maybeSingle();

                let shouldQueue = true;
                if (item.type === 'intro') {
                     // For intro, we don't have a template_question_id to dedupe easily against.
                     // We assume if the user requested it, they want it.
                     shouldQueue = true;
                } else if (existingQueue) {
                    shouldQueue = false;
                }

                if (shouldQueue) {
                    // Create Queue Entry
                    const { data: queueData, error: queueError } = await supabase
                        .from('video_generation_queue')
                        .insert({
                            organization_id: organizationId,
                            template_question_id: item.type === 'intro' ? null : item.id,
                            prompt: item.text,
                            status: 'pending',
                            created_by: userId,
                            // Metadata for the edge function to pick up if needed, though arguments handle it
                        })
                        .select()
                        .single();

                    if (queueError) throw queueError;

                    // Trigger Generation via Edge Function
                    await supabase.functions.invoke('generate-video', {
                        body: {
                            action: 'start',
                            db_record_id: queueData.id,
                            prompt: item.text,
                            persona_id: assignedPersonaId,
                            is_introduction: item.type === 'intro',
                            template_id: templateId,
                            video_type: item.type === 'clarification' ? 'clarification' : (item.type === 'intro' ? 'intro' : 'question')
                        }
                    });
                    
                    queuedIds.push(queueData.id);
                }

                setProgress(prev => prev + 1);
            }

            return { success: true, queuedIds, assignedPersonasCount: assignedCount };
        } catch (err) {
            console.error("Auto-generation error:", err);
            setError(err.message || "Failed to start auto-generation");
            return { success: false, error: err };
        } finally {
            // We don't set isGenerating false immediately if success, to allow parent to transition UI
            if (error) setIsGenerating(false);
        }
    };

    return {
        generateVideos: assignRandomPersonasAndQueueVideos, // Alias for backward compatibility if needed
        assignRandomPersonasAndQueueVideos,
        isGenerating,
        progress,
        total,
        error
    };
};
