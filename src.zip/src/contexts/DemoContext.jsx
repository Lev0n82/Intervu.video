
import React, { createContext, useContext, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const DemoContext = createContext(null);

export const DemoProvider = ({ children }) => {
    const location = useLocation();
    const navigate = useNavigate();
    const { toast } = useToast();

    const isDemo = useMemo(() => location.pathname.startsWith('/demo'), [location.pathname]);

    // Note: DemoContext does not provide activeOrganizationId.
    // The application relies on SupabaseAuthContext (useAuth) for organization context.
    // In demo mode, saving is disabled via promptSave below, so valid UUIDs are not required for saving.

    const promptSave = () => {
        if (isDemo) {
            toast({
                title: "Demo Mode",
                description: "This feature requires an account. Please sign up to save your work.",
                action: (
                    <button
                        onClick={() => navigate('/auth')}
                        className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
                    >
                        Sign Up
                    </button>
                ),
            });
            return true; // Indicates that the prompt was shown
        }
        return false; // Indicates not in demo mode, proceed with action
    };

    const value = {
        isDemo,
        promptSave,
    };

    return (
        <DemoContext.Provider value={value}>
            {children}
        </DemoContext.Provider>
    );
};

export const useDemo = () => {
    const context = useContext(DemoContext);
    if (context === undefined) {
        throw new Error('useDemo must be used within a DemoProvider');
    }
    return context;
};
