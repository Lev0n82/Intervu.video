
import React, { createContext, useState, useEffect, useContext, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/contexts/ThemeContext';
import { useTranslation } from 'react-i18next';
import { ToastAction } from '@/components/ui/toast';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeOrganization, setActiveOrganization] = useState(null);
  const { toast } = useToast();
  const { setTheme } = useTheme();
  const { i18n } = useTranslation();

  // Use refs to access latest values without triggering re-renders in useEffects
  const mountedRef = useRef(true);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const handleProfileData = useCallback((profile) => {
    if (!mountedRef.current) return;
    
    if (profile) {
      console.log("AuthContext: Profile loaded", profile.id);
      setUserProfile(profile);

      if (profile.preferred_theme) setTheme(profile.preferred_theme);
      if (profile.preferred_language) i18n.changeLanguage(profile.preferred_language);

      if (profile.team_memberships && profile.team_memberships.length > 0) {
        const lastActiveOrgId = localStorage.getItem('activeOrganizationId');
        const orgToSetActive = 
          profile.team_memberships.find(tm => tm.organization_id === lastActiveOrgId)?.organization || 
          profile.team_memberships[0].organization;
        setActiveOrganization(orgToSetActive);
      } else {
        setActiveOrganization(null);
      }
    } else {
      console.log("AuthContext: No profile found or profile cleared");
      setUserProfile(null);
      setActiveOrganization(null);
    }
  }, [setTheme, i18n]);

  const fetchFullProfile = useCallback(async (userId) => {
      console.log("AuthContext: Fetching full profile for", userId);
      try {
          const { data: profile, error } = await supabase.rpc('get_user_profile', { user_id_input: userId });
          
          if (error) {
              console.error("AuthContext: Could not fetch user profile:", error);
              if (mountedRef.current) handleProfileData(null);
          } else {
              if (mountedRef.current) handleProfileData(profile);
          }
          return profile;
      } catch (err) {
          console.error("AuthContext: Unexpected error fetching profile:", err);
          if (mountedRef.current) handleProfileData(null);
          return null;
      }
  }, [handleProfileData]);

  useEffect(() => {
    let mounted = true;
    
    // Initial session check
    const initializeAuth = async () => {
        console.log("AuthContext: Initializing auth...");
        setLoading(true);
        try {
            const { data: { session: initialSession }, error } = await supabase.auth.getSession();
            
            if (error) {
                console.error("AuthContext: Error getting initial session:", error);
                throw error;
            }

            if (mounted) {
                setSession(initialSession);
                setUser(initialSession?.user ?? null);
                
                if (initialSession?.user) {
                    console.log("AuthContext: Found initial user", initialSession.user.id);
                    await fetchFullProfile(initialSession.user.id);
                } else {
                    console.log("AuthContext: No initial user session");
                    handleProfileData(null);
                }
            }
        } catch (error) {
            console.error("AuthContext: Auth initialization error:", error);
        } finally {
            if (mounted) {
                console.log("AuthContext: Initialization complete. Loading set to false.");
                setLoading(false);
            }
        }
    };

    initializeAuth();

    // Listen for changes
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, currentSession) => {
      if (!mounted) return;
      console.log(`AuthContext: Auth state change event: ${event}`);

      const currentUser = currentSession?.user;
      setSession(currentSession);
      setUser(currentUser ?? null);

      if (currentUser) {
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
             // Fetch profile if missing or fresh sign-in
             await fetchFullProfile(currentUser.id);
        }
      } else if (event === 'SIGNED_OUT') {
        handleProfileData(null);
        setActiveOrganization(null);
      }
      
      // Ensure loading is turned off after state change processing
      // This is critical for resolving the "endless spinner" issue after redirects
      setLoading(false);
    });

    return () => {
      mounted = false;
      if (authListener && authListener.subscription) {
          authListener.subscription.unsubscribe();
      }
    };
  }, [fetchFullProfile, handleProfileData]); 

  const switchOrganization = (organization) => {
      setActiveOrganization(organization);
      localStorage.setItem('activeOrganizationId', organization.id);
      window.location.reload();
  };
  
  const refreshUserProfile = async () => {
    if (user) {
      await fetchFullProfile(user.id);
    }
  };

  const signUpAndOnboard = async (email, password, fullName, userType, organizationName, department) => {
    try {
      console.log("AuthContext: Starting signup...");
      // 1. Create the user in Supabase Auth
      const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
              data: {
                  full_name: fullName,
                  user_type: userType,
                  organization_name: userType === 'Hiring' ? organizationName : null,
                  department: userType === 'Hiring' ? department : null
              },
              emailRedirectTo: `${window.location.origin}/dashboard`,
          }
      });

      if (error) throw error;
      
      if (!data.user) {
          throw new Error("Registration failed. Please try again.");
      }

      console.log("AuthContext: User created, invoking email verification...");

      // 2. Trigger the robust email verification via Edge Function + Resend
      const { data: fnData, error: fnError } = await supabase.functions.invoke('send-verification-email', {
          body: {
              email,
              password,
              fullName,
              userType,
              organizationName,
              redirectUrl: `${window.location.origin}/dashboard`
          }
      });

      if (fnError) {
          console.error("Failed to send verification email via edge function:", fnError);
          toast({ 
            variant: "warning", 
            title: "Account Created", 
            description: "Account created, but we had trouble sending the verification email. Please check your spam folder or contact support." 
          });
      } else if (fnData?.verificationLink) {
          // CRITICAL: Handle the case where email failed but we got a link back (Dev/Test mode)
          console.log("Manual verification link received:", fnData.verificationLink);
          toast({
              title: "Action Required",
              description: "Email delivery skipped (Test Mode). Click 'Verify Now' to activate your account.",
              action: (
                <ToastAction altText="Verify Now" onClick={() => window.open(fnData.verificationLink, '_blank')}>
                  Verify Now
                </ToastAction>
              ),
              duration: 15000,
          });
      } else {
        console.log("Verification email sent successfully.");
      }

      return { user: data.user, error: null };

    } catch (err) {
      console.error("SignUp error:", err);
      toast({ variant: "destructive", title: "Sign up failed", description: err.message || "An unexpected error occurred." });
      return { user: null, error: err };
    }
  };

  const resendVerification = async (email, password) => {
      try {
        const { data: fnData, error: fnError } = await supabase.functions.invoke('send-verification-email', {
            body: {
                email,
                password,
                // We don't pass other fields to avoid overwriting metadata with nulls
            }
        });

        if (fnError) throw fnError;

        if (fnData?.verificationLink) {
            toast({
                title: "Verification Link",
                description: "Click below to verify your account (Test Mode).",
                action: (
                  <ToastAction altText="Verify Now" onClick={() => window.open(fnData.verificationLink, '_blank')}>
                    Verify Now
                  </ToastAction>
                ),
                duration: 15000,
            });
        } else {
            toast({ title: "Email Sent", description: "Verification email has been resent." });
        }
        return { error: null };
      } catch (err) {
        console.error("Resend error:", err);
        toast({ variant: "destructive", title: "Failed to resend", description: err.message });
        return { error: err };
      }
  };

  const signIn = async (email, password) => {
    setLoading(true);
    console.log("AuthContext: Attempting sign in...");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setLoading(false);
      console.error("AuthContext: Sign in failed:", error);
      if (error.message.includes("Email not confirmed")) {
        toast({
          variant: "destructive",
          title: "Email Not Verified",
          description: "Please check your inbox and click the verification link sent to you.",
        });
      } else {
        toast({ variant: "destructive", title: "Sign in Failed", description: error.message || "Invalid credentials." });
      }
    } else {
        console.log("AuthContext: Sign in successful");
        toast({ title: "Signed In Successfully!", description: "Welcome back! Redirecting..." });
    }
    return { error };
  };

  const signInWithGoogle = async (signUpData) => {
    console.log("AuthContext: Initiating Google Sign-In...");
    if (signUpData) {
      localStorage.setItem('pendingSignUpData', JSON.stringify(signUpData));
    } else {
      localStorage.removeItem('pendingSignUpData');
    }

    const { error } = await supabase.auth.signInWithOAuth({ 
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/`, 
      }
    });
    if (error) {
      console.error("AuthContext: Google Sign-In Error:", error);
      localStorage.removeItem('pendingSignUpData');
      toast({ variant: "destructive", title: "Error signing in with Google", description: error.message });
      setLoading(false); 
    }
  };
  
  const signOut = async () => {
    setLoading(true);
    console.log("AuthContext: Signing out...");
    await supabase.auth.signOut();
    localStorage.removeItem('activeOrganizationId');
    localStorage.removeItem('pendingSignUpData');
    handleProfileData(null);
    setLoading(false);
  };

  const value = {
    user, session, userProfile, loading, signUpAndOnboard, signIn, signInWithGoogle, signOut, refreshUserProfile,
    activeOrganization, switchOrganization, resendVerification
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
