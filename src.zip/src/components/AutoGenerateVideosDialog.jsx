
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Loader2, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const AutoGenerateVideosDialog = ({ 
    open, 
    progress, 
    total, 
    statusItems = [], 
    onClose, 
    isGenerating,
    error 
}) => {
    const progressPercentage = total > 0 ? (progress / total) * 100 : 0;
    const isComplete = progress === total && total > 0;

    return (
        <Dialog open={open} onOpenChange={(val) => !isGenerating && onClose && onClose(val)}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>Auto-Generating Persona Videos</DialogTitle>
                    <DialogDescription>
                        We are queuing video generation for your questions. This allows you to activate the template immediately.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-6 py-4">
                    {/* Error Banner */}
                    {error && (
                        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start text-sm">
                            <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}

                    {/* Progress Bar */}
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm text-muted-foreground">
                            <span>Queuing videos...</span>
                            <span>{progress} of {total}</span>
                        </div>
                        <Progress value={progressPercentage} className="h-2" />
                    </div>

                    {/* Status List */}
                    <div className="border rounded-md bg-muted/20">
                        <ScrollArea className="h-[200px] p-4">
                            <div className="space-y-3">
                                {statusItems.map((item, index) => (
                                    <div key={index} className="flex items-start text-sm">
                                        <div className="mr-3 pt-0.5">
                                            {item.status === 'pending' && <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />}
                                            {item.status === 'success' && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                                            {item.status === 'error' && <XCircle className="w-4 h-4 text-red-500" />}
                                            {item.status === 'waiting' && <div className="w-4 h-4 rounded-full border-2 border-muted" />}
                                        </div>
                                        <div className="flex-1">
                                            <p className={`font-medium ${item.status === 'error' ? 'text-red-600' : 'text-foreground'}`}>
                                                {item.title}
                                            </p>
                                            {item.message && (
                                                <p className="text-xs text-muted-foreground mt-0.5">{item.message}</p>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {statusItems.length === 0 && (
                                    <div className="text-center text-muted-foreground py-8">
                                        Preparing tasks...
                                    </div>
                                )}
                            </div>
                        </ScrollArea>
                    </div>
                </div>

                <DialogFooter className="sm:justify-between">
                    <div className="text-xs text-muted-foreground self-center hidden sm:block">
                        {isGenerating ? "Please do not close this window." : "Operation complete."}
                    </div>
                    <Button 
                        onClick={onClose} 
                        disabled={isGenerating}
                        variant={isComplete ? "default" : "secondary"}
                    >
                        {isComplete ? "Done" : "Cancel"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AutoGenerateVideosDialog;
