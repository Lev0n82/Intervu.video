
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { RefreshCw, Zap, WifiOff } from 'lucide-react';

const Preloader = ({ onTimeout }) => {
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    // 5-second timeout as requested for faster feedback loop
    const timer = setTimeout(() => {
      setShowError(true);
      if (onTimeout) onTimeout();
    }, 5000); 

    return () => clearTimeout(timer);
  }, [onTimeout]);

  const handleRetry = () => {
    window.location.reload();
  };

  // Background animated blob variants for depth effect
  const blobVariants = {
    animate: {
      scale: [1, 1.2, 1],
      rotate: [0, 90, 0],
      opacity: [0.3, 0.5, 0.3],
      transition: {
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-slate-950 font-sans text-slate-100">
      {/* Animated Ambient Background Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-indigo-950/40 to-slate-950 z-0" />
      
      {/* Floating Blobs for Depth / Glassmorphism context */}
      <motion.div
        variants={blobVariants}
        animate="animate"
        className="absolute top-[-10%] left-[-10%] w-[60vw] h-[60vw] rounded-full bg-purple-600/10 blur-[100px] z-0"
      />
      <motion.div
        variants={blobVariants}
        animate="animate"
        transition={{ delay: 2 }}
        className="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] rounded-full bg-blue-600/10 blur-[100px] z-0"
      />

      {/* Main Glass Card Container */}
      <div className="relative z-10 w-full max-w-sm mx-4 aspect-square max-h-[400px] h-full flex flex-col items-center justify-center">
        {/* Glass Effect Layer */}
        <div className="absolute inset-0 bg-white/5 backdrop-blur-2xl rounded-3xl border border-white/10 shadow-2xl" />
        
        <div className="relative z-20 flex flex-col items-center justify-center w-full h-full p-8 text-center">
          <AnimatePresence mode="wait">
            {!showError ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0, scale: 0.9, filter: "blur(10px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.9, filter: "blur(10px)" }}
                transition={{ duration: 0.5 }}
                className="flex flex-col items-center space-y-8"
              >
                {/* Logo Animation */}
                <div className="relative w-24 h-24">
                  {/* Outer Ring */}
                  <motion.div
                    className="absolute inset-0 rounded-full border-2 border-transparent border-t-indigo-500 border-r-purple-500"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  />
                  {/* Middle Ring (Reverse) */}
                  <motion.div
                    className="absolute inset-2 rounded-full border-2 border-transparent border-l-blue-400 border-b-cyan-400 opacity-70"
                    animate={{ rotate: -360 }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  />
                  
                  {/* Center Logo Icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                     <motion.div
                       animate={{ 
                         scale: [1, 1.1, 1],
                         filter: ["drop-shadow(0 0 0px rgba(99, 102, 241, 0))", "drop-shadow(0 0 15px rgba(99, 102, 241, 0.5))", "drop-shadow(0 0 0px rgba(99, 102, 241, 0))"]
                       }}
                       transition={{ duration: 2, repeat: Infinity }}
                     >
                       <Zap className="w-8 h-8 text-white fill-white" />
                     </motion.div>
                  </div>
                </div>

                <div className="space-y-2">
                  <motion.h2 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-slate-400"
                  >
                    intervu.video
                  </motion.h2>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="flex items-center justify-center gap-1"
                  >
                     <span className="text-sm font-medium text-slate-400">Initializing Studio</span>
                     <motion.span
                        animate={{ opacity: [0, 1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0 }}
                     >.</motion.span>
                     <motion.span
                        animate={{ opacity: [0, 1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0.2 }}
                     >.</motion.span>
                     <motion.span
                        animate={{ opacity: [0, 1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0.4 }}
                     >.</motion.span>
                  </motion.div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="error"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="flex flex-col items-center space-y-6"
              >
                <div className="relative">
                    <div className="absolute inset-0 bg-red-500/20 blur-xl rounded-full" />
                    <div className="relative p-4 bg-white/5 border border-red-500/30 rounded-full shadow-inner">
                        <WifiOff className="w-10 h-10 text-red-400" />
                    </div>
                </div>
                
                <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-white">Connection Timeout</h3>
                    <p className="text-sm text-slate-400 max-w-[240px] leading-relaxed">
                        We're having trouble reaching the studio servers. Please check your connection.
                    </p>
                </div>

                <Button 
                    onClick={handleRetry}
                    className="group relative overflow-hidden bg-white text-slate-900 hover:bg-slate-200 border-none shadow-lg shadow-white/10 transition-all duration-300 w-full max-w-[200px]"
                >
                    <RefreshCw className="w-4 h-4 mr-2 group-hover:rotate-180 transition-transform duration-500" />
                    <span className="font-medium">Retry Connection</span>
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Preloader;
