
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Lock, UserPlus, Loader2, AlertTriangle, Check, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';

const PasswordStep = ({ onBack, onSubmit, isLoading, error }) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  
  const requirements = [
    { label: "At least 8 characters", met: password.length >= 8 },
    { label: "Contains a number", met: /\d/.test(password) },
    { label: "Contains an uppercase letter", met: /[A-Z]/.test(password) },
    { label: "Contains a special character", met: /[!@#$%^&*(),.?":{}|<>]/.test(password) },
  ];

  const isStrong = requirements.every(r => r.met);
  const match = password && password === confirmPassword;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isStrong) return;
    if (!match) return;
    
    onSubmit(password, rememberMe);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-semibold tracking-tight">Create your password</h2>
        <p className="text-sm text-muted-foreground">
          Choose a strong password to protect your account.
        </p>
      </div>

      <Alert variant="warning" className="bg-amber-50 border-amber-200 text-amber-800">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-xs font-medium">
          Security Tip: Don't reuse passwords from other accounts.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-3">
          <div className="relative">
            <Lock className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="password"
              placeholder="Password"
              className="pl-9"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            {requirements.map((req, i) => (
              <div key={i} className={`flex items-center ${req.met ? 'text-green-600' : 'text-gray-400'}`}>
                {req.met ? <Check className="w-3 h-3 mr-1" /> : <div className="w-3 h-3 mr-1 rounded-full border border-gray-300" />}
                {req.label}
              </div>
            ))}
          </div>

          <div className="relative mt-2">
            <Lock className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="password"
              placeholder="Confirm Password"
              className="pl-9"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>
          {password && !match && <p className="text-xs text-red-500 flex items-center"><X className="w-3 h-3 mr-1"/> Passwords do not match</p>}
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox id="remember" checked={rememberMe} onCheckedChange={setRememberMe} />
          <Label htmlFor="remember" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            Remember me on this device
          </Label>
        </div>

        {error && <p className="text-sm text-red-500 text-center">{error}</p>}

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onBack} disabled={isLoading} className="flex-1">
            Back
          </Button>
          <Button type="submit" className="flex-1" disabled={isLoading || !isStrong || !match}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
            Sign Up & Join
          </Button>
        </div>
      </form>
    </div>
  );
};

export default PasswordStep;
