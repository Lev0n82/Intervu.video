import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Play, Square, HelpCircle } from "lucide-react";
import logger from "@/lib/logger";

const SUPPORTED_MIME_TYPES = [
    'video/webm; codecs=vp9,opus',
    'video/webm; codecs=vp8,opus',
    'video/mp4; codecs=h264,aac',
    'video/webm',
];

const InterviewRoom = ({ interviewDetails, onComplete }) => {
  const [recording, setRecording] = React.useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = React.useState(0);
  const [stream, setStream] = React.useState(null);
  const [mediaRecorder, setMediaRecorder] = React.useState(null);
  const videoRef = React.useRef(null);
  const questionVideoRef = React.useRef(null);
  const { toast } = useToast();

  const questions = interviewDetails?.questions || [
    { id: "q1", text: "Tell us about yourself.", videoUrl: "", clarificationVideoUrl: null, persona: { name: "Interviewer" } },
  ];
  const positionOverviewVideoUrl = interviewDetails?.positionOverviewVideoUrl;
  const [currentPhase, setCurrentPhase] = React.useState(positionOverviewVideoUrl ? "overview" : "question");


  React.useEffect(() => {
    const initializeCamera = async () => {
      logger.info("Initializing camera...");
      try {
        const s = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        setStream(s);
        if (videoRef.current) {
          videoRef.current.srcObject = s;
        }
        logger.info("Camera initialized successfully.");
      } catch (error) {
        logger.error("Camera initialization failed.", { error: error.toString() });
        toast({
          title: "Camera Error",
          description: "Unable to access camera or microphone. Please check permissions.",
          variant: "destructive",
        });
      }
    };

    initializeCamera();

    return () => {
      logger.info("Cleaning up InterviewRoom component.");
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        logger.debug("Media stream tracks stopped.");
      }
      if (mediaRecorder && mediaRecorder.state === "recording") {
        mediaRecorder.stop();
        logger.warn("MediaRecorder stopped during cleanup.");
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on mount

  React.useEffect(() => {
    const playVideoContent = async (videoUrl) => {
      if (questionVideoRef.current && videoUrl) {
        questionVideoRef.current.src = videoUrl;
        try {
          await questionVideoRef.current.play();
        } catch (e) {
          logger.error("Error playing video content.", { error: e.toString(), videoUrl });
          toast({ title: "Video Playback Error", description: "Could not play video. Please check console.", variant: "destructive" });
        }
      }
    };

    if (currentPhase === "overview" && positionOverviewVideoUrl) {
        playVideoContent(positionOverviewVideoUrl);
    } else if (currentPhase === "question" && questions[currentQuestionIndex]?.videoUrl) {
        playVideoContent(questions[currentQuestionIndex].videoUrl);
    } else if (currentPhase === "clarification" && questions[currentQuestionIndex]?.clarificationVideoUrl) {
        playVideoContent(questions[currentQuestionIndex].clarificationVideoUrl);
    }
  }, [currentPhase, currentQuestionIndex, questions, positionOverviewVideoUrl, toast]);


  const startRecording = () => {
    if (!stream) {
        logger.error("Attempted to record without a media stream.");
        toast({ title: "Camera Not Ready", description: "Please wait for the camera to initialize.", variant: "destructive"});
        return;
    }
    
    const supportedMimeType = SUPPORTED_MIME_TYPES.find(type => MediaRecorder.isTypeSupported(type));

    if (!supportedMimeType) {
        logger.error("No supported MIME type found for MediaRecorder.");
        toast({ title: "Recording Error", description: "Your browser does not support any required video formats.", variant: "destructive" });
        return;
    }
    
    logger.info(`Starting recording with MIME type: ${supportedMimeType}`);

    try {
        const recorder = new MediaRecorder(stream, { mimeType: supportedMimeType });
        const chunks = [];

        recorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
                chunks.push(e.data);
                logger.debug(`Received data chunk of size: ${e.data.size}`);
            } else {
                logger.warn("Received an empty data chunk from MediaRecorder.");
            }
        };

        recorder.onstop = () => {
            logger.info("Recording stopped.");
            if (chunks.length === 0) {
                logger.error("Recording stopped but no data chunks were received. The final video file will be empty.");
                toast({ title: "Recording Failed", description: "No video data was captured. Please try again or use the diagnostics tool.", variant: "destructive"});
                setRecording(false);
                return;
            }
            const blob = new Blob(chunks, { type: supportedMimeType });
            logger.info(`Blob created successfully. Size: ${blob.size}, Type: ${blob.type}`);
            
            // Here you would typically upload the blob
            console.log("Recording completed, blob created:", blob);
            
            toast({ title: "Response Recorded", description: "Your video response has been saved."});
            setRecording(false);
            handleNext();
        };
        
        recorder.onerror = (e) => {
            logger.error("MediaRecorder encountered an error.", { error: e.error.toString() });
            toast({ title: "Recording Error", description: `An error occurred during recording: ${e.error.name}`, variant: "destructive"});
            setRecording(false);
        };

        recorder.start();
        setMediaRecorder(recorder);
        setRecording(true);
        logger.info("MediaRecorder started.");

      } catch (error) {
        logger.error("Failed to create MediaRecorder instance.", { error: error.toString() });
        toast({ title: "Recording Failed", description: "Could not start recording. Please check console for errors.", variant: "destructive"});
      }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      logger.info("Stop recording requested by user.");
      mediaRecorder.stop(); 
    } else {
      logger.warn("Attempted to stop a recorder that was not active.");
    }
  };

  const handleNext = () => {
    setRecording(false); 
    if (currentPhase === "overview") {
        setCurrentPhase("question");
    } else if (currentPhase === "question" || currentPhase === "clarification_replay") {
        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
            setCurrentPhase("question"); 
        } else {
            setCurrentPhase("post_qna"); 
            if(onComplete) onComplete(); 
        }
    } else if (currentPhase === "clarification") {
        setCurrentPhase("clarification_replay"); 
        if (questionVideoRef.current && questions[currentQuestionIndex]?.videoUrl) {
            questionVideoRef.current.src = questions[currentQuestionIndex].videoUrl;
            questionVideoRef.current.play().catch(e => logger.error("Error replaying question video:", {error: e.toString()}));
        }
    }
  };
  
  const handlePlayClarification = () => {
    if (questions[currentQuestionIndex]?.clarificationVideoUrl) {
        setCurrentPhase("clarification");
    }
  };

  const currentQuestion = questions[currentQuestionIndex];
  const questionIdBase = `question-${currentQuestionIndex}`;

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-4xl mx-auto"
      aria-labelledby="interview-room-title"
    >
      <h1 id="interview-room-title" className="sr-only">Interview Room</h1>
      <div className="bg-slate-800 rounded-xl shadow-2xl overflow-hidden border border-slate-700">
        <div className="p-4 sm:p-6">
          
          <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden mb-6 border border-slate-700 shadow-inner">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover transform scaleX(-1)" 
              aria-label="Your camera preview"
            />
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentPhase + currentQuestionIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6 min-h-[150px] sm:min-h-[200px]" 
              role="region"
              aria-live="polite"
              aria-atomic="true"
            >
              {currentPhase === "overview" && positionOverviewVideoUrl && (
                <div className="text-center">
                  <h2 id="overview-title" className="text-xl sm:text-2xl font-semibold text-sky-300 mb-4">Position Overview</h2>
                  <video 
                    ref={questionVideoRef} 
                    controls 
                    className="w-full max-w-xl mx-auto rounded-lg shadow-lg aspect-video bg-slate-700" 
                    onEnded={handleNext} 
                    aria-labelledby="overview-title"
                  >
                    <track kind="captions" />
                  </video>
                  <Button onClick={handleNext} className="mt-4 bg-sky-500 hover:bg-sky-600 text-slate-900 w-full sm:w-auto" aria-label="Start Questions after overview">
                    Start Questions
                  </Button>
                </div>
              )}

              {(currentPhase === "question" || currentPhase === "clarification_replay") && currentQuestion && (
                <div>
                  <div className="mb-3 p-3 bg-slate-700 rounded-md text-center" aria-label={`Interviewer: ${currentQuestion.persona?.name || "Interviewer"}`}>
                    <p className="text-md sm:text-lg font-medium text-sky-300">{currentQuestion.persona?.name || "Interviewer"}</p>
                    {currentQuestion.persona?.role_title && <p className="text-xs sm:text-sm text-slate-400">{currentQuestion.persona.role_title}</p>}
                  </div>
                  <h3 id={`${questionIdBase}-title`} className="text-lg sm:text-xl font-semibold text-sky-300 mb-2">
                    Question {currentQuestionIndex + 1}
                  </h3>
                  <p id={`${questionIdBase}-text`} className="text-slate-300 mb-4 text-sm sm:text-base">{currentQuestion.text}</p>
                  {currentQuestion.videoUrl && (
                     <video 
                        ref={questionVideoRef} 
                        controls 
                        className="w-full max-w-xl mx-auto rounded-lg shadow-lg mb-4 aspect-video bg-slate-700" 
                        aria-labelledby={`${questionIdBase}-title ${questionIdBase}-text`}
                     >
                        <track kind="captions" />
                     </video>
                  )}
                </div>
              )}
              
              {currentPhase === "clarification" && currentQuestion?.clarificationVideoUrl && (
                 <div className="text-center">
                    <h3 id="clarification-title" className="text-lg sm:text-xl font-semibold text-sky-300 mb-2">Clarification</h3>
                    <video 
                        ref={questionVideoRef} 
                        controls 
                        className="w-full max-w-xl mx-auto rounded-lg shadow-lg aspect-video bg-slate-700" 
                        onEnded={handleNext} 
                        aria-labelledby="clarification-title"
                    >
                        <track kind="captions" />
                    </video>
                     <Button onClick={handleNext} className="mt-4 bg-sky-500 hover:bg-sky-600 text-slate-900 w-full sm:w-auto" aria-label="Replay original question after clarification">
                        Got it, Replay Question
                    </Button>
                 </div>
              )}

              {currentPhase === "post_qna" && (
                <div className="text-center">
                    <h2 className="text-xl sm:text-2xl font-semibold text-sky-300 mb-4">Interview Complete!</h2>
                    <p className="text-slate-300 mb-4 text-sm sm:text-base">Thank you for your responses. You can now close this window or return to dashboard if applicable.</p>
                    <Button onClick={() => { toast({title: "Finished!", description: "You can close this window."}) }} className="bg-green-500 hover:bg-green-600 text-slate-900 w-full sm:w-auto" aria-label="Finish interview">
                        Finish
                    </Button>
                </div>
              )}

            </motion.div>
          </AnimatePresence>

          {(currentPhase === "question" || currentPhase === "clarification_replay") && !recording && currentQuestion && (
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4">
              <Button
                onClick={startRecording}
                className="w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white"
                disabled={recording}
                aria-label={`Record answer for question ${currentQuestionIndex + 1}`}
              >
                <Play className="w-4 h-4 mr-2" aria-hidden="true" />
                Record Answer
              </Button>
              {currentQuestion?.clarificationVideoUrl && currentPhase === "question" && (
                 <Button
                    onClick={handlePlayClarification}
                    variant="outline"
                    className="w-full sm:w-auto text-sky-400 border-sky-400 hover:bg-sky-400 hover:text-slate-900"
                    aria-label={`Need clarification for question ${currentQuestionIndex + 1}`}
                 >
                    <HelpCircle className="w-4 h-4 mr-2" aria-hidden="true" /> Need Clarification?
                 </Button>
              )}
            </div>
          )}
          {recording && (
             <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4">
                <Button
                    onClick={stopRecording}
                    variant="outline"
                    className="w-full sm:w-auto border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                    aria-label={`Stop and submit answer for question ${currentQuestionIndex + 1}`}
                >
                    <Square className="w-4 h-4 mr-2" aria-hidden="true" />
                    Stop & Submit Answer
                </Button>
             </div>
          )}
        </div>

        <div className="bg-slate-900/50 px-4 sm:px-6 py-3 sm:py-4" aria-live="polite">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-400">
            <span>
                {currentPhase !== "overview" && currentPhase !== "post_qna" ? 
                `Question ${currentQuestionIndex + 1} of ${questions.length}` : 
                currentPhase === "overview" ? "Position Overview" : "Finalizing..."}
            </span>
            {recording && (
              <motion.div
                animate={{ opacity: [1, 0.5] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="flex items-center text-red-400"
                aria-label="Recording in progress"
              >
                <div className="w-2 h-2 bg-red-500 rounded-full mr-2" aria-hidden="true" />
                Recording
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </motion.section>
  );
};

export default InterviewRoom;