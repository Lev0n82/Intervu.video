
import React from 'react';

export const ParticipantInvitationEmailTemplate = ({
    participantName,
    title,
    description,
    inviteLink,
    expiryDate,
    organizationName,
    type = 'Interview' // 'Interview' or 'Survey'
}) => {
    
    // Styling
    const styles = {
        container: {
            fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
            maxWidth: '600px',
            margin: '0 auto',
            backgroundColor: '#ffffff',
            borderRadius: '12px',
            overflow: 'hidden',
            border: '1px solid #e2e8f0'
        },
        header: {
            backgroundColor: '#0f172a',
            padding: '24px',
            textAlign: 'center'
        },
        logoText: {
            color: '#ffffff',
            fontSize: '24px',
            fontWeight: 'bold',
            textDecoration: 'none'
        },
        content: {
            padding: '32px 24px',
            color: '#334155',
            lineHeight: '1.6'
        },
        greeting: {
            fontSize: '18px',
            fontWeight: '600',
            color: '#0f172a',
            marginBottom: '16px'
        },
        card: {
            backgroundColor: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: '8px',
            padding: '20px',
            marginBottom: '24px'
        },
        title: {
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#2563eb',
            marginBottom: '8px',
            display: 'block'
        },
        description: {
            fontSize: '14px',
            color: '#64748b',
            margin: 0
        },
        buttonContainer: {
            textAlign: 'center',
            margin: '32px 0'
        },
        button: {
            backgroundColor: '#2563eb',
            color: '#ffffff',
            padding: '14px 28px',
            borderRadius: '8px',
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '16px',
            display: 'inline-block',
            boxShadow: '0 4px 6px -1px rgba(37, 99, 235, 0.2)'
        },
        infoText: {
            fontSize: '13px',
            color: '#64748b',
            textAlign: 'center',
            marginBottom: '24px'
        },
        footer: {
            backgroundColor: '#f1f5f9',
            padding: '20px',
            textAlign: 'center',
            fontSize: '12px',
            color: '#94a3b8'
        }
    };

    return (
        <div style={styles.container}>
            <div style={styles.header}>
                <span style={styles.logoText}>Intervu.video</span>
            </div>
            
            <div style={styles.content}>
                <div style={styles.greeting}>Hello {participantName || 'there'},</div>
                
                <p>You have been invited to participate in a video {type.toLowerCase()} for <strong>{organizationName}</strong>.</p>
                
                <div style={styles.card}>
                    <span style={styles.title}>{title}</span>
                    {description && <p style={styles.description}>{description}</p>}
                </div>

                <div style={styles.buttonContainer}>
                    <a href={inviteLink} style={styles.button}>
                        Start {type}
                    </a>
                </div>
                
                <div style={styles.infoText}>
                    Click the button above to start. No login required.<br/>
                    {expiryDate && <span>This invitation is valid until {new Date(expiryDate).toLocaleDateString()}.</span>}
                </div>
            </div>
            
            <div style={styles.footer}>
                <p>If you're having trouble, please copy and paste this link into your browser:</p>
                <p style={{wordBreak: 'break-all', color: '#2563eb'}}>{inviteLink}</p>
                <div style={{marginTop: '20px', borderTop: '1px solid #cbd5e1', paddingTop: '20px'}}>
                    &copy; {new Date().getFullYear()} Intervu.video. All rights reserved.
                </div>
            </div>
        </div>
    );
};
