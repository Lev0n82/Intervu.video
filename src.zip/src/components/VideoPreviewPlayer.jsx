import React, { useRef, useState } from 'react';
import { Play, Pause, Trash2, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';

const VideoPreviewPlayer = ({ url, onRemove, label = "Video" }) => {
  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="relative group rounded-lg overflow-hidden border border-border bg-black aspect-video shadow-sm">
      {/* Mini Player */}
      <video
        ref={videoRef}
        src={url}
        className="w-full h-full object-cover"
        onEnded={() => setIsPlaying(false)}
        onPause={() => setIsPlaying(false)}
        onPlay={() => setIsPlaying(true)}
      />
      
      {/* Overlays */}
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
        <Button 
          variant="secondary" 
          size="icon" 
          className="rounded-full w-10 h-10" 
          onClick={togglePlay}
          type="button"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
        </Button>
        
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
             <Button variant="secondary" size="icon" className="rounded-full w-8 h-8" type="button">
                <Maximize2 className="w-4 h-4" />
             </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-4xl p-0 bg-black border-zinc-800">
             <div className="relative aspect-video w-full flex items-center justify-center">
                 <video src={url} controls autoPlay className="max-h-[80vh] w-full" />
             </div>
          </DialogContent>
        </Dialog>

        {onRemove && (
            <Button 
            variant="destructive" 
            size="icon" 
            className="rounded-full w-8 h-8" 
            onClick={onRemove}
            type="button"
            >
            <Trash2 className="w-4 h-4" />
            </Button>
        )}
      </div>
      
      {/* Status Badge (Static) */}
      <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-sm rounded text-xs text-white font-medium">
        {label}
      </div>
    </div>
  );
};

export default VideoPreviewPlayer;