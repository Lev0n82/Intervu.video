import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Building, Briefcase, ChevronRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CreateOrganizationDialog = ({ open, onOpenChange, onOrganizationCreated }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    orgName: '',
    department: '',
    title: '',
  });

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({...prev, [id]: value}));
  };

  const handleCreateOrganization = async (e) => {
    e.preventDefault();
    if (!formData.orgName.trim()) {
      toast({
        variant: 'destructive',
        title: 'Organization name is required.',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Instead of calling Supabase directly, we pass the data back to the parent
      if(onOrganizationCreated) {
        onOrganizationCreated(formData);
      }
      onOpenChange(false);
      setFormData({ orgName: '', department: '', title: '' });
    } catch (error) {
      console.error('Error in dialog:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to proceed',
        description: error.message || 'An unexpected error occurred.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-card to-background/80 backdrop-blur-xl border-border/50">
        <DialogHeader>
          <DialogTitle className="flex items-center text-xl">
            <Building className="mr-3 h-6 w-6 text-primary"/>
            Create Your Organization
          </DialogTitle>
          <DialogDescription>
            You're the first one here! Set up your team's workspace.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleCreateOrganization} className="space-y-6">
          <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="orgName">Organization Name*</Label>
                <Input id="orgName" value={formData.orgName} onChange={handleInputChange} placeholder="Your Company Inc." required disabled={isSubmitting} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Your Department</Label>
                <Input id="department" value={formData.department} onChange={handleInputChange} placeholder="e.g., Human Resources" disabled={isSubmitting} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="title">Your Title</Label>
                <Input id="title" value={formData.title} onChange={handleInputChange} placeholder="e.g., Hiring Manager" disabled={isSubmitting} />
              </div>
          </div>
          <DialogFooter className="gap-2 sm:justify-end">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || !formData.orgName.trim()}>
              {isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <ChevronRight className="mr-2 h-4 w-4" />
              )}
              {isSubmitting ? 'Creating...' : 'Create & Continue'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateOrganizationDialog;