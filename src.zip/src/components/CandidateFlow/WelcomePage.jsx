import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import Logo from '@/components/Logo';
import { Loader2 } from 'lucide-react';

const CandidateWelcomePage = () => {
  const { submissionToken } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [submission, setSubmission] = useState(null);
  
  const [name, setName] = useState('');
  const [consent, setConsent] = useState(false);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    const fetchInterviewDetails = async () => {
      setLoading(true);
      const { data: subData, error: subError } = await supabase
        .from('interview_submissions')
        .select('*, interviews(*, interview_templates(name, description))')
        .eq('submission_token', submissionToken)
        .single();
        
      if (subError || !subData) {
        toast({ variant: 'destructive', title: 'Invalid Interview Link', description: 'This interview link is invalid or has expired.' });
        navigate('/');
        return;
      }

      setSubmission(subData);
      setName(subData.candidate_name || subData.candidate_email || '');
      setLoading(false);
    };
    fetchInterviewDetails();
  }, [submissionToken, toast, navigate]);

  const handleStart = async () => {
    if (!name.trim()) {
      toast({ variant: 'destructive', title: 'Name Required', description: 'Please enter your full name.' });
      return;
    }
    if (!consent) {
      toast({ variant: 'destructive', title: 'Consent Required', description: 'You must consent to be recorded to proceed.' });
      return;
    }

    setUpdating(true);
    const { error } = await supabase
      .from('interview_submissions')
      .update({
        candidate_name: name,
        consent_given_at: new Date().toISOString(),
        status: 'started'
      })
      .eq('id', submission.id);

    if (error) {
      toast({ variant: 'destructive', title: 'Error Starting Interview', description: error.message });
      setUpdating(false);
    } else {
      navigate(`/interview/take/${submission.id}/device-check`);
    }
  };
  
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-slate-900 text-slate-100"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  if (!submission) return null;

  const interview = submission.interviews;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-4 aurora-background">
      <div className="absolute top-8">
        <Logo />
      </div>
      <Card className="w-full max-w-lg bg-card/80 backdrop-blur-lg border-border/50 text-card-foreground">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-primary">Welcome to Your Interview!</CardTitle>
          <CardDescription>You're invited to an interview for the role of {interview.interview_templates.name}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-sm text-muted-foreground text-center">{interview.interview_templates.description}</p>
          <div className="space-y-2">
            <Label htmlFor="name">Please confirm your full name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your Full Name" required className="bg-background/70"/>
          </div>
          <div className="flex items-start space-x-3">
            <Checkbox id="consent" checked={consent} onCheckedChange={setConsent} className="mt-1" aria-labelledby="consent-label" />
            <div className="grid gap-1.5 leading-none">
                <label
                    htmlFor="consent"
                    id="consent-label"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                    I consent to being recorded (video and audio) for this interview.
                </label>
                <p className="text-xs text-muted-foreground">
                   Your responses will be used for evaluation purposes only.
                </p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex-col gap-4">
          <Button onClick={handleStart} disabled={updating || !consent || !name} className="w-full">
            {updating ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : null}
            Proceed to Device Check
          </Button>
          <p className="text-xs text-muted-foreground">This interview should take approximately 15 minutes.</p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default CandidateWelcomePage;