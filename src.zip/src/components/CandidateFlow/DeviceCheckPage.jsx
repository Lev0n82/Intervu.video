
import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { CheckCircle, XCircle, Video, Mic, Volume2, Loader2, CameraOff, RefreshCw, ArrowRight } from "lucide-react";
import { useNavigate, useParams, Link } from "react-router-dom";
import Logo from "@/components/Logo";
import { supabase } from "@/lib/customSupabaseClient";

const DeviceCheckPage = () => {
    const { submissionToken } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();
    
    // State
    const [loading, setLoading] = useState(true);
    const [participant, setParticipant] = useState(null);
    const [error, setError] = useState(null);

    const [checks, setChecks] = useState({
        camera: null,
        microphone: null,
        speaker: null,
    });
    const videoRef = useRef(null);
    const [stream, setStream] = useState(null);
    const [isTesting, setIsTesting] = useState(true);
    const [starting, setStarting] = useState(false);

    // Fetch Participant Data
    useEffect(() => {
        const init = async () => {
            if (!submissionToken) {
                setError("No token provided");
                setLoading(false);
                return;
            }

            try {
                // Use RPC to get submission data publicly
                const { data, error } = await supabase.rpc('get_submission_by_token', {
                    p_token: submissionToken
                });

                if (error) throw error;
                if (!data) throw new Error("Submission not found or completed");

                setParticipant({
                    name: data.submission.candidate_name,
                    email: data.submission.candidate_email,
                    interviewTitle: data.interview.title
                });
            } catch (err) {
                console.error("Device check init error:", err);
                navigate('/participant/error/INVALID'); // Redirect to error page
            } finally {
                setLoading(false);
            }
        };

        init();
    }, [submissionToken, navigate]);

    // Device Check Logic (reused/refined)
    const cleanupStream = useCallback(() => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
    }, [stream]);

    const runDeviceCheck = useCallback(async (device) => {
        setChecks(prev => ({ ...prev, [device]: 'testing' }));
        try {
            switch (device) {
                case "camera": {
                    cleanupStream();
                    const newStream = await navigator.mediaDevices.getUserMedia({ 
                        video: { width: { ideal: 1280 }, height: { ideal: 720 } }
                    });
                    setStream(newStream);
                    if (videoRef.current) videoRef.current.srcObject = newStream;
                    setChecks(prev => ({ ...prev, camera: true }));
                    return true;
                }
                case "microphone": {
                    const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    setChecks(prev => ({ ...prev, microphone: true }));
                    audioStream.getTracks().forEach(track => track.stop());
                    return true;
                }
                case "speaker": {
                    const audio = new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZRA0PVqzn77BdGAg+ltryxnMpBSl+zPLaizsIGGS57OihUBELTKXh8bllHgU2jdXzzn0vBSF1xe/glEILElyx6OyrWBUIQ5zd8sFuJAUuhM/z1YU2Bhxqvu7mnEYODlOq5O+zYBoGPJPY88p2KwUme8rx3I4+CRZiturqpVITC0mi4PK8aB8GM4nU8tGAMQYfcsLu45ZFDBFYr+ftrVoXCECY3PLEcSYELIHO8diJOQgZaLvt559NEAxPqOPwtmMcBjiP1/PMeS0GI3fH8N2RQAoUXrTp66hVFApGnt/yvmwhBTCG0fPTgjQGHW/A7eSaRQ0PVqzl77BeGQc+ltrzxnUoBSh+zPDaizsIGGS56+mjTxELTKXh8bllHgU1jdT0z3wvBSJ0xe/glEILElyx6OyrWRUIRJve8sFuJAUug8/y1oU2Bhxqvu3mnUYODlOq5O+zYRsGPJLZ88p3KgUme8rx3I4+CRVht+rqpVMSC0mh4fK8aiAFM4nU8tGAMQYfccPu45ZFDBFYr+ftrVwWCECY3PLEcSYGK4DN8tiIOQgZZ7zs56BODwxPp+PxtmQcBjiP1/PMeywGI3fH8N+RQAoUXrTp66hWEwlGnt/yv2wiBDCG0fPTgzQHHG/A7eSaSw0PVqzl77BeGQc+ltvyxnUoBSh9y/HajDsIF2W56+mjUREKTKPi8blnHgU1jdTy0HwvBSJ0xPDglEQKElux6eyrWRUJQ5vd88FwJAug8/y1oY2Bhxqvu3mnUYODlKp5e+zYRsGOpPY88p3KgUmecnw3Y4/CBVht+rqpVMSC0mh4fK9aiAFM4nS89GAMQYfccLv45dGCxFYrufur1sYB0CY3PLEcSYGK4DN8tiIOQgZZ7vt56BODwxPp+PxtmQdBTiP1/PMeywGI3bH8d+RQQkUXrTp66hWEwlGnt/yv2wiBDCG0fPTgzQHHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3Bhxqvu3mnUYODlKp5e+zYRsGOpPY88p3KwUlecnw3Y8/CBVht+rqpVMSC0mh4fK9aiAFMojT89GBMgUfccLv45dGDBBYrufur1sYB0CX3fLEcicFKoDN8tiKOQgZZ7vt56BODwxPp+PxtmQdBTeP1/PMey0FI3bH8d+RQQsUXbPq66hWEwlGnt/yv2wiBDCG0fPTgzUGHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3Bhxqvu3mnUgNDlKp5e+zYRsGOpPY88p3KwUlecnw3Y8/CBVht+rqpVMSC0mh4fK9aiAFMojT89GBMgUfccLv45dGDBBYrufur1sYB0CX3fLEcicFKoDN8tiKOQgZZ7vt56BODwxPp+PxtmQdBTeP1/PMey0FI3bH8d+RQQsUXbPq66hWFAlEnt/yv2wiBDCG0fPTgzUGHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3BhxpvuzmnnsPGy4=");
                    await audio.play();
                    setChecks(prev => ({ ...prev, speaker: true }));
                    return true;
                }
                default: return false;
            }
        } catch (error) {
            setChecks(prev => ({ ...prev, [device]: false }));
            return false;
        }
    }, [cleanupStream]);

    const runAllChecks = useCallback(async () => {
        if (!participant) return;
        setIsTesting(true);
        await Promise.all([runDeviceCheck('camera'), runDeviceCheck('microphone'), runDeviceCheck('speaker')]);
        setIsTesting(false);
    }, [runDeviceCheck, participant]);

    useEffect(() => {
        if (participant) runAllChecks();
        return () => cleanupStream();
    }, [participant, runAllChecks, cleanupStream]);


    const handleStartInterview = async () => {
        if (!checks.camera || !checks.microphone) {
            toast({ title: "Equipment Check Failed", description: "Camera and microphone are required.", variant: "destructive" });
            return;
        }

        setStarting(true);
        try {
            const { error } = await supabase.rpc('start_interview_session', { p_token: submissionToken });
            if (error) throw error;
            navigate(`/interview/start/${submissionToken}`);
        } catch (err) {
            console.error("Start error:", err);
            toast({ title: "Error", description: "Could not start interview session.", variant: "destructive" });
            setStarting(false);
        }
    };

    if (loading) return <div className="min-h-screen bg-slate-900 flex items-center justify-center"><Loader2 className="w-8 h-8 text-sky-400 animate-spin" /></div>;

    if (!participant) return null; // Error handled in useEffect

    const CheckItem = ({ deviceName, status, onTest, icon }) => (
        <div className="flex items-center justify-between p-3 bg-slate-700 rounded-lg border border-slate-600">
            <div className="flex items-center space-x-3">
                {React.cloneElement(icon, { className: "w-5 h-5 text-sky-400" })}
                <span className="text-slate-200">{deviceName}</span>
            </div>
            <div className="flex items-center space-x-2">
                {status === 'testing' && <Loader2 className="w-5 h-5 animate-spin text-sky-400" />}
                {status === true && <CheckCircle className="w-6 h-6 text-green-400" />}
                {status === false && <XCircle className="w-6 h-6 text-red-400" />}
                {(status === null || status === false) && (
                    <Button onClick={onTest} variant="outline" size="sm" className="text-sky-400 border-sky-400 hover:bg-sky-400 hover:text-slate-900">Test</Button>
                )}
            </div>
        </div>
    );

    const isReady = checks.camera === true && checks.microphone === true;

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-4">
            <div className="absolute top-8 left-0 right-0 flex justify-center"><Logo /></div>
            
            <div className="w-full max-w-lg mx-auto mb-6 text-center">
                 <h2 className="text-xl text-slate-300">Welcome, <span className="text-white font-semibold">{participant.name}</span></h2>
                 <p className="text-slate-500 text-sm">You are about to start: <span className="text-sky-400">{participant.interviewTitle}</span></p>
                 <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-xs px-3 py-2 rounded-full inline-block mt-4">
                     Equipment check required before starting
                 </div>
            </div>

            <motion.section
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-lg mx-auto bg-slate-800 rounded-xl shadow-2xl p-6 md:p-8 border border-slate-700"
            >
                <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden mb-6 border border-slate-700 shadow-inner flex items-center justify-center relative">
                    {stream ? (
                        <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover transform scaleX(-1)"></video>
                    ) : (
                         <div className="text-slate-400 flex flex-col items-center">
                            {checks.camera === 'testing' ? <Loader2 className="w-6 h-6 animate-spin"/> : <CameraOff className="w-8 h-8"/>}
                        </div>
                    )}
                </div>

                <div className="space-y-4">
                    <CheckItem deviceName="Camera" status={checks.camera} onTest={() => runDeviceCheck("camera")} icon={<Video />} />
                    <CheckItem deviceName="Microphone" status={checks.microphone} onTest={() => runDeviceCheck("microphone")} icon={<Mic />} />
                    <CheckItem deviceName="Speakers" status={checks.speaker} onTest={() => runDeviceCheck("speaker")} icon={<Volume2 />} />
                </div>

                <div className="mt-8">
                    <Button 
                        className={`w-full text-lg h-12 transition-all ${isReady ? 'bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-900/20' : 'bg-slate-700 text-slate-400'}`}
                        onClick={handleStartInterview}
                        disabled={!isReady || starting}
                    >
                        {starting ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : (isReady ? <span className="flex items-center justify-center">Start Interview <ArrowRight className="ml-2 w-5 h-5"/></span> : "Complete Checks to Start")}
                    </Button>
                </div>
            </motion.section>
        </div>
    );
};

export default DeviceCheckPage;
