
import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { Sparkles, Video, Clock, AlertCircle } from 'lucide-react';

const AutoGenerationConfirmationModal = ({ 
    open, 
    onOpenChange, 
    onConfirm, 
    questionCount, 
    hasIntroMissing, 
    isGenerating = false,
    progress = 0,
    total = 0,
    error = null,
    questions = [], // Accepted as prop per requirements
    template = null // Accepted as prop per requirements
}) => {
  const missingCount = questionCount + (hasIntroMissing ? 1 : 0);
  const estimatedMinTime = missingCount * 1; 
  const estimatedMaxTime = missingCount * 2;

  return (
    <AlertDialog open={open} onOpenChange={isGenerating ? undefined : onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-primary">
            <Sparkles className="h-5 w-5 text-purple-600" />
            Auto-Generate & Activate?
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-4 pt-4">
            {!isGenerating ? (
                <>
                    <p className="text-slate-700">
                        You have <strong>{missingCount} missing video{missingCount !== 1 ? 's' : ''}</strong> (
                        {[hasIntroMissing && 'Introduction', questionCount > 0 && `${questionCount} Question${questionCount !== 1 ? 's' : ''}`].filter(Boolean).join(' + ')}
                        ).
                    </p>
                    
                    <div className="bg-slate-50 p-4 rounded-lg space-y-3 text-sm border border-slate-100">
                        <div className="flex gap-3">
                            <Video className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
                            <span className="text-slate-600">Random AI personas will be automatically assigned to any questions missing them.</span>
                        </div>
                        <div className="flex gap-3">
                            <Clock className="h-4 w-4 text-orange-500 mt-0.5 shrink-0" />
                            <span className="text-slate-600">Estimated time: <strong>{estimatedMinTime}-{estimatedMaxTime} minutes</strong>. All videos will be queued in the background.</span>
                        </div>
                        <div className="flex gap-3">
                            <AlertCircle className="h-4 w-4 text-purple-500 mt-0.5 shrink-0" />
                            <span className="text-slate-600">The template will be activated immediately, but candidates cannot start interviews until generation completes.</span>
                        </div>
                    </div>

                    <p className="text-sm text-slate-500">Proceed with auto-generation?</p>
                </>
            ) : (
                <div className="space-y-6 py-4">
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm text-slate-600">
                            <span>Processing videos...</span>
                            <span>{total > 0 ? Math.round((progress / total) * 100) : 0}%</span>
                        </div>
                        <Progress value={total > 0 ? (progress / total) * 100 : 0} className="h-2" />
                    </div>
                    <p className="text-center text-sm text-slate-500 animate-pulse">
                        Assigning personas and queuing generation...
                    </p>
                    {error && (
                        <div className="p-3 bg-red-50 text-red-600 text-sm rounded-md flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}
                </div>
            )}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          {!isGenerating && (
              <AlertDialogCancel disabled={isGenerating}>Cancel</AlertDialogCancel>
          )}
          {!isGenerating ? (
              <AlertDialogAction 
                onClick={(e) => {
                    e.preventDefault();
                    onConfirm();
                }} 
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Start Auto-Generation
              </AlertDialogAction>
          ) : (
              // Only show Close if there's an error, otherwise we wait for redirect
              error && <AlertDialogAction onClick={() => onOpenChange(false)}>Close</AlertDialogAction>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AutoGenerationConfirmationModal;
