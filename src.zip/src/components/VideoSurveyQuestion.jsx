
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Trash2, GripVertical, Video, CheckCircle, Upload, Wand2 } from 'lucide-react';
import VideoPreviewPlayer from '@/components/VideoPreviewPlayer';
import GenerationTimer from '@/components/GenerationTimer';

const VideoField = ({ 
  label, 
  videoUrl, 
  onRecord, 
  onUpload, 
  onGenerate, 
  onRemove, 
  generationState, 
  disabled,
  fieldId 
}) => {
  const isGenerating = generationState?.status === 'pending';
  const isSuccess = generationState?.status === 'success';
  const hasVideo = !!videoUrl;

  return (
    <div className="space-y-2">
       <Label className="flex items-center justify-between">
        <span className="flex items-center">
             {hasVideo && <CheckCircle className="w-4 h-4 mr-2 text-green-500" />}
             {label}
        </span>
        {isSuccess && (
            <motion.span 
                initial={{ opacity: 0, scale: 0.9 }} 
                animate={{ opacity: 1, scale: 1 }}
                className="text-xs font-medium text-green-600 bg-green-50 dark:bg-green-900/30 px-2 py-0.5 rounded-full border border-green-200 dark:border-green-800"
            >
                Generated
            </motion.span>
        )}
      </Label>
      
      <div className="min-h-[120px] bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-200 dark:border-slate-700 p-1">
         {isGenerating ? (
             <div className="h-full w-full flex flex-col items-center justify-center p-6 space-y-3 min-h-[180px]">
                 <GenerationTimer startTime={generationState.startTime} estimatedDuration={generationState.estimatedDuration} />
                 <p className="text-xs text-muted-foreground text-center max-w-[200px]">
                    Generating...
                 </p>
             </div>
         ) : hasVideo ? (
             <VideoPreviewPlayer 
                url={videoUrl} 
                onRemove={onRemove} 
                label={label}
             />
         ) : (
             <div className="h-full flex flex-col justify-center gap-3 p-4">
                 <div className="flex gap-2">
                    <Button type="button" variant="outline" className="flex-1 h-20 flex-col gap-2" onClick={onRecord} disabled={disabled}>
                    <Video className="w-6 h-6 mb-1 text-slate-500" /> 
                    <span>Record</span>
                    </Button>
                    <Button type="button" variant="outline" className="flex-1 h-20 flex-col gap-2" onClick={onUpload} disabled={disabled}>
                    <Upload className="w-6 h-6 mb-1 text-slate-500" /> 
                    <span>Upload</span>
                    </Button>
                 </div>
                 <Button type="button" variant="secondary" className="w-full gap-2 text-indigo-600" onClick={onGenerate} disabled={disabled}>
                    <Wand2 className="w-4 h-4" /> Generate with AI
                </Button>
             </div>
         )}
      </div>
    </div>
  );
};

const VideoSurveyQuestion = ({ 
    question, 
    index, 
    onQuestionChange, 
    onRemoveQuestion, 
    onRecordVideo, 
    onUploadVideo, 
    onGenerateVideo, 
    disabled,
    generationStatus = {}
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 bg-card/80 dark:bg-slate-700/50 rounded-lg border border-border space-y-6 shadow-sm"
    >
      <div className="flex justify-between items-start border-b border-border pb-4">
        <div className="flex items-center">
          <GripVertical className="w-5 h-5 text-muted-foreground mr-2 cursor-grab" />
          <h3 className="text-lg font-medium text-card-foreground">Question {index + 1}</h3>
        </div>
        <Button type="button" variant="ghost" size="icon" onClick={() => onRemoveQuestion(question.id)} disabled={disabled}>
          <Trash2 className="w-5 h-5" />
        </Button>
      </div>
      
      <div>
        <Label htmlFor={`questionText-${question.id}`}>Question Summary Text</Label>
        <Textarea
          id={`questionText-${question.id}`}
          value={question.question_text}
          onChange={(e) => onQuestionChange(question.id, 'question_text', e.target.value)}
          placeholder="e.g., Describe your experience with our new feature."
          required
          className="mt-1"
          disabled={disabled}
        />
        <p className="text-xs text-muted-foreground mt-1">This text is for your reference and will not be shown to the participant.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
         <VideoField 
            label="Question Video" 
            videoUrl={question.question_video_url}
            generationState={generationStatus['question_video_url']}
            onRecord={() => onRecordVideo(question.id, 'question_video_url')}
            onUpload={() => onUploadVideo(question.id, 'question_video_url')}
            onGenerate={() => onGenerateVideo(question.id, 'question_video_url')}
            onRemove={() => onQuestionChange(question.id, 'question_video_url', '')}
            disabled={disabled}
            fieldId="question_video_url"
         />

         <VideoField 
            label="Clarification Video" 
            videoUrl={question.clarification_video_url}
            generationState={generationStatus['clarification_video_url']}
            onRecord={() => onRecordVideo(question.id, 'clarification_video_url')}
            onUpload={() => onUploadVideo(question.id, 'clarification_video_url')}
            onGenerate={() => onGenerateVideo(question.id, 'clarification_video_url')}
            onRemove={() => onQuestionChange(question.id, 'clarification_video_url', '')}
            disabled={disabled}
            fieldId="clarification_video_url"
         />
      </div>
    </motion.div>
  );
};

export default VideoSurveyQuestion;
