
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Card, CardContent } from '@/components/ui/card';
import { Wand2, Bot, Edit3, Loader2, Settings, Eye, Sparkles, RefreshCw, Check, AlertTriangle, Cpu } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Slider } from '@/components/ui/slider';

const AIGenerationDialog = ({ 
    open, 
    onOpenChange, 
    onStartGeneration, 
    questionText, 
    personaId, 
    personas: propPersonas, 
    isGenerating, 
    isClarification = false 
}) => {
    const { activeOrganization, user } = useAuth();
    const { toast } = useToast();
    
    const [prompt, setPrompt] = useState(questionText || '');
    const [selectedPersonaId, setSelectedPersonaId] = useState(personaId || '');
    const [personas, setPersonas] = useState(propPersonas || []);
    const [isLoadingPersonas, setIsLoadingPersonas] = useState(false);
    
    // AI Config State
    const [provider, setProvider] = useState('luma'); // 'luma' | 'fallai'
    const [aiConfig, setAiConfig] = useState({
        systemPrompt: "You are a professional interviewer. Maintain a neutral but encouraging tone.",
        tone: "Professional",
        difficulty: "Medium"
    });
    
    // Fall.ai specific config
    const [fallaiConfig, setFallaiConfig] = useState({
        duration: 5,
        style: 'cinematic',
        quality: 'standard'
    });

    const [isEditingConfig, setIsEditingConfig] = useState(false);
    
    // Generation State
    const [isGeneratingQuestions, setIsGeneratingQuestions] = useState(false);
    const [generatedPreview, setGeneratedPreview] = useState(null);
    const [internalIsGenerating, setInternalIsGenerating] = useState(false);

    useEffect(() => {
        setPrompt(questionText || '');
        setSelectedPersonaId(personaId || '');
        setGeneratedPreview(null);
    }, [questionText, personaId, open]);

    useEffect(() => {
        const fetchPersonas = async () => {
            if (propPersonas && propPersonas.length > 0) {
                setPersonas(propPersonas);
                return;
            }

            if (!activeOrganization?.id) return;

            setIsLoadingPersonas(true);
            try {
                const { data, error } = await supabase
                    .from('personas')
                    .select('*')
                    .eq('organization_id', activeOrganization.id)
                    .is('deleted_at', null);

                if (error) throw error;
                setPersonas(data || []);
            } catch (error) {
                console.error("Error fetching personas:", error);
                toast({ title: "Error", description: "Could not load personas.", variant: "destructive" });
            } finally {
                setIsLoadingPersonas(false);
            }
        };

        if (open) {
            fetchPersonas();
            // Fetch saved config logic (omitted for brevity, same as previous)
        }
    }, [open, activeOrganization?.id, propPersonas, toast]);

    const handleGenerateSampleQuestions = async () => {
        if (!selectedPersonaId) {
            toast({ title: "Select Persona", description: "Please select a persona first.", variant: "destructive" });
            return;
        }
        
        setIsGeneratingQuestions(true);
        try {
            const { data, error } = await supabase.functions.invoke('generate-interview-questions', {
                body: {
                    prompt: prompt,
                    persona_id: selectedPersonaId,
                    config: aiConfig
                }
            });

            if (error) throw error;
            
            if (data && data.questions && data.questions.length > 0) {
                setGeneratedPreview(data.questions);
                toast({ title: "Questions Generated", description: "Check the preview below.", className: "bg-green-500 text-white" });
            }

        } catch (error) {
            console.error("Generation error:", error);
            toast({ title: "Generation Failed", description: "Could not generate sample questions.", variant: "destructive" });
        } finally {
            setIsGeneratingQuestions(false);
        }
    };

    const handleUseQuestion = (question) => {
        setPrompt(question);
        setGeneratedPreview(null);
    };

    const handleGenerateVideo = async () => {
        // 1. Pre-flight Validation
        if (!activeOrganization?.id) {
            toast({ title: "Permission Error", description: "No active organization found. Please reload.", variant: "destructive" });
            return;
        }
        if (!user) {
            toast({ title: "Authentication Error", description: "You must be signed in to generate videos.", variant: "destructive" });
            return;
        }
        if (!prompt || !selectedPersonaId) {
             toast({ title: "Missing Information", description: "Prompt and Persona are required.", variant: "destructive" });
             return;
        }

        // 2. Execution
        try {
            setInternalIsGenerating(true);
            
            // Pass provider specific options
            const options = {
                provider
            };
            
            if (provider === 'fallai') {
                options.duration = fallaiConfig.duration;
                options.style = fallaiConfig.style;
                options.quality = fallaiConfig.quality;
            }

            await onStartGeneration(prompt, selectedPersonaId, options);
        } catch (error) {
            console.error("CRITICAL: Generation Operation Failed", error);
            let errorMessage = "An unexpected error occurred.";
            if (error.message) errorMessage = error.message;
            toast({ title: "Generation Failed", description: errorMessage, variant: "destructive" });
        } finally {
            setInternalIsGenerating(false);
        }
    };

    const showLoading = isGenerating || internalIsGenerating;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center text-xl">
                        <Wand2 className="mr-2 h-5 w-5 text-primary" aria-hidden="true" />
                        Generate {isClarification ? "Clarification" : "Question"} Video
                    </DialogTitle>
                    <DialogDescription>
                        Generate an AI video of your persona speaking the script below.
                    </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6 py-4">
                    {/* Safeguard Warning for Clarification */}
                    {isClarification && (
                        <div className="bg-amber-50 border border-amber-200 rounded-md p-3 flex items-start text-sm text-amber-800">
                            <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 text-amber-600 flex-shrink-0" />
                            <p>
                                <strong>Clarification Mode:</strong> You are generating a video for the clarification/follow-up prompt.
                            </p>
                        </div>
                    )}
                    
                    {/* Provider Selection */}
                    <div className="flex gap-4 p-4 bg-slate-50 rounded-lg border">
                        <div className="w-1/2 space-y-2">
                             <Label className="flex items-center font-semibold">
                                <Cpu className="mr-2 h-4 w-4 text-primary"/> AI Provider
                             </Label>
                             <Select value={provider} onValueChange={setProvider}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="luma">Luma Dream Machine (High Quality)</SelectItem>
                                    <SelectItem value="fallai">Fall.ai (Fast Generation)</SelectItem>
                                </SelectContent>
                             </Select>
                        </div>
                        
                         {/* Fall.ai Specific Controls */}
                         {provider === 'fallai' && (
                             <div className="w-1/2 space-y-3 animate-in fade-in">
                                 <div>
                                     <div className="flex justify-between">
                                         <Label className="text-xs">Duration</Label>
                                         <span className="text-xs text-muted-foreground">{fallaiConfig.duration}s</span>
                                     </div>
                                     <Slider 
                                        value={[fallaiConfig.duration]} 
                                        min={1} max={60} step={1}
                                        onValueChange={(val) => setFallaiConfig({...fallaiConfig, duration: val[0]})}
                                        className="mt-2"
                                     />
                                 </div>
                                 <div className="flex gap-2">
                                     <div className="w-1/2">
                                         <Label className="text-xs">Style</Label>
                                         <Select value={fallaiConfig.style} onValueChange={(val) => setFallaiConfig({...fallaiConfig, style: val})}>
                                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="cinematic">Cinematic</SelectItem>
                                                <SelectItem value="realistic">Realistic</SelectItem>
                                                <SelectItem value="anime">Anime</SelectItem>
                                            </SelectContent>
                                         </Select>
                                     </div>
                                     <div className="w-1/2">
                                         <Label className="text-xs">Quality</Label>
                                         <Select value={fallaiConfig.quality} onValueChange={(val) => setFallaiConfig({...fallaiConfig, quality: val})}>
                                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="standard">Standard</SelectItem>
                                                <SelectItem value="high">High</SelectItem>
                                            </SelectContent>
                                         </Select>
                                     </div>
                                 </div>
                             </div>
                         )}
                    </div>

                    {/* 1. Persona Selection */}
                    <div className="space-y-2">
                        <Label htmlFor="ai-persona" className="flex items-center font-semibold">
                            <Bot className="mr-2 h-4 w-4 text-primary" aria-hidden="true"/>
                            Select Persona (Character Appearance)
                        </Label>
                        <div className="flex gap-2">
                            <Select value={selectedPersonaId} onValueChange={setSelectedPersonaId}>
                                <SelectTrigger id="ai-persona" className="w-full">
                                    <SelectValue placeholder={isLoadingPersonas ? "Loading personas..." : "Select a persona"} />
                                </SelectTrigger>
                                <SelectContent>
                                    {personas.length === 0 && !isLoadingPersonas ? (
                                        <div className="p-2 text-sm text-muted-foreground text-center">No personas found.</div>
                                    ) : (
                                        personas.map(p => (
                                            <SelectItem key={p.id} value={p.id}>
                                                <div className="flex items-center">
                                                    {p.name} 
                                                    {p.role_title && <span className="ml-2 text-xs text-muted-foreground">({p.role_title})</span>}
                                                </div>
                                            </SelectItem>
                                        ))
                                    )}
                                </SelectContent>
                            </Select>
                            <Button variant="outline" size="icon" onClick={() => { setIsLoadingPersonas(true); setTimeout(() => setIsLoadingPersonas(false), 500); }} title="Refresh Personas">
                                <RefreshCw className={`h-4 w-4 ${isLoadingPersonas ? 'animate-spin' : ''}`} />
                            </Button>
                        </div>
                    </div>

                    {/* 2. AI Configuration & Prompt */}
                    <Accordion type="single" collapsible className="w-full border rounded-lg px-4 bg-muted/10">
                        <AccordionItem value="config" className="border-none">
                            <AccordionTrigger className="hover:no-underline py-3">
                                <div className="flex items-center text-sm font-semibold text-muted-foreground">
                                    <Settings className="mr-2 h-4 w-4" />
                                    Text Generation Config
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="space-y-4 pt-2 pb-4">
                                {isEditingConfig ? (
                                    <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
                                        <div>
                                            <Label className="text-xs">System Prompt (Behavior)</Label>
                                            <Textarea 
                                                value={aiConfig.systemPrompt}
                                                onChange={(e) => setAiConfig({...aiConfig, systemPrompt: e.target.value})}
                                                className="mt-1 h-24 text-sm font-mono"
                                            />
                                        </div>
                                        <div className="flex justify-end gap-2">
                                            <Button size="sm" variant="ghost" onClick={() => setIsEditingConfig(false)}>Cancel</Button>
                                            <Button size="sm" onClick={() => setIsEditingConfig(false)}>Save Config</Button>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="bg-muted/30 p-3 rounded-md border space-y-2">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Current System Prompt</h4>
                                                <p className="text-sm mt-1 italic opacity-80">"{aiConfig.systemPrompt}"</p>
                                            </div>
                                            <Button size="sm" variant="ghost" className="h-6 px-2" onClick={() => setIsEditingConfig(true)}>
                                                <Edit3 className="h-3 w-3 mr-1" /> Edit
                                            </Button>
                                        </div>
                                    </div>
                                )}
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>

                    {/* 3. Script / Prompt Editor */}
                    <div className="space-y-2">
                        <div className="flex justify-between items-center">
                            <Label htmlFor="ai-prompt" className="flex items-center font-semibold">
                                <Edit3 className="mr-2 h-4 w-4 text-primary" aria-hidden="true"/>
                                {isClarification ? 'Clarification Script' : 'Question Script'} (Spoken by Character)
                            </Label>
                            <Button 
                                variant="outline" 
                                size="sm" 
                                className="h-7 text-xs" 
                                onClick={handleGenerateSampleQuestions}
                                disabled={isGeneratingQuestions || !selectedPersonaId}
                            >
                                {isGeneratingQuestions ? <Loader2 className="mr-1 h-3 w-3 animate-spin"/> : <Sparkles className="mr-1 h-3 w-3 text-purple-500"/>}
                                Generate Suggestions
                            </Button>
                        </div>
                        <Textarea 
                            id="ai-prompt" 
                            value={prompt} 
                            onChange={e => setPrompt(e.target.value)} 
                            rows={4} 
                            className="resize-none"
                            placeholder={isClarification 
                                ? "Enter the follow-up question or clarification text..." 
                                : "Enter the main question text..."}
                        />
                        <p className="text-xs text-muted-foreground text-right">
                            {prompt.length} characters
                        </p>
                    </div>

                    {/* 4. Generated Suggestions Preview */}
                    {generatedPreview && (
                        <div className="space-y-2 animate-in fade-in slide-in-from-bottom-4">
                            <Label className="flex items-center text-purple-600 font-semibold">
                                <Eye className="mr-2 h-4 w-4" /> Suggested Questions
                            </Label>
                            <Card className="bg-purple-50 border-purple-100">
                                <CardContent className="p-3 space-y-2">
                                    {generatedPreview.map((q, idx) => (
                                        <div key={idx} className="flex items-start gap-2 group">
                                            <Button 
                                                size="icon" 
                                                variant="ghost" 
                                                className="h-6 w-6 mt-0.5 text-purple-600 hover:text-purple-700 hover:bg-purple-200 shrink-0"
                                                onClick={() => handleUseQuestion(q)}
                                                title="Use this text"
                                            >
                                                <Check className="h-4 w-4" />
                                            </Button>
                                            <p className="text-sm text-purple-900 leading-relaxed pt-1">{q}</p>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </div>
                    )}
                </div>

                <DialogFooter className="sm:justify-between gap-4 border-t pt-4">
                    <div className="text-xs text-muted-foreground self-center hidden sm:block">
                        {selectedPersonaId ? "Ready to generate" : "Select a persona to continue"}
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto justify-end">
                        <Button variant="outline" onClick={() => onOpenChange(false)} disabled={showLoading}>
                            Cancel
                        </Button>
                        <Button onClick={handleGenerateVideo} disabled={!prompt || !selectedPersonaId || showLoading} className="min-w-[140px]">
                            {showLoading ? (
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" aria-hidden="true" />
                            ) : (
                                <Wand2 className="w-4 h-4 mr-2" aria-hidden="true" />
                            )}
                            {showLoading ? 'Generating...' : `Create ${isClarification ? 'Clarification' : ''} Video`}
                        </Button>
                    </div>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AIGenerationDialog;
