
import React from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle, Play } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const ReviewAnswers = ({ questions, answers, onComplete }) => {
    return (
        <div className="max-w-3xl mx-auto space-y-8 pb-12">
            <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-slate-100">Review Your Answers</h2>
                <p className="text-slate-400">Please check your responses before finishing the interview.</p>
            </div>

            <div className="space-y-4">
                {questions.map((q, index) => {
                    const answer = answers[q.id];
                    return (
                        <Card key={q.id} className="bg-slate-900 border-slate-800 overflow-hidden">
                            <CardContent className="p-4 flex flex-col sm:flex-row gap-4">
                                <div className="flex-1 space-y-2">
                                    <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Question {index + 1}</h3>
                                    <p className="text-slate-200">{q.question_text}</p>
                                </div>
                                <div className="sm:w-48 aspect-video bg-black rounded-md overflow-hidden border border-slate-800 relative group shrink-0">
                                    {answer ? (
                                        <video src={answer.url} className="w-full h-full object-cover" controls />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-xs text-slate-500 bg-slate-950">
                                            No Answer
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    );
                })}
            </div>

            <div className="flex justify-center pt-4">
                <Button 
                    size="lg" 
                    onClick={onComplete}
                    className="bg-green-600 hover:bg-green-500 text-white min-w-[200px] shadow-lg shadow-green-900/20"
                >
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Complete Interview
                </Button>
            </div>
        </div>
    );
};

export default ReviewAnswers;
