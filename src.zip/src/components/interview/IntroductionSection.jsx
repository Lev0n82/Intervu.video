
import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PlayCircle, CheckCircle } from 'lucide-react';

const IntroductionSection = ({ videoUrl, onWatched, onStart, watched }) => {
    const videoRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [hasEnded, setHasEnded] = useState(watched);

    const handlePlay = () => {
        if (videoRef.current) {
            videoRef.current.play();
            setIsPlaying(true);
        }
    };

    const handleEnded = () => {
        setIsPlaying(false);
        setHasEnded(true);
        if (onWatched) onWatched();
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-3xl mx-auto w-full space-y-8 p-4">
            <div className="text-center space-y-4">
                <h1 className="text-3xl font-bold text-slate-100">Welcome to Your Interview</h1>
                <p className="text-slate-400 max-w-lg mx-auto">
                    Please watch the introduction video below to understand the interview process and what we're looking for.
                </p>
            </div>

            <Card className="w-full bg-black border-slate-800 overflow-hidden shadow-2xl relative group">
                <CardContent className="p-0 aspect-video relative flex items-center justify-center">
                    {videoUrl ? (
                        <video
                            ref={videoRef}
                            src={videoUrl}
                            className="w-full h-full object-contain"
                            controls={hasEnded || isPlaying}
                            onEnded={handleEnded}
                            onPlay={() => setIsPlaying(true)}
                        />
                    ) : (
                        <div className="text-slate-500">No introduction video available.</div>
                    )}
                    
                    {!isPlaying && !hasEnded && videoUrl && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center backdrop-blur-[2px] transition-opacity group-hover:bg-black/30">
                            <Button 
                                size="lg" 
                                className="rounded-full h-20 w-20 bg-white/10 hover:bg-white/20 backdrop-blur-md border-2 border-white/30 text-white shadow-xl hover:scale-110 transition-transform"
                                onClick={handlePlay}
                            >
                                <PlayCircle className="w-10 h-10 fill-current" />
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>

            <div className="flex flex-col items-center gap-4">
                {hasEnded ? (
                    <div className="flex flex-col items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="flex items-center gap-2 text-green-400 bg-green-400/10 px-4 py-2 rounded-full text-sm font-medium">
                            <CheckCircle className="w-4 h-4" />
                            Introduction Watched
                        </div>
                        <Button 
                            size="lg" 
                            onClick={onStart}
                            className="bg-blue-600 hover:bg-blue-500 text-white min-w-[200px] shadow-lg shadow-blue-900/20"
                        >
                            Start Questions
                        </Button>
                    </div>
                ) : (
                    <p className="text-sm text-slate-500 italic">
                        You must watch the full video to proceed.
                    </p>
                )}
            </div>
        </div>
    );
};

export default IntroductionSection;
