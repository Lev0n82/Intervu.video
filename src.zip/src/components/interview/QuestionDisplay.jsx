
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { HelpCircle, Play } from 'lucide-react';
import AnswerTimer from './AnswerTimer';
import AnswerRecorder from './AnswerRecorder';
import ClarificationModal from './ClarificationModal';
import { motion, AnimatePresence } from 'framer-motion';

const QuestionDisplay = ({ 
    question, 
    index, 
    total, 
    onAnswerSubmitted, 
    trackVideoPlay, 
    trackClarification,
    videoPlayCount,
    clarificationUsed 
}) => {
    const [step, setStep] = useState('video'); // 'video' | 'answering'
    const [showClarification, setShowClarification] = useState(false);
    const [videoEnded, setVideoEnded] = useState(false);
    
    // Reset state when question changes
    useEffect(() => {
        setStep('video');
        setVideoEnded(false);
        setShowClarification(false);
    }, [question.id]);

    const handleVideoEnded = () => {
        setVideoEnded(true);
        setStep('answering');
    };

    const handleClarificationClick = () => {
        trackClarification(question.id);
        setShowClarification(true);
    };

    const handleTimerExpire = () => {
        // Handle auto-submit if implemented in AnswerRecorder or parent
        // For now, we rely on user action, but timer can trigger a "Time's up" modal or force stop
        console.log("Timer expired!");
    };

    const canReplay = videoPlayCount < 2; // Limit 1 replay (total 2 plays)

    return (
        <div className="w-full max-w-4xl mx-auto space-y-6">
            <div className="flex justify-between items-center text-sm text-slate-400 border-b border-slate-800 pb-4">
                <span>Question {index + 1} of {total}</span>
                <span>{question.personas?.name || 'Interviewer'}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Left: Question Video & Text */}
                <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-slate-100 min-h-[3.5rem]">
                        {question.question_text}
                    </h2>
                    
                    <Card className="bg-black border-slate-800 overflow-hidden aspect-video relative group shadow-inner">
                        <video 
                            src={question.question_video_url}
                            className="w-full h-full object-cover"
                            controls={canReplay || !videoEnded}
                            autoPlay
                            onEnded={handleVideoEnded}
                            onPlay={() => trackVideoPlay(question.id, 'question')}
                        />
                        {videoEnded && canReplay && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                <div className="bg-white/10 p-3 rounded-full backdrop-blur-md">
                                    <Play className="w-8 h-8 text-white fill-current" />
                                </div>
                            </div>
                        )}
                    </Card>

                    <div className="flex justify-between items-center">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="text-sky-400 hover:text-sky-300 hover:bg-sky-900/20"
                            onClick={handleClarificationClick}
                            disabled={!question.clarification_video_url || clarificationUsed > 0}
                        >
                            <HelpCircle className="w-4 h-4 mr-2" />
                            {clarificationUsed > 0 ? "Clarification Used" : "Get Clarification"}
                        </Button>
                    </div>
                </div>

                {/* Right: Answer Area */}
                <div className="flex flex-col items-center justify-center bg-slate-800/30 rounded-xl border border-slate-800 p-6 min-h-[400px]">
                    <AnimatePresence mode="wait">
                        {step === 'video' ? (
                            <motion.div 
                                key="waiting"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                className="text-center space-y-4"
                            >
                                <div className="w-16 h-16 rounded-full border-4 border-slate-700 border-t-blue-500 animate-spin mx-auto opacity-50" />
                                <p className="text-slate-400">Please watch the question video...</p>
                            </motion.div>
                        ) : (
                            <motion.div 
                                key="answering"
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="w-full flex flex-col items-center gap-8"
                            >
                                <AnswerTimer 
                                    isActive={true} 
                                    onExpire={handleTimerExpire} 
                                />
                                <AnswerRecorder 
                                    isActive={true}
                                    onAnswerSubmitted={onAnswerSubmitted}
                                    storagePath={`responses/${question.id}`}
                                />
                                <p className="text-xs text-slate-500 text-center max-w-[200px]">
                                    You have 4 minutes to record your answer.
                                </p>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>

            <ClarificationModal 
                open={showClarification}
                onOpenChange={setShowClarification}
                videoUrl={question.clarification_video_url}
                questionText={question.question_text}
            />
        </div>
    );
};

export default QuestionDisplay;
