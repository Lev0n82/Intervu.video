
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Video, Mic, Upload, Sparkles, ArrowRight, PlayCircle, Clock } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const IntroductionInstructions = ({ loading = false }) => {
  if (loading) {
    return (
      <Card className="bg-gradient-to-r from-slate-50 to-white border-blue-100 mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
             <div className="space-y-2 flex-1">
                 <Skeleton className="h-6 w-1/3" />
                 <Skeleton className="h-4 w-full" />
                 <Skeleton className="h-4 w-2/3" />
             </div>
             <div className="flex gap-4">
                 <Skeleton className="h-24 w-24 rounded-lg" />
                 <Skeleton className="h-24 w-24 rounded-lg" />
             </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50/50 to-white border-blue-100/50 shadow-sm mb-6 overflow-hidden relative">
      <div className="absolute top-0 right-0 p-4 opacity-5">
        <Video className="w-32 h-32" />
      </div>
      
      <CardContent className="p-6 relative z-10">
        <div className="flex flex-col gap-6">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <h3 className="text-lg font-semibold text-blue-900 flex items-center gap-2">
                <PlayCircle className="w-5 h-5 text-blue-600" />
                Interview Structure & Setup
              </h3>
              <p className="text-sm text-blue-700 max-w-2xl">
                Create a professional interview experience. The introduction video is the first thing candidates see—make it count!
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/60 p-4 rounded-lg border border-blue-100 backdrop-blur-sm">
              <div className="flex items-center gap-2 mb-2 text-blue-800 font-medium text-sm">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600 text-xs font-bold">1</span>
                Introduction Video
              </div>
              <p className="text-xs text-slate-600 mb-3">
                Required to start. Choose your method:
              </p>
              <div className="flex gap-2 text-xs text-slate-500">
                <div className="flex items-center gap-1 bg-white px-2 py-1 rounded border"><Sparkles className="w-3 h-3 text-purple-500" /> AI</div>
                <div className="flex items-center gap-1 bg-white px-2 py-1 rounded border"><Upload className="w-3 h-3 text-blue-500" /> Upload</div>
                <div className="flex items-center gap-1 bg-white px-2 py-1 rounded border"><Mic className="w-3 h-3 text-red-500" /> Record</div>
              </div>
            </div>

            <div className="bg-white/60 p-4 rounded-lg border border-blue-100 backdrop-blur-sm">
               <div className="flex items-center gap-2 mb-2 text-blue-800 font-medium text-sm">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600 text-xs font-bold">2</span>
                Question Flow
              </div>
              <p className="text-xs text-slate-600">
                After the intro, candidates proceed to questions. Each question can have a clarification video for extra context.
              </p>
            </div>

            <div className="bg-white/60 p-4 rounded-lg border border-blue-100 backdrop-blur-sm">
               <div className="flex items-center gap-2 mb-2 text-blue-800 font-medium text-sm">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600 text-xs font-bold">3</span>
                Participant View
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600 mt-1">
                <Clock className="w-3 h-3" />
                <span>Timed Answers</span>
                <ArrowRight className="w-3 h-3 text-blue-300" />
                <Video className="w-3 h-3" />
                <span>Video Response</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IntroductionInstructions;
