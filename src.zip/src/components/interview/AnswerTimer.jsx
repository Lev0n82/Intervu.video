
import React, { useState, useEffect, useRef } from 'react';
import { Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

const AnswerTimer = ({ duration = 240, onExpire, isActive }) => {
  const [timeLeft, setTimeLeft] = useState(duration);
  const audioContextRef = useRef(null);
  const hasBeepedRef = useRef(false);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          if (onExpire) onExpire();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, onExpire]);

  // Audio Beep Logic
  useEffect(() => {
    if (timeLeft === 40 && !hasBeepedRef.current && isActive) {
      playBeep();
      hasBeepedRef.current = true;
    }
  }, [timeLeft, isActive]);

  const playBeep = () => {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      
      if (!audioContextRef.current) {
        audioContextRef.current = new AudioContext();
      }

      const ctx = audioContextRef.current;
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, ctx.currentTime); // A4
      gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
      
      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.5); // 500ms beep
    } catch (e) {
      console.error("Audio beep failed", e);
    }
  };

  const getStatusColor = () => {
    if (timeLeft <= 30) return "text-red-500 animate-pulse";
    if (timeLeft <= 60) return "text-yellow-500";
    return "text-green-500";
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center gap-2 font-mono text-xl font-bold bg-zinc-900/50 px-4 py-2 rounded-lg border border-zinc-800">
      <Clock className={cn("w-5 h-5", getStatusColor())} />
      <span className={cn(getStatusColor())}>{formatTime(timeLeft)}</span>
    </div>
  );
};

export default AnswerTimer;
