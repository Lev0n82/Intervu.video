import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';

const LayoutHelmet = () => {
    const { i18n } = useTranslation();

    return (
        <Helmet 
            htmlAttributes={{ lang: i18n.language }}
            titleTemplate="%s | Intervu.video - AI-Powered Video Interviews"
            defaultTitle="Intervu.video - AI-Powered Video Interviews"
        >
            <meta name="description" content="The future of automated video interviews and surveys. Streamline your hiring process with advanced AI analysis, collaborative tools, and in-depth behavioral insights." />
        </Helmet>
    );
};

export default LayoutHelmet;