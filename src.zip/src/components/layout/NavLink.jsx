import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const NavLink = ({ to, children, icon: Icon, ariaLabel, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to || 
                   (to === "/about" && location.pathname.startsWith("/about")) ||
                   (to.startsWith("/profile") && location.pathname.startsWith("/profile"));

  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={cn(
        "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors w-full text-left focus-visible-ring relative",
        isActive 
          ? "text-primary-foreground" 
          : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
      )}
      aria-label={ariaLabel || String(children)}
      aria-current={isActive ? "page" : undefined}
    >
      {isActive && (
        <motion.div
          layoutId="active-nav-link"
          className="absolute inset-0 bg-primary rounded-md z-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        />
      )}
      <div className="relative z-10 flex items-center">
        {Icon && <Icon className="w-5 h-5 mr-2 flex-shrink-0" aria-hidden="true" />} {children}
      </div>
    </Link>
  );
};

export default NavLink;