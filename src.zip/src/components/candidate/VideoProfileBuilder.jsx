import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, Trash2, Upload, Video, X, Save, Loader2, PlayCircle, Film, 
  BarChart2, Share2, Download, Copy, Lightbulb, Sparkles, BrainCircuit,
  PieChart, TrendingUp, Mic
} from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import VideoRecorder from '@/components/VideoRecorder';
import logger from '@/lib/logger';

// Mock Question Library
const QUESTION_LIBRARY = {
  "General": ["Tell me about yourself.", "What are your greatest strengths?", "Why do you want to work here?"],
  "Behavioral": ["Describe a challenge you overcame.", "Tell me about a time you failed.", "How do you handle conflict?"],
  "Technical": ["Explain a complex technical concept simply.", "What is your preferred tech stack?", "How do you debug code?"]
};

const VideoProfileBuilder = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Dialog States
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [videoToDelete, setVideoToDelete] = useState(null);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedVideoForShare, setSelectedVideoForShare] = useState(null);
  const [showLibrary, setShowLibrary] = useState(false);
  
  // Form State
  const [newVideo, setNewVideo] = useState({
    title: '',
    description: '',
    video_url: '',
    thumbnail_url: '',
    tags: [],
    currentTag: '',
    transcription: '',
    edit_settings: null,
    ai_feedback: null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analyzingAi, setAnalyzingAi] = useState(false);

  useEffect(() => {
    if (user) fetchVideos();
  }, [user]);

  const fetchVideos = async () => {
    try {
      const { data, error } = await supabase
        .from('user_videos')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVideos(data || []);
    } catch (error) {
      console.error('Error fetching videos:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not load your profile videos.' });
    } finally {
      setLoading(false);
    }
  };

  const handleRecordingComplete = (data) => {
    // data contains { url, thumbnail_url, transcription, edit_settings }
    setNewVideo(prev => ({ 
        ...prev, 
        video_url: data.url,
        thumbnail_url: data.thumbnail_url,
        transcription: data.transcription,
        edit_settings: data.edit_settings
    }));
    setIsRecorderOpen(false); 
    toast({ title: "Video Attached", description: "Recording successful. Fill details to save." });
  };

  const simulateAiAnalysis = () => {
    setAnalyzingAi(true);
    // Simulate API delay
    setTimeout(() => {
        const mockScores = {
            clarity: Math.floor(Math.random() * (98 - 80) + 80),
            confidence: Math.floor(Math.random() * (99 - 75) + 75),
            pacing: ["Perfect", "Slightly Fast", "Good"][Math.floor(Math.random() * 3)],
            keywords: newVideo.tags.length > 0 ? newVideo.tags : ["Leadership", "Communication"]
        };
        setNewVideo(prev => ({ ...prev, ai_feedback: mockScores }));
        setAnalyzingAi(false);
        toast({ title: "Analysis Complete", description: "AI feedback generated successfully." });
    }, 2000);
  };

  const handleSaveVideo = async () => {
    if (!newVideo.title.trim() || !newVideo.video_url) {
        toast({ variant: 'destructive', title: 'Missing Info', description: 'Title and video are required.' });
        return;
    }

    setIsSubmitting(true);
    try {
        const { error } = await supabase.from('user_videos').insert({
            user_id: user.id,
            title: newVideo.title,
            description: newVideo.description,
            video_url: newVideo.video_url,
            thumbnail_url: newVideo.thumbnail_url,
            transcription: newVideo.transcription,
            edit_settings: newVideo.edit_settings,
            ai_feedback: newVideo.ai_feedback,
            tags: newVideo.tags
        });

        if (error) throw error;
        toast({ title: 'Success', description: 'Video added to profile.', className: 'bg-green-600 text-white' });
        setIsAddDialogOpen(false);
        resetForm();
        fetchVideos();
    } catch (error) {
        console.error('Save error:', error);
        toast({ variant: 'destructive', title: 'Error', description: 'Could not save video.' });
    } finally {
        setIsSubmitting(false);
    }
  };

  const resetForm = () => {
      setNewVideo({ title: '', description: '', video_url: '', thumbnail_url: '', tags: [], currentTag: '', transcription: '', ai_feedback: null });
  };

  const handleDeleteVideo = async () => {
      if (!videoToDelete) return;
      try {
          const { error } = await supabase.from('user_videos').delete().eq('id', videoToDelete.id);
          if (error) throw error;
          setVideos(prev => prev.filter(v => v.id !== videoToDelete.id));
          toast({ title: 'Deleted', description: 'Video removed.' });
      } catch (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'Delete failed.' });
      } finally {
          setDeleteConfirmOpen(false);
      }
  };

  const copyShareLink = (url) => {
      navigator.clipboard.writeText(url);
      toast({ title: "Copied!", description: "Link copied to clipboard." });
      setShareDialogOpen(false);
  };

  // --- Render Helpers ---

  const renderAiScore = (score, label, colorClass) => (
      <div className="flex flex-col items-center p-2 bg-muted/30 rounded-lg border border-border">
          <div className="relative flex items-center justify-center w-12 h-12">
              <svg className="w-full h-full transform -rotate-90">
                  <circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="4" fill="none" className="text-muted" />
                  <circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="4" fill="none" className={colorClass} strokeDasharray={113} strokeDashoffset={113 - (113 * score) / 100} />
              </svg>
              <span className="absolute text-xs font-bold">{score}</span>
          </div>
          <span className="text-[10px] uppercase font-bold text-muted-foreground mt-1">{label}</span>
      </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* 1. Header & Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 border-l-4 border-l-primary shadow-sm">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Video className="w-5 h-5 text-primary" />
                    Video Profile Builder
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground mb-4">Create a compelling video portfolio. Record introductions, answer standard interview questions, and showcase your communication skills.</p>
                <Button onClick={() => setIsAddDialogOpen(true)} className="shadow-lg hover:scale-105 transition-transform">
                    <Plus className="w-4 h-4 mr-2" /> Add New Video
                </Button>
            </CardContent>
        </Card>

        {/* Analytics Card */}
        <Card className="bg-gradient-to-br from-background to-muted/50 border-muted">
             <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2"><BarChart2 className="w-4 h-4" /> Profile Engagement</CardTitle></CardHeader>
             <CardContent>
                 <div className="text-3xl font-bold">{videos.reduce((acc, v) => acc + (v.views || 0), 0)}</div>
                 <p className="text-xs text-muted-foreground">Total Views</p>
                 <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
                     <div className="h-full bg-green-500" style={{ width: `${Math.min(videos.length * 20, 100)}%` }} />
                 </div>
                 <p className="text-xs text-right mt-1 text-muted-foreground">{videos.length} Videos Uploaded</p>
             </CardContent>
        </Card>
      </div>

      {/* 2. Video Grid */}
      {videos.length === 0 && !loading ? (
           <div className="text-center py-20 bg-muted/5 border-2 border-dashed border-muted rounded-2xl">
               <Film className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
               <h3 className="text-lg font-semibold text-muted-foreground">No videos yet</h3>
               <p className="text-sm text-muted-foreground/70 max-w-xs mx-auto mt-2">Start by recording a generic introduction to pin to your profile.</p>
           </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
                {videos.map((video) => (
                    <motion.div key={video.id} layout initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
                        <Card className="overflow-hidden h-full flex flex-col group hover:border-primary/50 transition-colors">
                            <div className="relative aspect-video bg-black group-hover:shadow-xl transition-all">
                                {/* Thumbnail/Video */}
                                {video.thumbnail_url ? (
                                    <img src={video.thumbnail_url} alt={video.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                ) : (
                                    <video src={video.video_url} className="w-full h-full object-cover" />
                                )}
                                
                                {/* Overlay Controls */}
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                     <Button size="icon" variant="secondary" className="rounded-full" onClick={() => { setSelectedVideoForShare(video); setShareDialogOpen(true); }}>
                                        <Share2 className="w-4 h-4" />
                                     </Button>
                                     <a href={video.video_url} download target="_blank" rel="noreferrer">
                                        <Button size="icon" variant="secondary" className="rounded-full">
                                            <Download className="w-4 h-4" />
                                        </Button>
                                     </a>
                                </div>
                                <div className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                                    {video.duration ? `${Math.floor(video.duration/60)}:${(video.duration%60).toString().padStart(2,'0')}` : 'HD'}
                                </div>
                            </div>
                            
                            <CardHeader className="p-4 pb-2">
                                <CardTitle className="text-base truncate" title={video.title}>{video.title}</CardTitle>
                                {video.ai_feedback && (
                                    <div className="flex gap-2 mt-2">
                                        <Badge variant="outline" className="text-[10px] bg-green-500/10 text-green-600 border-green-500/20">Clarity: {video.ai_feedback.clarity}%</Badge>
                                        <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-600 border-blue-500/20">Conf: {video.ai_feedback.confidence}%</Badge>
                                    </div>
                                )}
                            </CardHeader>
                            <CardContent className="p-4 pt-2 flex-grow">
                                <p className="text-sm text-muted-foreground line-clamp-2">{video.description}</p>
                            </CardContent>
                            <CardFooter className="p-4 pt-0 flex justify-between items-center text-xs text-muted-foreground">
                                <div className="flex items-center gap-1"><BarChart2 className="w-3 h-3" /> {video.views || 0} views</div>
                                <Button variant="ghost" size="sm" className="h-6 w-6 p-0 hover:text-red-500" onClick={() => { setVideoToDelete(video); setDeleteConfirmOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                            </CardFooter>
                        </Card>
                    </motion.div>
                ))}
            </AnimatePresence>
        </div>
      )}

      {/* 3. Add Video Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                  <DialogTitle>Add to Portfolio</DialogTitle>
                  <DialogDescription>Record a new video or upload an existing file.</DialogDescription>
              </DialogHeader>

              <div className="grid gap-6 py-4">
                  {/* Source Selection */}
                  {!newVideo.video_url ? (
                      <div className="grid grid-cols-2 gap-4">
                          <Button variant="outline" className="h-32 flex flex-col gap-2 hover:border-primary hover:bg-primary/5" onClick={() => setIsRecorderOpen(true)}>
                              <Video className="w-8 h-8 text-primary" />
                              <span>Record New Video</span>
                              <span className="text-xs text-muted-foreground">Use Studio Recorder</span>
                          </Button>
                          <Button variant="outline" className="h-32 flex flex-col gap-2 hover:border-primary hover:bg-primary/5" onClick={() => document.getElementById('upload-input').click()}>
                              <Upload className="w-8 h-8 text-primary" />
                              <span>Upload File</span>
                              <span className="text-xs text-muted-foreground">MP4, WebM (Max 100MB)</span>
                              <input id="upload-input" type="file" accept="video/*" className="hidden" />
                          </Button>
                      </div>
                  ) : (
                      <div className="space-y-4">
                          {/* Preview & Analysis */}
                          <div className="grid md:grid-cols-2 gap-4">
                              <div className="aspect-video bg-black rounded-lg overflow-hidden relative group">
                                  {newVideo.thumbnail_url && !newVideo.edit_settings ? (
                                      <img src={newVideo.thumbnail_url} className="w-full h-full object-cover" alt="Preview" />
                                  ) : (
                                      <video src={newVideo.video_url} className="w-full h-full object-cover" controls style={newVideo.edit_settings ? {filter: `brightness(${newVideo.edit_settings.brightness}%) contrast(${newVideo.edit_settings.contrast}%) saturate(${newVideo.edit_settings.saturation}%)`} : {}} />
                                  )}
                                  <Button size="icon" variant="destructive" className="absolute top-2 right-2 h-6 w-6" onClick={() => setNewVideo(prev => ({...prev, video_url: ''}))}><X className="w-3 h-3" /></Button>
                              </div>
                              
                              {/* AI Analysis Panel */}
                              <div className="bg-muted/20 border rounded-lg p-4 flex flex-col justify-center">
                                  {!newVideo.ai_feedback ? (
                                      <div className="text-center">
                                          <BrainCircuit className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                                          <h4 className="font-semibold text-sm mb-1">AI Analysis</h4>
                                          <p className="text-xs text-muted-foreground mb-3">Get feedback on clarity, confidence, and pacing.</p>
                                          <Button size="sm" variant="outline" onClick={simulateAiAnalysis} disabled={analyzingAi}>
                                              {analyzingAi ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Sparkles className="w-3 h-3 mr-2" />}
                                              Analyze Video
                                          </Button>
                                      </div>
                                  ) : (
                                      <div className="space-y-3">
                                          <div className="flex justify-between items-center"><h4 className="text-sm font-semibold flex items-center gap-2"><Sparkles className="w-3 h-3 text-purple-500"/> AI Score</h4> <Badge variant="secondary" className="text-[10px]">Beta</Badge></div>
                                          <div className="flex justify-around">
                                              {renderAiScore(newVideo.ai_feedback.clarity, "Clarity", "text-green-500")}
                                              {renderAiScore(newVideo.ai_feedback.confidence, "Confidence", "text-blue-500")}
                                          </div>
                                          <div className="bg-background rounded p-2 text-xs border">
                                              <span className="font-semibold text-muted-foreground">Pacing:</span> {newVideo.ai_feedback.pacing}
                                          </div>
                                      </div>
                                  )}
                              </div>
                          </div>

                          {/* Details Form */}
                          <div className="space-y-3">
                              <div>
                                  <div className="flex justify-between">
                                     <Label>Title</Label>
                                     <Button variant="link" size="sm" className="h-auto p-0 text-xs" onClick={() => setShowLibrary(!showLibrary)}>Browse Question Library</Button>
                                  </div>
                                  
                                  {/* Quick Library Dropdown */}
                                  {showLibrary && (
                                      <motion.div initial={{height:0}} animate={{height:'auto'}} className="mb-2 overflow-hidden bg-muted/30 rounded-md border text-xs">
                                          {Object.entries(QUESTION_LIBRARY).map(([category, questions]) => (
                                              <div key={category} className="p-2 border-b last:border-0">
                                                  <span className="font-bold text-muted-foreground block mb-1">{category}</span>
                                                  <div className="flex flex-wrap gap-1">
                                                      {questions.map((q, i) => (
                                                          <Badge key={i} variant="outline" className="cursor-pointer hover:bg-background hover:border-primary" onClick={() => { setNewVideo(prev => ({...prev, title: q})); setShowLibrary(false); }}>{q}</Badge>
                                                      ))}
                                                  </div>
                                              </div>
                                          ))}
                                      </motion.div>
                                  )}
                                  
                                  <Input placeholder="e.g. My Leadership Style" value={newVideo.title} onChange={e => setNewVideo(prev => ({...prev, title: e.target.value}))} />
                              </div>
                              
                              <div>
                                  <Label>Description & Transcription</Label>
                                  <Tabs defaultValue="desc" className="w-full">
                                      <TabsList className="h-7">
                                          <TabsTrigger value="desc" className="text-xs py-1 h-full">Description</TabsTrigger>
                                          <TabsTrigger value="trans" className="text-xs py-1 h-full flex gap-1"><Mic className="w-3 h-3"/> Transcript</TabsTrigger>
                                      </TabsList>
                                      <TabsContent value="desc">
                                          <Textarea placeholder="Context about this clip..." value={newVideo.description} onChange={e => setNewVideo(prev => ({...prev, description: e.target.value}))} className="h-20" />
                                      </TabsContent>
                                      <TabsContent value="trans">
                                          <Textarea placeholder="Transcription will appear here..." value={newVideo.transcription} onChange={e => setNewVideo(prev => ({...prev, transcription: e.target.value}))} className="h-20 font-mono text-xs bg-muted/20" />
                                      </TabsContent>
                                  </Tabs>
                              </div>
                          </div>
                      </div>
                  )}
              </div>

              <DialogFooter>
                  <Button variant="ghost" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleSaveVideo} disabled={!newVideo.video_url || isSubmitting}>
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save to Profile'}
                  </Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>
      
      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
          <DialogContent>
              <DialogHeader><DialogTitle>Share Video</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4">
                  <div className="flex items-center space-x-2">
                      <Input value={selectedVideoForShare?.video_url || ''} readOnly />
                      <Button size="icon" onClick={() => copyShareLink(selectedVideoForShare?.video_url)}><Copy className="w-4 h-4" /></Button>
                  </div>
                  <div className="flex justify-center gap-4">
                      <Button variant="outline" className="flex-1">Twitter</Button>
                      <Button variant="outline" className="flex-1">LinkedIn</Button>
                      <Button variant="outline" className="flex-1">Email</Button>
                  </div>
              </div>
          </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
              <AlertDialogTitle>Delete Video?</AlertDialogTitle>
              <AlertDialogDescription>This action cannot be undone.</AlertDialogDescription>
              <div className="flex justify-end gap-2"><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteVideo} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction></div>
          </AlertDialogContent>
      </AlertDialog>

      {/* Recorder Instance */}
      {user && (
          <VideoRecorder 
            open={isRecorderOpen} 
            onOpenChange={setIsRecorderOpen}
            onUploadComplete={handleRecordingComplete}
            storagePath={user.id}
            bucketName="user-profile-videos"
          />
      )}
    </div>
  );
};

export default VideoProfileBuilder;