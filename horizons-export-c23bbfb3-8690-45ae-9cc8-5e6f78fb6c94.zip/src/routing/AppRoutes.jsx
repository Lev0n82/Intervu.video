
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import PublicLayout from '@/components/layout/PublicLayout';
import DemoLayout from '@/components/layout/DemoLayout';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

// Page Imports
import LandingPage from '@/pages/LandingPage';
import AuthPage from '@/pages/AuthPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import PasswordResetPage from '@/pages/PasswordResetPage';
import AcceptInvitationPage from '@/pages/AcceptInvitationPage';
import WelcomePage from '@/pages/WelcomePage';
import RoleSelectionPage from '@/pages/onboarding/RoleSelectionPage';
import DashboardPage from '@/pages/DashboardPage';
import TemplateManagementPage from '@/pages/TemplateManagementPage';
import InterviewSetupPage from '@/pages/InterviewSetupPage';
import EditTemplatePage from '@/pages/EditTemplatePage';
import TeamManagementPage from '@/pages/TeamManagementPage';
import SettingsPage from '@/pages/SettingsPage';
import ScheduleInterviewPage from '@/pages/ScheduleInterviewPage';
import InterviewManagementPage from '@/pages/InterviewManagementPage';
import ViewSubmissionPage from '@/pages/ViewSubmissionPage';
import CandidateDashboardPage from '@/pages/CandidateDashboardPage';
import CandidateInterviewPage from '@/pages/CandidateInterviewPage';
import InterviewStartPage from '@/pages/InterviewStartPage';
import SurveyManagementPage from '@/pages/SurveyManagementPage';
import SurveyBuilderPage from '@/pages/SurveyBuilderPage';
import EditSurveyPage from '@/pages/EditSurveyPage';
import VideoSurveyBuilderPage from '@/pages/VideoSurveyBuilderPage';
import EditVideoSurveyPage from '@/pages/EditVideoSurveyPage';
import SurveyCompletionPage from '@/pages/SurveyCompletionPage';
import ReportsPage from '@/pages/ReportsPage';
import PersonaManagementPage from '@/pages/PersonaManagementPage';
import OrganizationSettingsPage from '@/pages/OrganizationSettingsPage';
import UserProfilePage from '@/pages/UserProfilePage';
import SurveyResultsPage from '@/pages/SurveyResultsPage';
import HostEventPage from '@/pages/HostEventPage';
import PreviewPage from '@/pages/PreviewPage';
import FeatureStatusPage from '@/pages/FeatureStatusPage';
import RequirementsPage from '@/pages/RequirementsPage';
import UserStoriesPage from '@/pages/UserStoriesPage';
import TechnicalDetailsPage from '@/pages/TechnicalDetailsPage';
import AboutUsPage from '@/pages/AboutUsPage';
import TermsAndConditionsPage from '@/pages/TermsAndConditionsPage';
import ModernSlaveryStatementPage from '@/pages/ModernSlaveryStatementPage';
import EnvironmentalPolicyPage from '@/pages/EnvironmentalPolicyPage';
import AccessibilityCompliancePage from '@/pages/AccessibilityCompliancePage';
import VideoDiagnosticsPage from '@/pages/VideoDiagnosticsPage';
import VersionHistoryPage from '@/pages/VersionHistoryPage';

// Join Flow Pages
import JoinTeamPage from '@/pages/join/JoinTeamPage';
import TeamInvitationFlow from '@/pages/join/TeamInvitationFlow';
import TeamJoinSuccessPage from '@/pages/join/TeamJoinSuccessPage';
import ParticipantInvitationFlow from '@/pages/join/ParticipantInvitationFlow';
import ParticipantInvitationErrorPage from '@/pages/join/ParticipantInvitationErrorPage';
import DeviceCheckPage from '@/components/CandidateFlow/DeviceCheckPage';

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<LandingPage />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/password-reset" element={<PasswordResetPage />} />
        
        {/* Legacy Invite Route */}
        <Route path="/accept-invitation/:token" element={<AcceptInvitationPage />} />
        
        {/* Team Join Flow */}
        <Route path="/join-team/:invitationCode" element={<JoinTeamPage />} />
        <Route path="/join-team/:invitationCode/signup" element={<TeamInvitationFlow />} />
        <Route path="/join-team/success" element={<TeamJoinSuccessPage />} />

        {/* Participant Join Flow (No Auth Required) */}
        <Route path="/join/participant/:token" element={<ParticipantInvitationFlow />} />
        <Route path="/participant/error/:errorType" element={<ParticipantInvitationErrorPage />} />
        <Route path="/interview/device-check/:submissionToken" element={<DeviceCheckPage />} />
        
        {/* Survey Routes */}
        <Route path="/survey/complete/:token" element={<SurveyCompletionPage />} />
        <Route path="/s/:id" element={<SurveyCompletionPage />} />

        {/* Public Informational Pages */}
        <Route path="/about-us" element={<AboutUsPage />} />
        <Route path="/requirements" element={<RequirementsPage />} />
        <Route path="/user-stories" element={<UserStoriesPage />} />
        <Route path="/feature-status" element={<FeatureStatusPage />} />
        <Route path="/technical-details" element={<TechnicalDetailsPage />} />
        <Route path="/terms-and-conditions" element={<TermsAndConditionsPage />} />
        <Route path="/modern-slavery-statement" element={<ModernSlaveryStatementPage />} />
        <Route path="/environmental-policy" element={<EnvironmentalPolicyPage />} />
        <Route path="/accessibility-compliance" element={<AccessibilityCompliancePage />} />
        <Route path="/diagnostics/video" element={<VideoDiagnosticsPage />} />
        <Route path="/version-history" element={<VersionHistoryPage />} />
      </Route>

      {/* Onboarding Routes */}
      <Route element={<ProtectedRoute />}>
        <Route path="/welcome" element={<WelcomePage />} />
        <Route path="/onboarding/role" element={<RoleSelectionPage />} />
      </Route>

      {/* Main Application Routes (Hiring) */}
      <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/templates" element={<TemplateManagementPage />} />
        <Route path="/templates/new" element={<InterviewSetupPage />} />
        <Route path="/templates/edit/:templateId" element={<EditTemplatePage />} />
        <Route path="/interviews" element={<InterviewManagementPage />} />
        <Route path="/interviews/schedule" element={<ScheduleInterviewPage />} />
        <Route path="/interviews/submission/:submissionId" element={<ViewSubmissionPage />} />
        <Route path="/surveys" element={<SurveyManagementPage />} />
        <Route path="/surveys/new" element={<SurveyBuilderPage />} />
        <Route path="/surveys/edit/:surveyId" element={<EditSurveyPage />} />
        <Route path="/surveys/video/new" element={<VideoSurveyBuilderPage />} />
        <Route path="/surveys/video/edit/:surveyId" element={<EditVideoSurveyPage />} />
        <Route path="/surveys/results/:surveyId" element={<SurveyResultsPage />} />
        <Route path="/team" element={<TeamManagementPage />} />
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/personas" element={<PersonaManagementPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/settings/organization" element={<OrganizationSettingsPage />} />
        <Route path="/settings/profile" element={<UserProfilePage />} />
        <Route path="/host-event" element={<HostEventPage />} />
        <Route path="/preview" element={<PreviewPage />} />
      </Route>

      {/* Candidate Routes (Auth Protected parts) */}
      <Route element={<ProtectedRoute><PublicLayout /></ProtectedRoute>}>
        <Route path="/candidate-home" element={<CandidateDashboardPage />} />
        <Route path="/interview/start/:token" element={<InterviewStartPage />} />
        <Route path="/interview/session/:token" element={<CandidateInterviewPage />} />
      </Route>

      {/* Demo Routes */}
      <Route path="/demo" element={<DemoLayout />}>
        <Route index element={<Navigate to="/demo/dashboard" replace />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="templates" element={<TemplateManagementPage />} />
        <Route path="templates/new" element={<InterviewSetupPage />} />
        <Route path="templates/edit/:templateId" element={<EditTemplatePage />} />
        <Route path="interviews" element={<InterviewManagementPage />} />
        <Route path="interviews/schedule" element={<ScheduleInterviewPage />} />
        <Route path="interviews/submission/:submissionId" element={<ViewSubmissionPage />} />
        <Route path="surveys" element={<SurveyManagementPage />} />
        <Route path="surveys/new" element={<SurveyBuilderPage />} />
        <Route path="surveys/edit/:surveyId" element={<EditSurveyPage />} />
        <Route path="surveys/video/new" element={<VideoSurveyBuilderPage />} />
        <Route path="surveys/video/edit/:surveyId" element={<EditVideoSurveyPage />} />
        <Route path="team" element={<TeamManagementPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="personas" element={<PersonaManagementPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="s/:id" element={<SurveyCompletionPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
