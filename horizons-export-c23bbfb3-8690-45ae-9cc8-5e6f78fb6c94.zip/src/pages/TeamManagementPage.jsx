
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, PlusCircle, Trash2, Mail, Send, Loader2, AlertCircle, RefreshCw, Clock } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import CopyableCode from '@/components/CopyableCode';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

// Enhanced Debug logger helper
const logDebug = (action, status, details = {}) => {
  const timestamp = new Date().toISOString();
  const color = status === 'ERROR' ? 'background: #fee2e2; color: #991b1b' : 
                status === 'SUCCESS' ? 'background: #dcfce7; color: #166534' : 
                status === 'WARN' ? 'background: #fef3c7; color: #92400e' :
                'background: #eff6ff; color: #1e40af';
  
  console.groupCollapsed(`%c[TeamManagement] ${action} - ${status}`, `padding: 2px 4px; border-radius: 2px; ${color}`);
  console.log('Time:', timestamp);
  Object.entries(details).forEach(([key, value]) => {
      console.log(`${key}:`, value);
  });
  console.groupEnd();
};

const demoTeamMembers = [
    { team_member_id: 'demo-1', full_name: 'Alex Johnson', email: 'alex@example.com', role: { name: 'Admin' }, user_id: 'demo-user-1', avatar_url: 'https://i.pravatar.cc/150?u=alex', created_at: new Date().toISOString() },
    { team_member_id: 'demo-2', full_name: 'Maria Garcia', email: 'maria@example.com', role: { name: 'Manager' }, user_id: 'demo-user-2', avatar_url: 'https://i.pravatar.cc/150?u=maria', created_at: new Date().toISOString() },
    { team_member_id: 'demo-3', full_name: 'Chen Wei', email: 'chen@example.com', role: { name: 'Interviewer' }, user_id: 'demo-user-3', avatar_url: 'https://i.pravatar.cc/150?u=chen', created_at: new Date().toISOString() },
];
const demoInvitations = [
    { id: 'inv-1', email: 'new.hire@example.com', role: { name: 'Interviewer' }, status: 'pending', created_at: new Date().toISOString() }
];
const demoRoles = [
    { id: 1, name: 'Admin' }, { id: 2, name: 'Manager' }, { id: 3, name: 'Interviewer' }, { id: 4, name: 'Coordinator' }
];

const TeamManagementPage = () => {
  const { user, activeOrganization, loading: authLoading } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  
  const [teamMembers, setTeamMembers] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [roles, setRoles] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviting, setInviting] = useState(false);
  const [inviteSuccessData, setInviteSuccessData] = useState(null);
  
  const [email, setEmail] = useState('');
  const [roleId, setRoleId] = useState('');

  // Refs for subscription cleanup
  const membersSubscription = useRef(null);
  const invitationsSubscription = useRef(null);

  const getInitials = (name) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const fetchRoles = useCallback(async () => {
    if (isDemo) {
      setRoles(demoRoles);
      return;
    }
    try {
      const { data: rolesData, error: rolesError } = await supabase.from('roles').select('*');
      if (rolesError) throw rolesError;
      setRoles(rolesData || []);
    } catch (error) {
      logDebug('FetchRoles', 'ERROR', { error });
      toast({ variant: 'destructive', title: 'Error fetching roles', description: error.message });
      setRoles([]);
    }
  }, [toast, isDemo]);
  
  const fetchTeamData = useCallback(async (showLoading = true) => {
    // 1. Validation checks
    if (isDemo) {
        setTeamMembers(demoTeamMembers);
        setInvitations(demoInvitations);
        if (showLoading) setLoading(false);
        return;
    }
    
    if (authLoading) {
        return;
    }

    if (!activeOrganization?.id) {
        if (showLoading) setLoading(false);
        return;
    }
    
    // 2. Start Fetch
    if (showLoading) setLoading(true);
    setError(null);

    try {
        // --- Fetch Members ---
        const { data: members, error: membersError } = await supabase.rpc('get_team_members_with_emails', {
            p_organization_id: activeOrganization.id
        });

        if (membersError) throw new Error(`Members RPC Error: ${membersError.message}`);
        
        const standardizedMembers = (members || []).map(m => ({
            team_member_id: m.team_member_id,
            user_id: m.user_id,
            full_name: m.full_name || 'Unknown',
            email: m.email,
            avatar_url: m.avatar_url,
            role: { name: m.role_name || 'Unknown Role', id: m.role_id },
            department: m.department,
            title: m.title,
            created_at: m.created_at
        }));
        setTeamMembers(standardizedMembers);

        // --- Fetch Invitations ---
        const { data: invs, error: invsError } = await supabase
            .from('team_invitations')
            .select('id, email, role_id, status, created_at, invitation_code, roles(id, name)')
            .eq('organization_id', activeOrganization.id)
            .eq('status', 'pending')
            .order('created_at', { ascending: false });
            
        if (invsError) throw new Error(`Invitations Fetch Error: ${invsError.message}`);
        
        const standardizedInvs = (invs || []).map(i => ({
            ...i,
            role: i.roles // map nested relation
        }));
        setInvitations(standardizedInvs);

    } catch (error) {
      console.error("Fetch team data error:", error);
      setError(error.message);
      toast({ variant: 'destructive', title: 'Failed to load team data', description: error.message });
    } finally {
      if (showLoading) setLoading(false);
    }
  }, [activeOrganization, authLoading, toast, isDemo]);

  // Initial Data Fetch
  useEffect(() => {
    fetchRoles();
  }, [fetchRoles]);

  useEffect(() => {
    if (!authLoading && activeOrganization) {
      fetchTeamData(true);
    }
  }, [authLoading, activeOrganization, fetchTeamData]);

  // Real-time Subscriptions
  useEffect(() => {
    if (isDemo || !activeOrganization?.id) return;

    const membersChannel = supabase.channel(`team_members:${activeOrganization.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'team_members', filter: `organization_id=eq.${activeOrganization.id}` }, () => fetchTeamData(false))
      .subscribe();
    membersSubscription.current = membersChannel;

    const invitationsChannel = supabase.channel(`team_invitations:${activeOrganization.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'team_invitations', filter: `organization_id=eq.${activeOrganization.id}` }, () => fetchTeamData(false))
      .subscribe();
    invitationsSubscription.current = invitationsChannel;

    return () => {
      if (membersSubscription.current) supabase.removeChannel(membersSubscription.current);
      if (invitationsSubscription.current) supabase.removeChannel(invitationsSubscription.current);
    };
  }, [activeOrganization, fetchTeamData, isDemo]);


  const handleInvite = async (e) => {
    e.preventDefault();
    if (promptSave()) return;

    if (!activeOrganization?.id) {
       toast({ variant: 'destructive', title: 'System Error', description: 'No active organization found.' });
       return;
    }

    if (!email || !roleId) {
      toast({ variant: 'destructive', title: 'Validation Error', description: 'Please provide both an email and a role.' });
      return;
    }
    
    setInviting(true);
    setInviteSuccessData(null);

    try {
        const { data: dbData, error: dbError } = await supabase.rpc('invite_user_to_team', {
            organization_id_to_invite_to: activeOrganization.id,
            invitee_email: email,
            role_id_to_assign: parseInt(roleId, 10),
            site_url: window.location.origin
        });

        if (dbError || !dbData.success) {
             throw new Error(dbData?.message || dbError?.message || 'Database error');
        }

        const roleName = roles.find(r => String(r.id) === String(roleId))?.name;
        
        // Send email (best effort)
        const { data: emailData } = await supabase.functions.invoke('send-invitation-email', {
            body: {
                invitee_email: email,
                org_name: dbData.org_name || activeOrganization.name,
                invitation_token: dbData.token,
                invitation_code: dbData.code,
                site_url: window.location.origin,
                role_name: roleName
            }
        });

        const successInfo = {
            email,
            code: dbData.code,
            token: dbData.token,
            link: `${window.location.origin}/accept-invite/${dbData.token}`
        };
        
        setInviteSuccessData(successInfo);
        
        if (emailData?.success) {
             toast({ title: 'Invitation Sent', description: `Invitation sent to ${email} successfully.` });
        } else {
             toast({ variant: 'warning', title: 'Saved, but Email Failed', description: 'The invitation was saved, but email failed. You can share the code manually.' });
        }

        await fetchTeamData(false);

    } catch (error) {
        toast({ variant: 'destructive', title: 'Invitation Failed', description: error.message });
    } finally {
        setInviting(false);
    }
  };

  const handleCloseInviteDialog = () => {
      setIsInviteDialogOpen(false);
      setInviteSuccessData(null);
      setEmail('');
      setRoleId('');
  }
  
  const handleDeleteMember = async (memberId, memberName) => {
    if (promptSave()) return;
    if (!window.confirm(`Remove ${memberName} from the team?`)) return;

    try {
        const { error } = await supabase.from('team_members').delete().eq('id', memberId);
        if (error) throw error;
        toast({ title: 'Member Removed', description: `${memberName} has been removed.` });
        fetchTeamData(false);
    } catch (error) {
        toast({ variant: 'destructive', title: 'Error Removing Member', description: error.message });
    }
  }

  const handleDeleteInvitation = async (invitationId, inviteeEmail) => {
    if (promptSave()) return;
    if (!window.confirm(`Delete invitation for ${inviteeEmail}?`)) return;

    try {
        const { error } = await supabase.from('team_invitations').delete().eq('id', invitationId);
        if (error) throw error;
        toast({ title: 'Invitation Deleted', description: `Invitation for ${inviteeEmail} deleted.` });
        fetchTeamData(false);
    } catch (error) {
        toast({ variant: 'destructive', title: 'Error Deleting Invitation', description: error.message });
    }
  }
  
  const allTeamItems = [
      ...teamMembers.map(m => ({ ...m, type: 'member' })),
      ...invitations.map(i => ({ ...i, type: 'invitation' }))
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-4 sm:p-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <CardTitle className="text-primary flex items-center text-2xl">
              <Users className="mr-3 h-6 w-6" /> Team Management
            </CardTitle>
            <CardDescription className="mt-1">
              Manage team members and their roles.
            </CardDescription>
          </div>
          <div className="flex gap-2 mt-3 sm:mt-0">
             <Button variant="outline" size="sm" onClick={() => fetchTeamData(true)} disabled={loading}>
                 <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
             </Button>
              <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
                <DialogTrigger asChild>
                    <Button onClick={() => setInviteSuccessData(null)}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Invite User
                    </Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle className="flex items-center"><Mail className="mr-2"/>Invite New Team Member</DialogTitle>
                        <DialogDescription>
                            Send an email invitation or generate a shareable code.
                        </DialogDescription>
                    </DialogHeader>

                    {!inviteSuccessData ? (
                        <form onSubmit={handleInvite} className="space-y-4 pt-4">
                            <div>
                                <Label htmlFor="email">Email</Label>
                                <Input 
                                    id="email" type="email" placeholder="email@example.com" 
                                    value={email} onChange={e => setEmail(e.target.value)} 
                                    required disabled={inviting} className="mt-1" 
                                />
                            </div>
                            <div>
                                <Label htmlFor="role">Role</Label>
                                <Select onValueChange={setRoleId} value={roleId} required disabled={inviting}>
                                    <SelectTrigger id="role" disabled={roles.length === 0 || inviting} className="mt-1">
                                        <SelectValue placeholder="Select a role" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {roles.filter(r => r.name !== 'Admin').map(r => (
                                            <SelectItem key={r.id} value={r.id.toString()}>{r.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={handleCloseInviteDialog} disabled={inviting}>Cancel</Button>
                                <Button type="submit" disabled={inviting}>
                                    {inviting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Send className="mr-2 h-4 w-4"/>}
                                    {inviting ? 'Sending...' : 'Send Invite'}
                                </Button>
                            </DialogFooter>
                        </form>
                    ) : (
                        <div className="space-y-6 pt-2">
                             <Alert className="bg-green-50 border-green-200">
                                <AlertTitle className="text-green-800">Invitation Created!</AlertTitle>
                                <AlertDescription className="text-green-700">
                                    You can share the invitation manually using the options below.
                                </AlertDescription>
                            </Alert>
                            
                            <CopyableCode 
                                code={inviteSuccessData.link} 
                                label="Direct Invite Link" 
                                description="Share this link via Slack, Teams, or email."
                            />

                            <CopyableCode 
                                code={inviteSuccessData.code} 
                                label="Invitation Code" 
                                description="Or share this short code for manual entry."
                            />
                            
                            <DialogFooter>
                                <Button onClick={handleCloseInviteDialog}>Done</Button>
                            </DialogFooter>
                        </div>
                    )}
                </DialogContent>
              </Dialog>
          </div>
        </CardHeader>
        <CardContent>
            {error && (
                <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error Loading Team</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

          <div className="border rounded-lg overflow-auto">
            <table className="min-w-full divide-y divide-border">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Role</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Code</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Joined</th>
                  <th className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading || authLoading ? (
                    <tr><td colSpan={5} className="text-center py-10" role="status"><Loader2 className="h-6 w-6 animate-spin mx-auto"/></td></tr>
                ) : allTeamItems.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-20 text-muted-foreground">No team members yet.</td></tr>
                ) : (
                    <AnimatePresence>
                    {allTeamItems.map((item) => {
                      if (item.type === 'member') {
                        return (
                          <motion.tr key={`member-${item.team_member_id}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} layout>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10">
                                  <AvatarImage src={item.avatar_url} alt={item.full_name} />
                                  <AvatarFallback>{getInitials(item.full_name)}</AvatarFallback>
                                </Avatar>
                                <div className="ml-4">
                                  <div className="text-sm font-medium">{item.full_name}</div>
                                  <div className="text-sm text-muted-foreground">{item.email}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">{item.role?.name}</td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-sm text-muted-foreground"><span className="flex items-center"><Clock className="w-3 h-3 mr-1" />{formatDate(item.created_at)}</span></td>
                            <td className="px-6 py-4 text-right">
                                {user && item.user_id !== user.id && item.role?.name !== 'Admin' && (
                                    <Button variant="ghost" size="icon" onClick={() => handleDeleteMember(item.team_member_id, item.full_name)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                )}
                            </td>
                          </motion.tr>
                        );
                      }
                      if (item.type === 'invitation') {
                        return (
                          <motion.tr key={`invitation-${item.id}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} layout className="bg-muted/20">
                            <td className="px-6 py-4">
                               <div className="flex items-center">
                                 <Avatar className="h-10 w-10"><AvatarFallback><Mail className="w-5 h-5"/></AvatarFallback></Avatar>
                                 <div className="ml-4">
                                   <div className="text-sm font-medium text-muted-foreground italic">Pending</div>
                                   <div className="text-sm text-muted-foreground">{item.email}</div>
                                 </div>
                               </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">{item.role?.name}</td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">
                                {item.invitation_code ? <span className="font-mono bg-background px-2 py-1 rounded border">{item.invitation_code}</span> : '-'}
                            </td>
                            <td className="px-6 py-4 text-sm text-muted-foreground"><span className="flex items-center"><Clock className="w-3 h-3 mr-1" />{formatDate(item.created_at)}</span></td>
                            <td className="px-6 py-4 text-right">
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteInvitation(item.id, item.email)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                            </td>
                          </motion.tr>
                        );
                      }
                      return null;
                    })}
                    </AnimatePresence>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TeamManagementPage;
