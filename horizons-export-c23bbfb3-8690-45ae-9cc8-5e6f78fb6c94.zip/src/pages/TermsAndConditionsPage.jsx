import React from 'react';
import { motion } from 'framer-motion';
import { Gavel, FileText, ShieldCheck, Users, Clock, CreditCard, Edit3, Globe, AlertTriangle, Database, Lock, RefreshCw, MessageSquare, Link as LinkIcon, UserCheck, Edit, AlertCircle, CheckSquare } from 'lucide-react';

const Section = ({ title, icon, children }) => (
  <motion.section 
    className="mb-8 sm:mb-10 p-4 sm:p-6 bg-card rounded-xl shadow-xl border border-border"
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.3 }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex items-center mb-3 sm:mb-4">
      {React.cloneElement(icon, { size: 24, className: "text-primary mr-2 sm:mr-3 flex-shrink-0" })}
      <h2 className="text-xl sm:text-2xl font-bold text-card-foreground">{title}</h2>
    </div>
    <div className="text-muted-foreground space-y-2 sm:space-y-3 text-xs sm:text-sm leading-relaxed">
      {children}
    </div>
  </motion.section>
);

const TermsAndConditionsPage = () => {
  return (
    <div className="container mx-auto max-w-4xl py-12 sm:py-16 px-4">
      <motion.header 
        className="text-center mb-10 sm:mb-12 py-6 sm:py-8 bg-gradient-to-r from-primary to-cyan-500 rounded-xl shadow-2xl"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Gavel size={40} className="mx-auto mb-3 sm:mb-4 text-primary-foreground" />
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight mb-2 sm:mb-3 text-primary-foreground">Terms and Conditions</h1>
        <p className="text-md sm:text-lg md:text-xl text-primary-foreground/80 max-w-2xl mx-auto px-2">
          Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </motion.header>

      <Section title="1. Acceptance of Terms & Scope of Use" icon={<CheckSquare />}>
        <p>Welcome to the Virtual Interview Platform ("the Platform"), operated by [Your Company Name] ("We", "Us", "Our"). By accessing, registering for, or using any part of the Platform, including its associated services, software, and AI tools, you ("User", "You") signify your unconditional agreement to be bound by these Terms and Conditions ("Terms", "Agreement"). If you do not agree to all provisions of this Agreement, you are not authorized to access or use the Platform.</p>
        <p>The Platform is designed exclusively for facilitating virtual interviews, including but not limited to creating interview templates, recording questions and responses, utilizing AI-powered analysis, and managing candidate interactions. Any use of the Platform for purposes other than its intended use is strictly prohibited. This includes, without limitation, unauthorized access to data, attempts to reverse-engineer the software, sharing of login credentials, redistribution of Platform content or materials, or any activity that could compromise the security or functionality of the Platform.</p>
      </Section>

      <Section title="2. License and Use Rights" icon={<FileText />}>
        <p>Subject to your full compliance with this Agreement and timely payment of any applicable subscription fees, we grant you a limited, non-exclusive, non-transferable, non-sublicensable, and revocable license to access and use the Platform and its associated Services and Materials solely for your internal business purposes of conducting virtual interviews. This license is contingent upon your adherence to all usage restrictions and guidelines set forth in this Agreement and any accompanying documentation.</p>
        <p>You agree not to use the Platform in any manner that is unlawful, harmful, or infringes upon the rights of others. You shall not copy, modify, distribute, sell, lease, or create derivative works based on the Platform, its Services, or Materials, except as expressly permitted herein or with our prior written consent.</p>
      </Section>

      <Section title="3. Definitions" icon={<Edit />}>
        <ul className="list-disc list-inside space-y-2">
          <li><strong>Platform:</strong> Refers to our comprehensive web-based virtual interview system, including all underlying software, AI algorithms, user interfaces, features, functionalities, and related technologies.</li>
          <li><strong>Services:</strong> Encompasses your authorized access to and use of the Platform, along with any associated customer support, technical assistance, maintenance, and updates provided by us during your active subscription period.</li>
          <li><strong>Materials:</strong> Includes all content, data, information, documentation, software components, AI models, and other intellectual property incorporated into or made available through the Platform as part of your subscription.</li>
          <li><strong>Activation Date:</strong> The specific date on which your user account is officially activated and granted access to the Platform's features corresponding to your subscription plan, typically following successful registration and payment confirmation.</li>
        </ul>
      </Section>

      <Section title="4. Access and Availability" icon={<Clock />}>
        <p>We are committed to providing a reliable and accessible Platform. We strive for maximum uptime; however, we do not guarantee uninterrupted access. The Platform's availability may be affected by factors beyond our reasonable control, including internet service disruptions, third-party service failures, or force majeure events. </p>
        <p>Scheduled maintenance or updates that may temporarily impact Platform availability will be communicated to you in advance, whenever practicable, through your account email or notifications within the Platform. We reserve the right to modify, suspend, or discontinue any aspect of the Platform at any time, with or without notice, though we will endeavor to provide notice for significant changes.</p>
      </Section>

      <Section title="5. Subscription and Payment" icon={<CreditCard />}>
        <p>Access to certain features of the Platform may require a paid subscription. All applicable subscription fees, payment terms, and billing cycles will be clearly disclosed to you prior to your account Activation Date or at the time of subscription purchase/renewal. Payments are due upon receipt of invoice or as per the agreed-upon billing schedule. </p>
        <p>Late payments may be subject to interest charges at a rate of 2% per month (or the maximum rate permitted by law, whichever is lower) on the outstanding balance. We reserve the right to suspend or terminate access to the Platform for accounts with overdue payments. All fees are quoted and payable in Canadian Dollars (CAD) unless otherwise specified.</p>
      </Section>

      <Section title="6. Changes to Terms or Pricing" icon={<Edit3 />}>
        <p>We reserve the right to revise these Terms or modify subscription pricing at our discretion. Any such changes will be communicated to you at least thirty (30) days prior to their effective date, typically via email or a prominent notice on the Platform. Price reductions or beneficial changes to terms may apply immediately without prior notice.</p>
        <p>Price increases will not be retroactive; they will apply to new subscription periods or renewals occurring after the effective date of the change. Your continued use of the Platform after the effective date of any revisions constitutes your acceptance of the modified Terms or pricing.</p>
      </Section>

      <Section title="7. Intellectual Property Rights" icon={<Globe />}>
        <p>All content, software, designs, trademarks, logos, AI models, algorithms, and other intellectual property associated with the Platform ("Platform IP") are and will remain the exclusive property of [Your Company Name] or its licensors. This Agreement does not grant you any ownership rights in or to the Platform IP, except for the limited license expressly provided herein.</p>
        <p>We will defend, indemnify, and hold harmless authorized users from and against any third-party claims alleging that the use of the Platform, as permitted under this Agreement, infringes upon their intellectual property rights, provided that you give us prompt written notice of any such claim, allow us to control the defense and settlement, and provide reasonable cooperation.</p>
      </Section>

      <Section title="8. Limitation of Liability" icon={<AlertTriangle />}>
        <p>To the maximum extent permitted by applicable law, our total cumulative liability arising out of or in connection with this Agreement or your use of the Platform, whether in contract, tort (including negligence), or otherwise, shall be limited to the greater of one hundred Canadian Dollars ($100 CAD) or the total amount of subscription fees paid by you to us during the twelve (12) month period immediately preceding the event giving rise to the claim.</p>
        <p>In no event shall we be liable for any indirect, incidental, special, consequential, punitive, or speculative damages (including, without limitation, damages for loss of profits, data, business interruption, or goodwill), even if we have been advised of the possibility of such damages. These limitations apply regardless of the failure of any essential purpose of any limited remedy.</p>
      </Section>

      <Section title="9. Data Privacy and Security" icon={<ShieldCheck />}>
        <p>We are committed to protecting your data and privacy. Our data handling practices are designed to comply with applicable data protection regulations, including the General Data Protection Regulation (GDPR), the Health Insurance Portability and Accountability Act (HIPAA) where applicable, and the Personal Information Protection and Electronic Documents Act (PIPEDA) of Canada. Our Privacy Policy, which is incorporated by reference into these Terms, provides detailed information on how we collect, use, share, and protect your personal information and interview data.</p>
        <p>Use of certain AI analysis features may involve processing of personal data; such processing will only occur with explicit consent where required by law. You are responsible for maintaining the confidentiality and security of your account credentials (username and password) and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account or any other breach of security.</p>
      </Section>

      <Section title="10. Warranties and Disclaimers" icon={<AlertCircle />}>
        <p>The Platform is provided on an "as-is" and "as-available" basis, without any warranties of any kind, express or implied. While we make commercially reasonable efforts to ensure the reliability, accuracy, and security of the Platform, we do not warrant that the Platform will be uninterrupted, error-free, completely secure, or that all defects will be corrected.</p>
        <p>We disclaim all warranties, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, title, and non-infringement. Any issues or defects encountered during an active, fully paid subscription period will be addressed by our support team in accordance with our standard support procedures and service level objectives, if applicable.</p>
      </Section>

      <Section title="11. Security Measures" icon={<Lock />}>
        <p>We implement and maintain robust technical and organizational security measures designed to protect your data from unauthorized access, disclosure, alteration, or destruction. These measures include, but are not limited to, data encryption in transit (e.g., TLS/SSL) and at rest, multi-factor authentication (MFA) options for user accounts, regular security assessments, and access controls based on the principle of least privilege.</p>
        <p>You agree to promptly notify us at [Your Security Contact Email/Support Channel] of any suspected or actual unauthorized activity, security breaches, or vulnerabilities related to your account or the Platform that you become aware of.</p>
      </Section>

      <Section title="12. Subscription Renewal and Termination" icon={<RefreshCw />}>
        <p>Unless otherwise specified in your subscription agreement, subscriptions will automatically renew for successive periods equivalent to the initial term, unless canceled by either party at least thirty (30) days prior to the end of the then-current term. You may cancel your subscription through your account settings or by providing written notice to us.</p>
        <p>We may terminate or suspend your access to the Platform for breach of these Terms, non-payment, or illegal activities, with or without prior notice. Termination of this Agreement requires written notice and the fulfillment of all outstanding payment obligations. Upon termination, your right to access and use the Platform will immediately cease, and we may delete your account data in accordance with our data retention policies.</p>
      </Section>

      <Section title="13. Governing Law and Jurisdiction" icon={<Gavel />}>
        <p>This Agreement and any disputes arising out of or related to it or the Platform shall be governed by and construed in accordance with the laws of the Province of Ontario, Canada, without regard to its conflict of law principles.</p>
        <p>Notwithstanding the foregoing, for the purpose of dispute resolution, the parties agree that such disputes may, at our sole discretion, be resolved under the substantive laws and exclusive jurisdiction of the courts of either: (a) Ontario, Canada; (b) Zurich, Switzerland; or (c) Singapore. The choice of jurisdiction will be made by us based on considerations of fairness, enforceability, and the geographical location of the parties involved or the subject matter of the dispute. You consent to the personal jurisdiction of such courts.</p>
      </Section>

      <Section title="14. Communication" icon={<MessageSquare />}>
        <p>All official notices, communications, and disclosures from us to you regarding this Agreement, your subscription, or the Platform will be sent electronically to the primary email address associated with your account. You are responsible for keeping your email address current and regularly checking for communications from us.</p>
        <p>Communications sent to your verified account email address will be deemed to have legal validity and to have been duly received by you. For any notices you need to send to us, please use the contact information provided on our website or within the Platform.</p>
      </Section>

      <Section title="15. Assignment and Resale" icon={<LinkIcon />}>
        <p>You may not transfer, assign, sublicense, or resell your account, your rights, or your obligations under this Agreement, in whole or in part, without our prior express written consent. Any attempted assignment or transfer in violation of this provision will be null and void.</p>
        <p>We may assign this Agreement or any of its rights or obligations hereunder, in whole or in part, to an affiliate or in connection with a merger, acquisition, corporate reorganization, or sale of all or substantially all of its assets, without your consent, provided that the assignee agrees to be bound by these Terms.</p>
      </Section>

      <Section title="16. User Responsibilities" icon={<UserCheck />}>
        <p>You are solely responsible for selecting the Platform to achieve your intended results, for the installation or access to and use of the Platform, and for the results obtained. You are responsible for providing and maintaining your own equipment, internet connectivity, and any third-party software necessary to access and use the Platform.</p>
        <p>You are also responsible for ensuring that your use of the Platform complies with all applicable laws, regulations, and ethical guidelines, including those related to data privacy, employment practices, and anti-discrimination. You agree to provide adequate training and support to your internal users regarding the proper and lawful use of the Platform.</p>
      </Section>

      <Section title="17. Amendments" icon={<Edit />}>
        <p>We may amend these Terms from time to time. Any future changes or updates to this Agreement will be communicated to you in advance, typically through email or a notice on the Platform, as outlined in Section 6. Your continued use of the Platform following the effective date of such amendments will constitute your acceptance of the revised Terms.</p>
        <p>It is your responsibility to review these Terms periodically for any updates or changes.</p>
      </Section>

      <Section title="18. Dispute Resolution" icon={<Users />}>
        <p>We are committed to resolving disputes amicably and efficiently. In the event of any dispute, claim, or controversy arising out of or relating to this Agreement or the Platform, you agree to first attempt to resolve the matter informally by contacting our support team.</p>
        <p>If a dispute cannot be resolved informally within sixty (60) days, either party may pursue formal legal action. Any legal claim or action must be filed within two (2) years from the date the cause of action arose, otherwise, such claim or action shall be permanently barred.</p>
      </Section>

      <Section title="19. Final Provision" icon={<FileText />}>
        <p>This Agreement, including any documents incorporated by reference (such as the Privacy Policy), constitutes the entire agreement between you and [Your Company Name] regarding your use of the Platform and supersedes all prior or contemporaneous understandings, agreements, representations, and warranties, both written and oral.</p>
        <p>This Agreement is intended to ensure a secure, professional, and mutually beneficial partnership. No agency, partnership, joint venture, or employment relationship is created as a result of this Agreement, and you do not have any authority of any kind to bind us in any respect whatsoever, beyond what is explicitly stated herein.</p>
        <p>If any provision of this Agreement is held to be invalid, illegal, or unenforceable, the validity, legality, and enforceability of the remaining provisions shall not in any way be affected or impaired thereby.</p>
      </Section>
    </div>
  );
};

export default TermsAndConditionsPage;