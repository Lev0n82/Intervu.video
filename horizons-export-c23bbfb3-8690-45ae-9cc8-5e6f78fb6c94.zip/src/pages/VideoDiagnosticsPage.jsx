import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { 
  Loader2, CheckCircle, XCircle, AlertTriangle, 
  Video, Mic, Play, Square, RefreshCw, Download, 
  Activity, Monitor, Volume2, Settings, Camera,
  Maximize2, RotateCcw
} from 'lucide-react';
import { cn } from '@/lib/utils';
import logger from '@/lib/logger';

// --- Components ---

const DiagnosticItem = ({ status, title, details }) => {
  const getIcon = () => {
    switch (status) {
      case 'pending': return <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />;
      case 'success': return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-400" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-amber-400" />;
      default: return <div className="w-5 h-5 rounded-full border-2 border-zinc-700" />;
    }
  };

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800 transition-all hover:bg-zinc-900">
      <div className="mt-0.5 shrink-0">{getIcon()}</div>
      <div className="space-y-1">
        <p className={cn("text-sm font-medium", status === 'error' ? "text-red-200" : "text-zinc-200")}>
          {title}
        </p>
        {details && <p className="text-xs text-zinc-500 font-mono break-all">{details}</p>}
      </div>
    </div>
  );
};

const MetricBadge = ({ icon: Icon, label, value, subValue }) => (
  <div className="flex items-center gap-3 p-3 bg-zinc-900 rounded-lg border border-zinc-800">
    <div className="p-2 bg-zinc-800 rounded-md text-indigo-400">
      <Icon className="w-4 h-4" />
    </div>
    <div>
      <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">{label}</p>
      <p className="text-sm font-medium text-zinc-200">{value || '--'}</p>
      {subValue && <p className="text-xs text-zinc-600">{subValue}</p>}
    </div>
  </div>
);

const AudioVisualizer = ({ audioLevel }) => (
  <div className="flex items-center gap-1 h-4">
    {[...Array(20)].map((_, i) => (
      <div 
        key={i} 
        className={cn(
          "w-1 rounded-full transition-all duration-75",
          (audioLevel / 5) > i ? "bg-indigo-500 h-full" : "bg-zinc-800 h-1.5"
        )}
      />
    ))}
  </div>
);

// --- Main Page ---

const VideoDiagnosticsPage = () => {
  const { toast } = useToast();
  
  // State
  const [step, setStep] = useState('init'); // init, ready, recording, processing, review
  const [checks, setChecks] = useState({});
  const [stream, setStream] = useState(null);
  const [audioLevel, setAudioLevel] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);
  const [metrics, setMetrics] = useState({
    resolution: null,
    frameRate: null,
    mimeType: null,
    fileSize: null,
    duration: null,
  });
  
  // Refs
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const recordingStartTimeRef = useRef(null);

  // --- Logic ---

  const addCheck = useCallback((id, status, title, details) => {
    setChecks(prev => ({ ...prev, [id]: { status, title, details } }));
    logger.log(`Diagnostic Check: ${title}`, status === 'error' ? 'ERROR' : 'INFO', { details });
  }, []);

  const getSupportedMimeType = () => {
    const types = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4'
    ];
    return types.find(t => MediaRecorder.isTypeSupported(t));
  };

  const analyzeAudio = () => {
    if (!analyserRef.current) return;
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);
    const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
    setAudioLevel(average);
    animationFrameRef.current = requestAnimationFrame(analyzeAudio);
  };

  const initializeSystem = async () => {
    setStep('init');
    setChecks({});
    setMetrics({});
    
    // 1. Browser Check
    addCheck('browser', 'pending', 'Checking browser compatibility...');
    await new Promise(r => setTimeout(r, 400));
    const ua = navigator.userAgent;
    const isSupported = !!(navigator.mediaDevices && window.MediaRecorder);
    
    if (isSupported) {
      addCheck('browser', 'success', 'Browser compatible', ua);
    } else {
      addCheck('browser', 'error', 'Browser not supported', 'MediaDevices or MediaRecorder API missing');
      return;
    }

    // 2. Permissions & Stream
    addCheck('permissions', 'pending', 'Requesting device access...');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' }, 
        audio: true 
      });
      
      setStream(stream);
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      // Analyze Tracks
      const videoTrack = stream.getVideoTracks()[0];
      const audioTrack = stream.getAudioTracks()[0];
      const settings = videoTrack.getSettings();
      
      setMetrics(prev => ({
        ...prev,
        resolution: `${settings.width}x${settings.height}`,
        frameRate: settings.frameRate ? `${settings.frameRate.toFixed(0)} fps` : 'Unknown',
        mimeType: getSupportedMimeType() || 'Default',
      }));

      addCheck('permissions', 'success', 'Devices connected', `${videoTrack.label} | ${audioTrack.label}`);

      // Setup Audio Context for Visualization
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        const audioCtx = new AudioContext();
        const analyser = audioCtx.createAnalyser();
        const source = audioCtx.createMediaStreamSource(stream);
        source.connect(analyser);
        analyser.fftSize = 64; // Lower fftSize for chunkier visualizer bars
        
        audioContextRef.current = audioCtx;
        analyserRef.current = analyser;
        analyzeAudio();
      }

      setStep('ready');

    } catch (err) {
      console.error(err);
      addCheck('permissions', 'error', 'Access denied or device error', err.message);
      toast({ variant: "destructive", title: "Initialization Failed", description: "Check camera permissions." });
    }
  };

  const startRecording = () => {
    if (!stream) return;
    
    const mimeType = getSupportedMimeType();
    if (!mimeType) {
      addCheck('recording', 'error', 'No supported codec found');
      return;
    }

    const chunks = [];
    const recorder = new MediaRecorder(stream, { mimeType });
    mediaRecorderRef.current = recorder;

    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      const url = URL.createObjectURL(blob);
      setRecordedBlob(blob);
      setVideoUrl(url);
      
      const duration = (Date.now() - recordingStartTimeRef.current) / 1000;
      const sizeMB = blob.size / (1024 * 1024);
      
      setMetrics(prev => ({
        ...prev,
        fileSize: `${sizeMB.toFixed(2)} MB`,
        duration: `${duration.toFixed(1)}s`,
        bitrate: `${((blob.size * 8) / duration / 1000).toFixed(0)} kbps`
      }));

      addCheck('recording', 'success', 'Recording captured', `${sizeMB.toFixed(2)}MB • ${duration.toFixed(1)}s`);
      setStep('review');
    };

    recorder.start(100); // Slice into chunks every 100ms for safety
    recordingStartTimeRef.current = Date.now();
    setStep('recording');
    addCheck('recording', 'pending', 'Recording in progress...');
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const resetTest = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setRecordedBlob(null);
    setVideoUrl(null);
    setStep('ready');
    addCheck('recording', 'pending', 'Ready for new test...');
  };

  const downloadVideo = () => {
    if (!videoUrl) return;
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = `diagnostic-test-${new Date().toISOString()}.webm`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast({ title: "Download Started", description: "Your test recording is downloading." });
  };

  // Lifecycle & Cleanup
  useEffect(() => {
    initializeSystem();
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop());
      if (audioContextRef.current) audioContextRef.current.close();
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, []);

  // Ensure video ref is attached when stream changes or component re-renders
  // Robust implementation with cleanup
  useEffect(() => {
    const videoEl = videoRef.current;
    if (videoEl && stream) {
        videoEl.srcObject = stream;
    }
    return () => {
      if (videoEl) videoEl.srcObject = null;
    }
  }, [stream, step]);


  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-4 sm:p-8 font-sans">
      <Helmet>
        <title>System Diagnostics | Intervu Studio</title>
      </Helmet>

      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-zinc-800 pb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-zinc-100 flex items-center gap-3">
              <Activity className="w-8 h-8 text-indigo-500" />
              Studio Diagnostics
            </h1>
            <p className="text-zinc-400 mt-2">Run a complete system check to ensure your camera, microphone, and network are interview-ready.</p>
          </div>
          <Button variant="outline" onClick={initializeSystem} className="border-zinc-700 bg-zinc-900 text-zinc-300 hover:bg-zinc-800">
            <RefreshCw className="w-4 h-4 mr-2" />
            Restart Diagnostics
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Preview & Controls */}
          <div className="lg:col-span-7 space-y-6">
            <Card className="bg-zinc-900 border-zinc-800 overflow-hidden shadow-xl shadow-black/20">
              <CardHeader className="pb-2 border-b border-zinc-800/50 bg-zinc-900/50">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    {step === 'review' ? <Play className="w-5 h-5 text-emerald-500" /> : <Camera className="w-5 h-5 text-indigo-500" />}
                    <CardTitle className="text-lg text-zinc-200">
                      {step === 'review' ? 'Playback Review' : 'Live Camera Feed'}
                    </CardTitle>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-500">
                    {step === 'recording' && (
                      <span className="flex items-center text-red-500 font-bold animate-pulse">
                        <div className="w-2 h-2 bg-red-500 rounded-full mr-2" />
                        RECORDING
                      </span>
                    )}
                    {metrics.resolution && <span>{metrics.resolution}</span>}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 relative aspect-video bg-black group">
                
                {/* Video Element */}
                {step === 'review' && videoUrl ? (
                  <video 
                    src={videoUrl} 
                    controls 
                    className="w-full h-full object-contain"
                    autoPlay
                  />
                ) : (
                  <>
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      muted 
                      playsInline 
                      className={cn(
                        "w-full h-full object-cover transform -scale-x-100 transition-opacity duration-500",
                        !stream ? "opacity-0" : "opacity-100"
                      )} 
                    />
                    {/* Grid Overlay (Optional visual aid) */}
                    <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-20">
                        <div className="border-r border-b border-white/30"></div>
                        <div className="border-r border-b border-white/30"></div>
                        <div className="border-b border-white/30"></div>
                        <div className="border-r border-b border-white/30"></div>
                        <div className="border-r border-b border-white/30"></div>
                        <div className="border-b border-white/30"></div>
                        <div className="border-r border-white/30"></div>
                        <div className="border-r border-white/30"></div>
                        <div></div>
                    </div>
                  </>
                )}

                {/* Placeholder / Loading State */}
                {!stream && step !== 'review' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-600">
                    <Loader2 className="w-12 h-12 animate-spin mb-4 text-indigo-600" />
                    <p>Initializing Camera...</p>
                  </div>
                )}
              </CardContent>
              
              {/* Control Bar */}
              <div className="p-4 bg-zinc-900 border-t border-zinc-800 flex items-center justify-between gap-4">
                <div className="flex-1">
                  {/* Audio Meter */}
                  {step !== 'review' && (
                    <div className="flex items-center gap-3">
                      <Mic className={cn("w-4 h-4", audioLevel > 5 ? "text-emerald-400" : "text-zinc-600")} />
                      <AudioVisualizer audioLevel={audioLevel} />
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  {step === 'ready' && (
                    <Button onClick={startRecording} className="bg-red-600 hover:bg-red-700 text-white min-w-[140px]">
                      <div className="w-3 h-3 bg-white rounded-sm mr-2" />
                      Record Test
                    </Button>
                  )}
                  {step === 'recording' && (
                    <Button onClick={stopRecording} variant="secondary" className="min-w-[140px] animate-pulse bg-zinc-800 text-zinc-100 hover:bg-zinc-700">
                      <Square className="w-4 h-4 mr-2 fill-current" />
                      Stop Recording
                    </Button>
                  )}
                  {step === 'review' && (
                    <>
                      <Button variant="outline" onClick={resetTest} className="border-zinc-700">
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Retake
                      </Button>
                      <Button variant="outline" onClick={downloadVideo} className="border-zinc-700">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </Card>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <MetricBadge icon={Monitor} label="Resolution" value={metrics.resolution} />
              <MetricBadge icon={Activity} label="Frame Rate" value={metrics.frameRate} />
              <MetricBadge icon={Settings} label="Codec" value={metrics.mimeType?.split(';')[0]} subValue={metrics.mimeType?.split('codecs=')[1]} />
              <MetricBadge icon={Volume2} label="Mic Status" value={audioLevel > 2 ? "Active" : "Silent"} subValue={audioLevel > 0 ? `${audioLevel.toFixed(0)}% Input` : null} />
            </div>
          </div>

          {/* Right Column: Diagnostic Checklist */}
          <div className="lg:col-span-5 space-y-6">
            <Card className="bg-zinc-900 border-zinc-800 h-full shadow-lg">
              <CardHeader>
                <CardTitle className="text-zinc-100">System Checks</CardTitle>
                <CardDescription className="text-zinc-400">Real-time status of your recording environment</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {Object.entries(checks).length === 0 && (
                    <div className="text-center py-12 text-zinc-600">
                      <Activity className="w-12 h-12 mx-auto mb-3 opacity-20" />
                      <p>Initializing diagnostics...</p>
                    </div>
                  )}
                  {Object.entries(checks).map(([key, check]) => (
                    <motion.div
                      key={key}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      <DiagnosticItem {...check} />
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {/* Final Success Message */}
                {step === 'review' && !Object.values(checks).some(c => c.status === 'error') && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-center"
                  >
                    <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    <h3 className="font-bold text-emerald-400">System Ready</h3>
                    <p className="text-sm text-emerald-200/70">Your setup looks great for an interview.</p>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>

        </div>
      </div>
    </div>
  );
};

export default VideoDiagnosticsPage;