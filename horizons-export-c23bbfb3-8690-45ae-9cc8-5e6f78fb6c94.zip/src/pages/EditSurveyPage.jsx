import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PlusCircle, Save, ClipboardCheck, Loader2, FileUp } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import SurveyQuestionBuilder from '@/components/SurveyQuestionBuilder';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const EditSurveyPage = () => {
  const { surveyId } = useParams();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeSubmitType, setActiveSubmitType] = useState(null);
  
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { activeOrganization } = useAuth();

  useEffect(() => {
    const fetchSurvey = async () => {
      if (!surveyId || !activeOrganization) return;
      setLoading(true);
      try {
        const { data: surveyData, error: surveyError } = await supabase
          .from('surveys')
          .select('*, survey_questions(*)')
          .eq('id', surveyId)
          .single();

        if (surveyError) throw surveyError;
        if (surveyData.survey_type !== 'text') {
            toast({ title: "Wrong Editor", description: "You are trying to edit a video survey with the wrong editor.", variant: "destructive" });
            navigate(isDemo ? '/demo/surveys' : '/surveys');
            return;
        }

        setTitle(surveyData.title);
        setDescription(surveyData.description);
        setQuestions(surveyData.survey_questions.sort((a, b) => a.sequence_order - b.sequence_order).map(q => ({
          id: q.id,
          text: q.question_text || '', // Fallback to empty string safely
          type: q.question_type,
          isRequired: q.is_required,
          options: q.options?.options || [],
        })));

      } catch (error) {
        toast({ title: 'Error fetching survey', description: error.message, variant: 'destructive' });
        navigate(isDemo ? '/demo/surveys' : '/surveys');
      } finally {
        setLoading(false);
      }
    };
    fetchSurvey();
  }, [surveyId, toast, navigate, isDemo, activeOrganization]);

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: `temp-${Date.now()}`, text: '', type: 'text', options: [], isRequired: true }]);
  };

  const handleQuestionChange = (id, field, value) => {
    setQuestions(prev => prev.map(q => (q.id === id ? { ...q, [field]: value } : q)));
  };

  const handleRemoveQuestion = (id) => {
    if (questions.length <= 1) {
      toast({ title: "Minimum Questions", description: "A survey must have at least one question.", variant: "destructive" });
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
  };
  
  const handleUpdate = async (submitType) => {
    if (promptSave()) return;

    setActiveSubmitType(submitType);
    setIsSubmitting(true);
    
    if (!title.trim()) {
      toast({ title: 'Validation Error', description: 'Survey title is required.', variant: 'destructive' });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }
    
    // Strict validation for question text
    const invalidQuestionIndex = questions.findIndex(q => !q.text || !q.text.trim());
    if (invalidQuestionIndex !== -1) {
      toast({ 
        title: 'Validation Error', 
        description: `Question ${invalidQuestionIndex + 1} cannot be empty. Please add text before saving.`, 
        variant: 'destructive' 
      });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }

    try {
      const { error: surveyError } = await supabase
        .from('surveys')
        .update({
          title,
          description,
          status: submitType === 'activate' ? 'active' : 'draft',
          updated_at: new Date().toISOString(),
        })
        .eq('id', surveyId);

      if (surveyError) throw surveyError;

      const questionUpserts = questions.map((q, index) => ({
        id: String(q.id).startsWith('temp-') ? undefined : q.id,
        survey_id: surveyId,
        question_text: q.text.trim(), // Ensure trimmed text
        question_type: q.type,
        options: ['multiple-choice', 'likert', 'yes-no'].includes(q.type) && q.options.length > 0 ? { options: q.options.filter(Boolean) } : null,
        sequence_order: index + 1,
        is_required: q.isRequired,
      }));
      
      const { error: questionsError } = await supabase.from('survey_questions').upsert(questionUpserts, { onConflict: 'id' });

      if (questionsError) throw questionsError;

      toast({ title: 'Survey Updated!', description: 'Your changes have been saved successfully.', className: 'bg-green-500 text-white' });
      navigate(isDemo ? '/demo/surveys' : '/surveys');

    } catch (error) {
      console.error('Update Error:', error);
      toast({ title: 'Error Updating Survey', description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
      setActiveSubmitType(null);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8"
    >
      <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-primary text-2xl">
              <ClipboardCheck className="w-6 h-6 mr-3" aria-hidden="true"/>
              Edit Text Survey
            </CardTitle>
            <CardDescription>Modify your existing text-based survey.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="surveyTitle">Survey Title</Label>
              <Input id="surveyTitle" value={title} onChange={(e) => setTitle(e.target.value)} required className="mt-1" disabled={isSubmitting}/>
            </div>
            <div>
              <Label htmlFor="surveyDescription">Description (Optional)</Label>
              <Textarea id="surveyDescription" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 min-h-[80px]" disabled={isSubmitting}/>
            </div>
          </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Survey Questions</CardTitle>
                <CardDescription>Edit the questions for your survey below.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {questions.map((q, index) => (
                    <SurveyQuestionBuilder key={q.id} question={q} index={index} onQuestionChange={handleQuestionChange} onRemoveQuestion={handleRemoveQuestion} disabled={isSubmitting} />
                  ))}
                  <Button type="button" variant="outline" onClick={handleAddQuestion} className="w-full border-dashed" disabled={isSubmitting}>
                    <PlusCircle className="w-5 h-5 mr-2" aria-hidden="true" /> Add Question
                  </Button>
            </CardContent>
        </Card>

        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" onClick={() => navigate(isDemo ? '/demo/surveys' : '/surveys')} disabled={isSubmitting}>Cancel</Button>
          <Button type="button" variant="secondary" onClick={() => handleUpdate('draft')} disabled={isSubmitting}>
            {isSubmitting && activeSubmitType === 'draft' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
            Save as Draft
          </Button>
          <Button type="button" onClick={() => handleUpdate('activate')} disabled={isSubmitting}>
            {isSubmitting && activeSubmitType === 'activate' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <FileUp className="w-5 h-5 mr-2" />}
            Save & Activate
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default EditSurveyPage;