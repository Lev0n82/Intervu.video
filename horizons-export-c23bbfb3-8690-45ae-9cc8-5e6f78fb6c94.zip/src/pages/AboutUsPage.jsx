
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Zap, BrainCircuit, Users, BookOpen, GitBranch, FileText, Cpu, Shield, Target, TrendingUp, HeartHandshake as Handshake } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';

const BenefitCard = ({ icon, title, description }) => (
  <motion.div
    className="bg-card p-6 rounded-xl shadow-lg border border-border hover:shadow-primary/20 transition-shadow duration-300 flex flex-col text-center items-center"
    whileHover={{ y: -5 }}
  >
    <div className="flex items-center justify-center w-12 h-12 bg-primary text-primary-foreground rounded-full mb-4" aria-hidden="true">
      {icon}
    </div>
    <h3 className="text-lg font-semibold text-card-foreground mb-2">{title}</h3>
    <p className="text-muted-foreground text-sm leading-relaxed flex-grow">{description}</p>
  </motion.div>
);

const AboutUsPage = () => {
  return (
    <>
      <Helmet>
        <title>About Us | Why Intervu.video</title>
        <meta name="description" content="Learn about Intervu.video's mission to make hiring more efficient, effective, and equitable with ethical AI technology and advanced behavioral analysis." />
      </Helmet>
      <div className="container mx-auto max-w-5xl py-12 sm:py-16 px-4">
        <motion.header
          className="text-center mb-12 sm:mb-16"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-primary mb-4">A Smarter, Faster, and Fairer Approach to Hiring</h1>
          <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto">In today's competitive talent market, attracting and hiring the right people is more challenging than ever. Intervu.video is an advanced workflow optimisation & hiring platform designed to help you reclaim your time, reduce hiring costs, and build the team of your dreams with confidence.</p>
        </motion.header>

        <section className="mb-12 sm:mb-16" aria-labelledby="key-benefits-heading">
          <h2 id="key-benefits-heading" className="text-2xl sm:text-3xl font-bold text-center mb-8">Key Benefits for Your Organization</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            <BenefitCard
              icon={<TrendingUp size={24} />}
              title="Reduce Time-to-Hire by 60%"
              description="Automate scheduling, screening, and analysis to accelerate your hiring cycle and fill critical roles faster."
            />
            <BenefitCard
              icon={<Target size={24} />}
              title="Improve Quality of Hire"
              description="Our AI analyzes thousands of data points, including behavioral indicators, to identify top performers and authentic candidates."
            />
            <BenefitCard
              icon={<Shield size={24} />}
              title="Enhance Candidate Authenticity"
              description="Advanced facial and voice analysis helps identify inconsistencies, providing an additional layer of due diligence."
            />
            <BenefitCard
              icon={<Users size={24} />}
              title="Enhance Candidate Experience"
              description="Provide a modern, flexible, and engaging interview experience with full transparency about our AI analysis."
            />
            <BenefitCard
              icon={<BrainCircuit size={24} />}
              title="Promote Fair & Unbiased Hiring"
              description="Standardized questions and objective AI analysis help eliminate unconscious bias, ensuring fair evaluation."
            />
            <BenefitCard
              icon={<Zap size={24} />}
              title="Increase Recruiter Productivity"
              description="Free your team from administrative tasks to focus on strategic initiatives like employer branding."
            />
          </div>
        </section>

        <section className="mb-12 sm:mb-16 text-center" aria-labelledby="our-mission-heading">
            <h2 id="our-mission-heading" className="text-2xl sm:text-3xl font-bold text-center mb-4">About Us: The People Behind a Smarter Way to Hire</h2>
            <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto mb-4">
              Our mission is simple: to make hiring more efficient, effective, and equitable for everyone.
            </p>
            <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto mb-4">Intervu.video was founded by a team of IT professionals, data scientists, and engineers who were frustrated with the inefficiencies and biases of traditional hiring methods. We saw firsthand how much time and talent was being wasted on outdated processes, and we knew there had to be a better way.</p>
            <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto">
              We believe that technology can be a powerful force for good in the world of work. We are passionate about building a platform that not only saves companies time and money, but also creates a more positive and fair experience for job seekers. Our goal is to empower organizations to build the best possible teams, and to help talented individuals find the roles where they can truly shine.
            </p>
            
            <h3 className="text-xl sm:text-2xl font-bold text-center mt-10 mb-4">Our Commitment to Ethical use of technology</h3>
            <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto">We are not just a technology company; we are a people company. We understand that hiring is a deeply human process, and we are committed to building human in the loop workflows that augments human intelligence, not replaces it. Our platform is built on a foundation of transparency, fairness, and accountability. We are constantly working to ensure that our algorithms are free from bias and that our platform promotes equitable outcomes for all.</p>

            <Button asChild size="lg" className="mt-8">
              <Link to="/technical-details">Explore Our Technology</Link>
            </Button>
        </section>

        <section className="mb-12 sm:mb-16 text-center" aria-labelledby="join-us-heading">
            <h2 id="join-us-heading" className="text-2xl sm:text-3xl font-bold text-center mb-4">Join Us on Our Journey</h2>
            <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto">
              We are always looking for passionate and talented individuals to join our team. If you are excited about the future of work and believe in the power of technology to create positive change, we would love to hear from you.
            </p>
            <Button asChild size="lg" variant="secondary" className="mt-8">
              {/* This link will likely point to a separate careers page later */}
              <Link to="/contact">Visit our careers page</Link>
            </Button>
        </section>

        <section className="p-6 sm:p-8 bg-secondary/50 rounded-xl shadow-xl border border-border" aria-labelledby="open-source-heading">
          <h2 id="open-source-heading" className="text-2xl sm:text-3xl font-bold text-primary mb-6 text-center">Our Open Source Commitment</h2>
          <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg"><GitBranch /></div>
              <div>
                <h3 className="text-lg font-semibold">Promoting Innovation</h3>
                <p className="text-muted-foreground text-sm">Our core virtual interview patent is open-sourced to foster innovation and prevent patent trolling, ensuring the technology remains accessible to all.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-primary/10 text-primary rounded-lg"><FileText /></div>
              <div>
                <h3 className="text-lg font-semibold">Permissive License</h3>
                <p className="text-muted-foreground text-sm">Our technology is licensed to allow free use, modification, and commercial implementation, with the sole restriction being that it cannot be used to file new, restrictive patents.</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutUsPage;
