import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Save, Database, AlertTriangle, Loader2 } from 'lucide-react';

const storageProviders = [
  { id: 'supabase', name: 'intervu.video Storage (Default)' },
  { id: 'gdrive', name: 'Google Drive' },
  { id: 'onedrive', name: 'OneDrive' },
  { id: 'dropbox', name: 'Dropbox' },
  { id: 'box', name: 'Box' },
  { id: 'backblaze', name: 'Backblaze B2' },
  { id: 'aws_s3', name: 'Amazon S3' },
];

const OrganizationSettingsPage = () => {
  const { activeOrganization } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [settings, setSettings] = useState(null);
  const [selectedProvider, setSelectedProvider] = useState('supabase');

  const fetchSettings = useCallback(async () => {
    if (!activeOrganization?.id) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('organization_storage_settings')
      .select('*')
      .eq('organization_id', activeOrganization.id)
      .maybeSingle();

    if (error) {
      toast({ title: 'Error fetching settings', description: error.message, variant: 'destructive' });
    } else {
      setSettings(data);
      setSelectedProvider(data?.provider || 'supabase');
    }
    setLoading(false);
  }, [activeOrganization?.id, toast]);

  useEffect(() => {
    if (activeOrganization) {
      fetchSettings();
    } else {
      setLoading(false);
    }
  }, [fetchSettings, activeOrganization]);

  const handleSave = async () => {
    if (!activeOrganization?.id) {
      toast({ title: 'Error', description: 'No active organization selected.', variant: 'destructive' });
      return;
    }
    setIsSaving(true);
    
    const { error } = await supabase
      .from('organization_storage_settings')
      .upsert(
        { organization_id: activeOrganization.id, provider: selectedProvider, is_active: true },
        { onConflict: 'organization_id' }
      );

    if (error) {
      toast({ title: 'Failed to save settings', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Settings Saved!', description: 'Your storage provider preference has been updated.', className: 'bg-green-500 text-white' });
      fetchSettings();
    }
    setIsSaving(false);
  };

  const renderProviderInfo = () => {
    if (selectedProvider === 'supabase') {
      return null;
    }
    return (
      <div className="mt-4 p-4 bg-yellow-900/20 border border-yellow-500/30 rounded-lg text-yellow-200">
        <div className="flex items-start">
          <AlertTriangle className="h-5 w-5 mr-3 mt-1 text-yellow-400" />
          <div>
            <h4 className="font-semibold">Integration Required</h4>
            <p className="text-sm text-yellow-300">
              Connecting to this provider requires additional setup. This feature is not yet implemented.
              For now, all data will be stored securely with intervu.video Storage.
            </p>
          </div>
        </div>
      </div>
    );
  };

  if (!activeOrganization) {
     return (
        <Card className="bg-card border-border">
            <CardHeader>
                <CardTitle className="text-2xl text-primary flex items-center">
                    <Database className="mr-3" /> Organization Settings
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground text-center py-8">Please select an organization to manage settings.</p>
            </CardContent>
        </Card>
     )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center">
            <Database className="mr-3" /> Organization Settings
          </CardTitle>
          <CardDescription>
            Manage settings for your organization: <span className="font-semibold text-primary">{activeOrganization.name}</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
             <div className="flex justify-center items-center py-10">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
             </div>
          ) : (
            <div className="space-y-6">
              <div>
                <Label htmlFor="storage-provider" className="text-lg font-medium">
                  Data Storage Provider
                </Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Choose where your interview videos and results are stored.
                </p>
                <Select value={selectedProvider} onValueChange={setSelectedProvider} disabled={isSaving}>
                  <SelectTrigger id="storage-provider" className="w-full md:w-1/2">
                    <SelectValue placeholder="Select a storage provider" />
                  </SelectTrigger>
                  <SelectContent>
                    {storageProviders.map(provider => (
                      <SelectItem key={provider.id} value={provider.id}>
                        {provider.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {renderProviderInfo()}
              </div>
              <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving || loading}>
                  {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  {isSaving ? 'Saving...' : 'Save Settings'}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default OrganizationSettingsPage;