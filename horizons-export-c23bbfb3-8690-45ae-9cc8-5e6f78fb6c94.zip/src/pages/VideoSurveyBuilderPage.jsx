
import React, { useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PlusCircle, Save, Video, Loader2, FileUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import VideoSurveyQuestion from '@/components/VideoSurveyQuestion';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import VideoRecorder from '@/components/VideoRecorder';
import TemplateSelector from '@/components/TemplateSelector';
import { commonVideoSurveyTemplates } from '@/lib/predefinedTemplates';
import AIGenerationDialog from '@/components/interview/AIGenerationDialog';
import { useVideoGeneration } from '@/hooks/useVideoGeneration';

const VideoSurveyBuilderPage = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([{ id: Date.now(), question_text: '', question_video_url: null, clarification_video_url: null }]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeSubmitType, setActiveSubmitType] = useState(null);
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [isAiDialogOpen, setIsAiDialogOpen] = useState(false);
  const [activeQuestionId, setActiveQuestionId] = useState(null);
  const [activeVideoField, setActiveVideoField] = useState(null);
  const [personas, setPersonas] = useState([]);
  const fileInputRef = React.useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  const [savingForAI, setSavingForAI] = useState(false);

  const { activeOrganization, user } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();

  // AI Generation Hook
  const handleGenerationComplete = useCallback((questionId, field, url) => {
    setQuestions(currentQuestions => 
        currentQuestions.map(q => q.id === questionId ? { ...q, [field]: url } : q)
    );
    toast({ title: "Video Generated", description: "Your AI video is ready!" });
  }, [toast]);

  const { generations, startGeneration } = useVideoGeneration(activeOrganization?.id, handleGenerationComplete);

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: Date.now(), question_text: '', question_video_url: null, clarification_video_url: null }]);
  };

  const handleQuestionChange = (id, field, value) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, [field]: value } : q));
  };

  const handleRemoveQuestion = (id) => {
    if (questions.length <= 1) {
      toast({ title: "Minimum Questions", description: "A survey must have at least one question.", variant: "destructive" });
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
  };
  
  const handleSelectTemplate = (template) => {
    const { title, description, questions: templateQuestions } = template.data;
    setTitle(title);
    setDescription(description);
    setQuestions(templateQuestions.map(q => ({...q, id: `temp-${Date.now()}-${Math.random()}`})));
    toast({ title: "Template Applied!", description: `The "${template.name}" template has been loaded.` });
  };

  const openRecorder = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    setIsRecorderOpen(true);
  };

   const handleUploadClick = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    fileInputRef.current.click();
  };
  
  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    const fileName = `template-videos/video-${Date.now()}-${file.name}`;
    
    try {
        const { data, error } = await supabase.storage
            .from('template-videos')
            .upload(fileName, file, {
                cacheControl: '3600',
                upsert: false,
            });

        if (error) throw error;
        
        const { data: { publicUrl } } = supabase.storage.from('template-videos').getPublicUrl(data.path);
        
        if (activeQuestionId && activeVideoField) {
            handleQuestionChange(activeQuestionId, activeVideoField, publicUrl);
        }

        toast({ title: "Upload Complete!", description: "Your video has been saved.", className: "bg-green-500 text-white" });

    } catch (error) {
        toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
    } finally {
        setIsUploading(false);
        event.target.value = '';
    }
  };

  const openAiGenerator = (questionId, videoField) => {
      setActiveQuestionId(questionId);
      setActiveVideoField(videoField);
      setIsAiDialogOpen(true);
  };

  const handleStartGeneration = async (prompt, personaId) => {
    if (promptSave()) return;
    
    if (!activeOrganization?.id || !user?.id) {
        toast({ title: "Error", description: "Cannot start AI generation. Missing context.", variant: "destructive" });
        return;
    }

    setSavingForAI(true);
    setIsAiDialogOpen(false);

    try {
        // NOTE: We pass null for template_question_id since this is a survey, and backend handles nullable.
        await startGeneration(
            activeQuestionId, 
            activeVideoField, 
            prompt, 
            user.id, 
            null 
        );
        
        toast({ title: "AI Generation Queued", description: "Your video is being generated." });

    } catch (err) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
        setSavingForAI(false);
    }
  };

  const handleRecorderUploadComplete = (data) => {
    if (activeQuestionId && activeVideoField) {
      handleQuestionChange(activeQuestionId, activeVideoField, data.url);
    }
    setIsRecorderOpen(false);
    setActiveQuestionId(null);
    setActiveVideoField(null);
  };
  
  const handleSave = async (submitType) => {
    if (promptSave()) return;
    
    setActiveSubmitType(submitType);
    setIsSubmitting(true);
    
    if (!activeOrganization?.id || !user?.id) {
      toast({ title: 'Error', description: 'Organization or user not found.', variant: 'destructive' });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }
    if (!title.trim()) {
      toast({ title: 'Validation Error', description: 'Survey title is required.', variant: 'destructive' });
      setIsSubmitting(false);
      setActiveSubmitType(null);
      return;
    }
    
    if (submitType === 'activate') {
        if (questions.some(q => !q.question_text || !q.question_text.trim())) {
            toast({ title: 'Validation Error', description: 'All questions must have a summary text to activate.', variant: 'destructive' });
            setIsSubmitting(false);
            setActiveSubmitType(null);
            return;
        }
        if (questions.some(q => !q.question_video_url)) {
            toast({ title: 'Validation Error', description: 'To activate, all questions must have a recorded question video.', variant: 'destructive' });
            setIsSubmitting(false);
            setActiveSubmitType(null);
            return;
        }
    }

    try {
      const { data: surveyData, error: surveyError } = await supabase
        .from('surveys')
        .insert({
          title,
          description,
          organization_id: activeOrganization.id,
          created_by: user.id,
          survey_type: 'video',
          allow_resubmission: false,
          status: submitType === 'activate' ? 'active' : 'draft',
        })
        .select()
        .single();

      if (surveyError) throw surveyError;

      const surveyId = surveyData.id;
      const questionInserts = questions.map((q, index) => ({
        survey_id: surveyId,
        question_text: q.question_text ? q.question_text.trim() : '', 
        question_type: 'video',
        sequence_order: index + 1,
        is_required: true,
        question_video_url: q.question_video_url,
        clarification_video_url: q.clarification_video_url,
      }));

      const { error: questionsError } = await supabase.from('survey_questions').insert(questionInserts);

      if (questionsError) {
          await supabase.from('surveys').delete().eq('id', surveyId);
          throw questionsError;
      }

      toast({ title: submitType === 'activate' ? 'Survey Activated!' : 'Draft Saved!', description: `Your video survey has been saved.`, className: 'bg-green-500 text-white' });
      navigate(isDemo ? '/demo/surveys' : '/surveys');

    } catch (error) {
        console.error("Survey Save Error:", error);
        let msg = error.message;
        if (error.code === '23505') msg = "Duplicate key violation. Please check your data.";
        toast({ title: 'Error Saving Survey', description: msg, variant: 'destructive' });
    } finally {
        setIsSubmitting(false);
        setActiveSubmitType(null);
    }
  };


  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 sm:p-6 max-w-4xl mx-auto space-y-8"
      >
        <TemplateSelector templates={commonVideoSurveyTemplates} onSelectTemplate={handleSelectTemplate} />

        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-primary text-2xl">
                <Video className="w-6 h-6 mr-3" aria-hidden="true"/>
                Video Survey Builder
              </CardTitle>
              <CardDescription>Create a survey where each question is presented via video.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="surveyTitle">Survey Title</Label>
                <Input
                  id="surveyTitle"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Q3 Product Feedback Video Survey"
                  required
                  className="mt-1"
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="surveyDescription">Description (Optional)</Label>
                <Textarea
                  id="surveyDescription"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="A brief description of the video survey's purpose."
                  className="mt-1 min-h-[80px]"
                  disabled={isSubmitting}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
              <CardHeader>
                  <CardTitle>Survey Questions</CardTitle>
                  <CardDescription>Build the video questions for your survey below.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                   {questions.map((q, index) => (
                      <VideoSurveyQuestion
                        key={q.id}
                        question={q}
                        index={index}
                        onQuestionChange={handleQuestionChange}
                        onRemoveQuestion={handleRemoveQuestion}
                        onRecordVideo={openRecorder}
                        onUploadVideo={handleUploadClick}
                        onGenerateVideo={openAiGenerator}
                        disabled={isSubmitting || isUploading || savingForAI}
                        generationStatus={{
                            'question_video_url': generations[`${q.id}-question_video_url`],
                            'clarification_video_url': generations[`${q.id}-clarification_video_url`]
                        }}
                      />
                    ))}
                    <Button type="button" variant="outline" onClick={handleAddQuestion} className="w-full border-dashed" disabled={isSubmitting || isUploading}>
                      <PlusCircle className="w-5 h-5 mr-2" aria-hidden="true" /> Add Question
                    </Button>
              </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline" onClick={() => navigate(isDemo ? '/demo/surveys' : '/surveys')} disabled={isSubmitting || isUploading}>
              Cancel
            </Button>
            <Button type="button" variant="secondary" onClick={() => handleSave('draft')} disabled={isSubmitting || isUploading}>
              {isSubmitting && activeSubmitType === 'draft' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
              Save as Draft
            </Button>
            <Button type="button" onClick={() => handleSave('activate')} disabled={isSubmitting || isUploading}>
              {isSubmitting && activeSubmitType === 'activate' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <FileUp className="w-5 h-5 mr-2" />}
              Save & Activate
            </Button>
          </div>
        </form>
      </motion.div>
      <VideoRecorder
        open={isRecorderOpen}
        onOpenChange={setIsRecorderOpen}
        onUploadComplete={handleRecorderUploadComplete}
      />
       <AIGenerationDialog
          open={isAiDialogOpen}
          onOpenChange={setIsAiDialogOpen}
          onStartGeneration={handleStartGeneration}
          questionText={questions.find(q => q.id === activeQuestionId)?.question_text || ''}
          personaId={null}
          personas={personas}
       />
       <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="video/*"
          disabled={isUploading}
       />
    </>
  );
};

export default VideoSurveyBuilderPage;
