import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { BarChart2, Plus, Users, FileText, Video } from 'lucide-react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import Preloader from '@/components/Preloader';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const DashboardPage = () => {
    // 1. Consume contexts
    const { userProfile: authUserProfile, activeOrganization: authOrg, loading: authLoading } = useAuth();
    const { isDemo } = useDemo();
    const navigate = useNavigate();

    // 2. Define Mock Data for Demo Mode
    // This ensures the component has data to render even if the user isn't logged in.
    const demoProfile = { 
        full_name: 'Demo User', 
        team_memberships: [{ 
            organization_id: 'demo-org-id',
            role: { name: 'Admin' } 
        }] 
    };
    
    const demoOrg = { 
        id: 'demo-org-id', 
        name: 'Demo Organization' 
    };

    // 3. Determine Effective State
    // If isDemo is true, we forcefully set loading to false and use mock data.
    const loading = isDemo ? false : authLoading;
    const userProfile = isDemo ? demoProfile : authUserProfile;
    const activeOrganization = isDemo ? demoOrg : authOrg;

    // 4. Helper for Navigation
    // Keeps the user in the /demo namespace if they are currently in demo mode.
    const getRoute = (path) => isDemo ? `/demo${path}` : path;

    // 5. Preloader Logic
    // If we are not in demo mode AND (loading is true OR we lack a profile), show loader.
    // In demo mode, 'loading' is forced false, so we skip this.
    if (loading || (!isDemo && !userProfile)) {
      return <div className="flex items-center justify-center h-full"><Preloader /></div>;
    }
    
    // 6. Permission Logic
    // In demo mode, we assume Admin access.
    const canCreate = isDemo || userProfile?.team_memberships?.some(
        m => m.organization_id === activeOrganization?.id && (m.role.name === 'Admin' || m.role.name === 'Manager')
    );

    const containerVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                staggerChildren: 0.1
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, scale: 0.95 },
        visible: { opacity: 1, scale: 1 }
    };

    const ActionButton = ({ icon, title, description, onClick, disabled }) => (
        <motion.div variants={itemVariants}>
            <Card className="hover:border-primary transition-colors duration-300 group h-full flex flex-col">
                <CardHeader>
                    <CardTitle className="flex items-center text-xl">
                        {icon}
                        {title}
                    </CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                    <CardDescription>{description}</CardDescription>
                </CardContent>
                <div className="p-6 pt-0">
                    <Button onClick={onClick} className="w-full" disabled={disabled} aria-label={`Create New ${title}`}>
                        <Plus className="mr-2 h-4 w-4" aria-hidden="true" /> Create New
                    </Button>
                </div>
            </Card>
        </motion.div>
    );

     const SurveyActionButton = ({ icon, title, description, disabled }) => (
        <motion.div variants={itemVariants}>
            <Card className="hover:border-primary transition-colors duration-300 group h-full flex flex-col">
                <CardHeader>
                    <CardTitle className="flex items-center text-xl">
                        {icon}
                        {title}
                    </CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                    <CardDescription>{description}</CardDescription>
                </CardContent>
                <div className="p-6 pt-0">
                     <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button className="w-full" disabled={disabled} aria-label="Create New Survey Options">
                            <Plus className="mr-2 h-4 w-4" aria-hidden="true" /> Create New
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        <DropdownMenuItem onSelect={() => navigate(getRoute('/surveys/new'))}>
                          <FileText className="mr-2 h-4 w-4" aria-hidden="true" />
                          <span>Text Survey</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onSelect={() => navigate(getRoute('/surveys/video/new'))}>
                          <Video className="mr-2 h-4 w-4" aria-hidden="true" />
                          <span>Video Survey</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </Card>
        </motion.div>
    );


    return (
        <>
            <Helmet>
                <title>Dashboard | Intervu.video</title>
                <meta name="description" content="Overview of your organization and quick actions." />
            </Helmet>
            <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="space-y-8"
            >
                <motion.div variants={itemVariants} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-4xl font-extrabold tracking-tight text-primary">
                            Welcome Back{userProfile.full_name ? `, ${userProfile.full_name}` : ''}
                        </h1>
                        <p className="text-lg text-muted-foreground mt-2">
                           Here's an overview of your active organization{activeOrganization?.name ? `, ${activeOrganization.name}` : ''}.
                        </p>
                    </div>
                </motion.div>

                {canCreate ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                         <ActionButton
                            icon={<Video className="mr-3 text-primary" aria-hidden="true" />}
                            title="Video Interviews"
                            description="Create and manage asynchronous video interviews for your candidates."
                            onClick={() => navigate(getRoute('/templates/new'))}
                        />
                         <SurveyActionButton
                            icon={<FileText className="mr-3 text-primary" aria-hidden="true" />}
                            title="Surveys"
                            description="Design and deploy text or video-based surveys to gather feedback."
                        />
                    </div>
                ) : (
                    <motion.div variants={itemVariants}>
                        <Card className="text-center p-8">
                            <CardHeader>
                                <CardTitle>View-Only Access</CardTitle>
                                <CardDescription className="mt-2">
                                    You currently have view-only access. Contact an administrator to gain full access to creating content.
                                </CardDescription>
                            </CardHeader>
                        </Card>
                    </motion.div>
                )}


                <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="hover:shadow-primary/20 transition-shadow">
                        <CardHeader>
                            <CardTitle className="flex items-center"><Users className="mr-2 text-primary" aria-hidden="true" />Team Members</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground">View and manage the members of your organization.</p>
                            <Button variant="outline" className="mt-4" onClick={() => navigate(getRoute('/team'))}>Manage Team</Button>
                        </CardContent>
                    </Card>
                    <Card className="hover:shadow-primary/20 transition-shadow">
                        <CardHeader>
                            <CardTitle className="flex items-center"><BarChart2 className="mr-2 text-primary" aria-hidden="true" />Reports & Analytics</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground">Access detailed reports and analytics on interviews and submissions.</p>
                            <Button variant="outline" className="mt-4" onClick={() => navigate(getRoute('/reports'))}>View Reports</Button>
                        </CardContent>
                    </Card>
                </motion.div>
            </motion.div>
        </>
    );
};

export default DashboardPage;