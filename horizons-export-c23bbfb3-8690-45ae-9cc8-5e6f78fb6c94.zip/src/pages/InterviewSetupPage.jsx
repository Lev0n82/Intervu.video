import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PlusCircle, Save, FileText, Loader2, FileUp, Sparkles, Wand2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import QuestionBuilder from '@/components/interview/QuestionBuilder';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import TemplateSelector from '@/components/TemplateSelector';
import { commonInterviewTemplates } from '@/lib/predefinedTemplates';
import VideoRecorder from '@/components/VideoRecorder';
import AIGenerationDialog from '@/components/interview/AIGenerationDialog';
import VideoGenerationQueue from '@/components/VideoGenerationQueue';
import { isValidUUID } from '@/lib/utils';

const InterviewSetupPage = () => {
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  const [introductionText, setIntroductionText] = useState('');
  const [questions, setQuestions] = useState([{ id: `temp-${Date.now()}`, question_text: '', clarification_text: '', persona_id: null, order: 0 }]);
  const [personas, setPersonas] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeSubmitType, setActiveSubmitType] = useState(null);
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [activeQuestionId, setActiveQuestionId] = useState(null);
  const [activeVideoField, setActiveVideoField] = useState(null);
  const [isAiDialogOpen, setIsAiDialogOpen] = useState(false);
  const fileInputRef = React.useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  
  // Track if we've already created a draft in the DB to allow question attachment
  const [savedTemplateId, setSavedTemplateId] = useState(null);
  
  const { activeOrganization, user } = useAuth();
  const { isDemo, promptSave } = useDemo();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPersonas = async () => {
      if (!activeOrganization?.id) return;
      try {
        const { data, error } = await supabase
          .from('personas')
          .select('*')
          .eq('organization_id', activeOrganization.id)
          .is('deleted_at', null);
        if (error) throw error;
        setPersonas(data);
      } catch (error) {
        toast({ title: 'Error fetching personas', description: error.message, variant: 'destructive' });
      }
    };
    fetchPersonas();
  }, [activeOrganization, toast]);

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: `temp-${Date.now()}`, question_text: '', clarification_text: '', persona_id: null, order: questions.length }]);
  };

  const handleQuestionChange = (id, field, value) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, [field]: value } : q));
  };

  const handleRemoveQuestion = (id) => {
    if (questions.length <= 1) {
      toast({ title: "Minimum Questions", description: "An interview template must have at least one question.", variant: "destructive" });
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
  };
  
  const handleSelectTemplate = (template) => {
    const { templateName, templateDescription, introductionText, questions: templateQuestions } = template.data;
    setTemplateName(templateName);
    setTemplateDescription(templateDescription);
    setIntroductionText(introductionText);
    setQuestions(templateQuestions.map((q, index) => ({
      ...q,
      id: `temp-${Date.now()}-${index}`,
      order: index
    })));
    toast({ title: "Template Applied!", description: `The "${template.name}" template has been loaded.` });
  };
  
  const openRecorder = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    setIsRecorderOpen(true);
  };

  const handleUploadClick = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    fileInputRef.current.click();
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    const fileName = `template-videos/video-${Date.now()}-${file.name}`;
    
    try {
        const { data, error } = await supabase.storage.from('template-videos').upload(fileName, file);
        if (error) throw error;
        const { data: { publicUrl } } = supabase.storage.from('template-videos').getPublicUrl(data.path);
        
        handleUploadComplete(publicUrl);
        toast({ title: "Upload Complete!", description: "Your video has been saved.", className: "bg-green-500 text-white" });
    } catch (error) {
        toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
    } finally {
        setIsUploading(false);
        event.target.value = '';
    }
  };
  
  const handleUploadComplete = (url) => {
    if (activeQuestionId && activeVideoField) {
      handleQuestionChange(activeQuestionId, activeVideoField, url);
    }
    setIsRecorderOpen(false);
  };
  
  const openAiGenerator = (questionId, videoField) => {
    setActiveQuestionId(questionId);
    setActiveVideoField(videoField);
    setIsAiDialogOpen(true);
  };
  
  const validateContextUUIDs = () => {
    // 1. Validate Org ID
    if (!activeOrganization?.id || !isValidUUID(activeOrganization.id)) {
        console.error("Invalid Organization UUID:", activeOrganization?.id);
        toast({ title: "Configuration Error", description: "Invalid Organization ID found. Please refresh the page.", variant: "destructive" });
        return false;
    }
    
    // 2. Validate User ID
    if (!user?.id || !isValidUUID(user.id)) {
        console.error("Invalid User UUID:", user?.id);
        toast({ title: "Authentication Error", description: "Invalid User ID found. Please relogin.", variant: "destructive" });
        return false;
    }
    return true;
  };

  const ensureDraftTemplateExists = async () => {
    if (savedTemplateId) return savedTemplateId;
    
    if (!validateContextUUIDs()) {
        throw new Error("Missing valid context identifiers (Org/User)");
    }

    const draftName = templateName.trim() || `Draft Template ${new Date().toLocaleString()}`;
    
    // Check existing
    if (templateName.trim()) {
         const { data: existing } = await supabase
            .from('interview_templates')
            .select('id')
            .eq('organization_id', activeOrganization.id)
            .eq('name', templateName.trim())
            .maybeSingle();
            
         if (existing) {
             console.log("Found existing template with same name, using it.");
             setSavedTemplateId(existing.id);
             return existing.id;
         }
    }

    // Explicitly generate UUID client-side for safety and tracking
    const newTemplateId = crypto.randomUUID();
    console.log("Creating draft template with Generated UUID:", newTemplateId);
    console.log("Using Organization UUID:", activeOrganization.id);
    console.log("Using User UUID:", user.id);

    const { data, error } = await supabase
        .from('interview_templates')
        .insert({
            id: newTemplateId,
            name: draftName,
            description: templateDescription || 'Draft created during video generation.',
            introduction_text: introductionText,
            organization_id: activeOrganization.id,
            created_by: user.id,
            status: 'draft',
        })
        .select()
        .single();

    if (error) {
        if (error.code === '23505') {
            throw new Error("A template with this name already exists. Please change the name.");
        }
        throw error;
    }
    
    setSavedTemplateId(data.id);
    return data.id;
  };

  const handleStartGeneration = async (prompt, personaId) => {
    if (promptSave()) return;
    if (!personaId) throw new Error("Persona is required.");
    
    setIsAiDialogOpen(false);
    
    try {
      if (!validateContextUUIDs()) return;

      // 1. Ensure we have a valid template ID to attach the question to
      const targetTemplateId = await ensureDraftTemplateExists();
      
      // 2. Insert the specific question into the DB to get a real ID
      const currentQuestionState = questions.find(q => q.id === activeQuestionId);
      const questionOrder = currentQuestionState ? currentQuestionState.order : 999;
      
      let questionDbId = null;
      let dbError = null;
      let questionData = null;

      if (String(activeQuestionId).startsWith('temp-')) {
          // Generate UUID for question if it's new
          const newQuestionId = crypto.randomUUID();
          
          const { data, error } = await supabase.from('template_questions')
          .insert({
              id: newQuestionId,
              template_id: targetTemplateId,
              question_text: prompt,
              persona_id: personaId,
              order: questionOrder
          }).select().single();
          
          questionData = data;
          dbError = error;
      } else {
          // Update existing
           const { data, error } = await supabase.from('template_questions')
          .update({
              question_text: prompt,
              persona_id: personaId
          })
          .eq('id', activeQuestionId)
          .select().single();
          
          questionData = data;
          dbError = error;
      }
      
      if (dbError) throw dbError;
      questionDbId = questionData.id;

      // 3. Update local state
      if (String(activeQuestionId).startsWith('temp-')) {
        setQuestions(prev => prev.map(q => q.id === activeQuestionId ? { ...q, id: questionDbId, question_text: prompt, persona_id: personaId } : q));
        setActiveQuestionId(questionDbId);
      } else {
        setQuestions(prev => prev.map(q => q.id === activeQuestionId ? { ...q, question_text: prompt, persona_id: personaId } : q));
      }

      // 4. Queue the generation
      const { error: queueError } = await supabase.from('video_generation_queue').insert({
        organization_id: activeOrganization.id,
        created_by: user.id,
        prompt: prompt,
        template_question_id: questionDbId,
        status: 'queued',
        progress: 0,
      });
      
      if (queueError) throw queueError;

      toast({ title: "AI Generation Queued", description: "Your video is being generated. Track its progress in the queue.", });

    } catch (error) {
      console.error("Failed to start generation:", error);
      let msg = error.message;
      if (error.code === '23505') msg = "Duplicate name or record found. Please verify your data.";
      toast({ title: "Generation Error", description: msg, variant: "destructive" });
    }
  };

  const handleSave = async (submitType) => {
    if (promptSave()) return;
    setActiveSubmitType(submitType);
    setIsSubmitting(true);
    
    // Strict UUID Validation
    if (!validateContextUUIDs()) {
        setIsSubmitting(false);
        setActiveSubmitType(null);
        return;
    }

    if (!templateName.trim()) {
        toast({ title: 'Validation Error', description: 'Template name is required.', variant: 'destructive' });
        setIsSubmitting(false);
        setActiveSubmitType(null);
        return;
    }

    if (submitType === 'active') {
        if (questions.some(q => !q.question_text.trim() || !q.persona_id || !q.question_video_url)) {
            toast({ title: 'Validation Error', description: 'To activate, all questions must have a prompt, a persona, and a video.', variant: 'destructive' });
            setIsSubmitting(false);
            setActiveSubmitType(null);
            return;
        }
    }

    try {
        let templateId = savedTemplateId;

        // 1. Upsert Template
        if (templateId) {
             const { error: updateError } = await supabase
            .from('interview_templates')
            .update({
                name: templateName,
                description: templateDescription,
                introduction_text: introductionText,
                status: submitType === 'active' ? 'active' : 'draft',
                updated_at: new Date().toISOString()
            })
            .eq('id', templateId);
            
            if (updateError) throw updateError;
        } else {
            // Check existence
             const { data: existing } = await supabase
                .from('interview_templates')
                .select('id')
                .eq('organization_id', activeOrganization.id)
                .eq('name', templateName)
                .maybeSingle();

            if (existing) {
                throw new Error("A template with this name already exists.");
            }

            // Generate UUID for new template
            const newTemplateId = crypto.randomUUID();
            console.log("Saving new template with UUID:", newTemplateId);

            const { data: templateData, error: insertError } = await supabase
            .from('interview_templates')
            .insert({
                id: newTemplateId,
                name: templateName,
                description: templateDescription,
                introduction_text: introductionText,
                organization_id: activeOrganization.id,
                created_by: user.id,
                status: submitType === 'active' ? 'active' : 'draft',
            })
            .select()
            .single();

            if (insertError) throw insertError;
            templateId = templateData.id;
            setSavedTemplateId(templateId);
        }

        // 2. Upsert Questions
        const questionsToInsert = [];
        const questionsToUpdate = [];

        questions.forEach((q, index) => {
            const payload = {
                template_id: templateId,
                question_text: q.question_text,
                clarification_text: q.clarification_text,
                question_video_url: q.question_video_url,
                clarification_video_url: q.clarification_video_url,
                persona_id: q.persona_id,
                order: index,
            };

            if (String(q.id).startsWith('temp-')) {
                // Generate ID for new question
                const newQId = crypto.randomUUID();
                questionsToInsert.push({ ...payload, id: newQId });
            } else {
                questionsToUpdate.push({ ...payload, id: q.id });
            }
        });

        if (questionsToInsert.length > 0) {
            const { error: insertQError } = await supabase.from('template_questions').insert(questionsToInsert);
            if (insertQError) throw insertQError;
        }

        if (questionsToUpdate.length > 0) {
            const { error: updateQError } = await supabase.from('template_questions').upsert(questionsToUpdate);
            if (updateQError) throw updateQError;
        }

        toast({ title: submitType === 'active' ? 'Template Activated!' : 'Draft Saved!', description: `The template "${templateName}" has been saved.` });
        navigate(isDemo ? '/demo/templates' : '/templates');

    } catch (error) {
        console.error("Save error:", error);
        let msg = error.message;
        if (error.code === '23505') msg = "A template with this name already exists in your organization.";
        toast({ title: 'Error Saving Template', description: msg, variant: 'destructive' });
    } finally {
        setIsSubmitting(false);
        setActiveSubmitType(null);
    }
  };

  return (
    <>
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto"
    >
        <div className="lg:col-span-2 space-y-8">
            <TemplateSelector templates={commonInterviewTemplates} onSelectTemplate={handleSelectTemplate} />
            <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center text-primary text-2xl">
                            <Sparkles className="w-6 h-6 mr-3" />
                            Create Interview Template
                        </CardTitle>
                        <CardDescription>Design a new template from scratch or customize a pre-built one.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <Label htmlFor="templateName">Template Name</Label>
                            <Input id="templateName" value={templateName} onChange={(e) => setTemplateName(e.target.value)} required className="mt-1" disabled={isSubmitting}/>
                        </div>
                        <div>
                            <Label htmlFor="templateDescription">Description</Label>
                            <Textarea id="templateDescription" value={templateDescription} onChange={(e) => setTemplateDescription(e.target.value)} className="mt-1" disabled={isSubmitting}/>
                        </div>
                         <div>
                            <Label htmlFor="introductionText">Introduction Text for Candidate</Label>
                            <Textarea id="introductionText" value={introductionText} onChange={(e) => setIntroductionText(e.target.value)} className="mt-1" disabled={isSubmitting}/>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Interview Questions</CardTitle>
                        <CardDescription>Add and configure the video questions for this template.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {questions.map((q, index) => (
                            <QuestionBuilder
                                key={q.id} question={q} index={index}
                                onQuestionChange={handleQuestionChange}
                                onRemoveQuestion={handleRemoveQuestion}
                                personas={personas}
                                disabled={isSubmitting || isUploading}
                                onRecordVideo={openRecorder}
                                onUploadVideo={handleUploadClick}
                                onGenerateVideo={openAiGenerator}
                            />
                        ))}
                        <Button type="button" variant="outline" onClick={handleAddQuestion} className="w-full border-dashed" disabled={isSubmitting || isUploading}>
                            <PlusCircle className="w-5 h-5 mr-2" /> Add Question
                        </Button>
                    </CardContent>
                </Card>

                <div className="flex justify-end space-x-4">
                    <Button type="button" variant="outline" onClick={() => navigate(isDemo ? '/demo/templates' : '/templates')} disabled={isSubmitting || isUploading}>Cancel</Button>
                    <Button type="button" variant="secondary" onClick={() => handleSave('draft')} disabled={isSubmitting || isUploading}>
                        {isSubmitting && activeSubmitType === 'draft' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
                        Save as Draft
                    </Button>
                    <Button type="button" onClick={() => handleSave('active')} disabled={isSubmitting || isUploading}>
                         {isSubmitting && activeSubmitType === 'active' ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <FileUp className="w-5 h-5 mr-2" />}
                        Save & Activate
                    </Button>
                </div>
            </form>
        </div>
        <aside className="lg:col-span-1 lg:sticky top-24 self-start space-y-6">
            <VideoGenerationQueue />
        </aside>
    </motion.div>
    <VideoRecorder
      open={isRecorderOpen}
      onOpenChange={setIsRecorderOpen}
      onUploadComplete={handleUploadComplete}
    />
    <AIGenerationDialog
        open={isAiDialogOpen}
        onOpenChange={setIsAiDialogOpen}
        onStartGeneration={handleStartGeneration}
        questionText={questions.find(q => q.id === activeQuestionId)?.question_text || ''}
        personaId={questions.find(q => q.id === activeQuestionId)?.persona_id}
        personas={personas}
        isGenerating={isSubmitting}
    />
    <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="video/*" disabled={isUploading}/>
    </>
  );
};

export default InterviewSetupPage;