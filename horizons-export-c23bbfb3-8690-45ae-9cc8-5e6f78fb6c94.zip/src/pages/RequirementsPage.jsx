
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import { FileText } from 'lucide-react';
// eslint-disable-next-line import/no-unresolved
import staticRequirements from '../../Requirements.md?raw';

const RequirementsPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700"
    >
      <header className="flex items-center justify-between mb-6 pb-4 border-b border-slate-700 flex-wrap gap-4">
        <div className="flex items-center">
          <FileText className="w-8 h-8 text-sky-400 mr-4" />
          <h1 className="text-2xl sm:text-3xl font-bold text-sky-400">Project Requirements</h1>
        </div>
      </header>

      <article className="prose prose-invert prose-sm sm:prose-base max-w-none 
        prose-headings:text-sky-400 prose-h1:text-2xl prose-h2:text-xl prose-h3:text-lg
        prose-a:text-sky-400 hover:prose-a:text-sky-300
        prose-strong:text-slate-100
        prose-blockquote:border-sky-500 prose-blockquote:text-slate-300
        prose-code:bg-slate-700 prose-code:text-sky-300 prose-code:p-1 prose-code:rounded-md
        prose-table:border-slate-600 prose-th:bg-slate-700 prose-th:text-slate-100 prose-tr:border-slate-600">
        <ReactMarkdown>{staticRequirements}</ReactMarkdown>
      </article>
    </motion.div>
  );
};

export default RequirementsPage;
