import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Building, PlusCircle } from 'lucide-react';
import CreateOrganizationDialog from '@/components/organization/CreateOrganizationDialog';

const HostEventPage = () => {
  const [isCreateOrgDialogOpen, setCreateOrgDialogOpen] = useState(false);

  return (
    <>
      <motion.div
        className="flex flex-col items-center justify-center text-center p-4"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-2xl w-full bg-card/80 backdrop-blur-sm p-8 sm:p-12 rounded-xl shadow-2xl border border-border/20">
          <motion.div
            className="p-4 bg-primary/10 rounded-full inline-block mb-6"
            animate={{
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0],
            }}
            transition={{
              duration: 1,
              ease: "easeInOut",
              repeat: Infinity,
              repeatDelay: 2,
            }}
          >
            <Building className="h-12 w-12 text-primary" />
          </motion.div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-primary tracking-tight">
            Create Your Organization
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            To start creating interviews and surveys, you first need an organization. This will be the central hub for all your team's activities.
          </p>
          <Button
            size="lg"
            className="mt-8 text-lg"
            onClick={() => setCreateOrgDialogOpen(true)}
          >
            <PlusCircle className="mr-2 h-5 w-5" />
            Create Organization
          </Button>
        </div>
      </motion.div>
      <CreateOrganizationDialog
        isOpen={isCreateOrgDialogOpen}
        setIsOpen={setCreateOrgDialogOpen}
      />
    </>
  );
};

export default HostEventPage;