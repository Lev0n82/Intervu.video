
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, AlertCircle } from 'lucide-react';
import ParticipantInterviewFlow from '@/components/interview/ParticipantInterviewFlow';
import { Button } from '@/components/ui/button';

const CandidateInterviewPage = () => {
    const { submissionId } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [interviewData, setInterviewData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    // In a real app, we would extract the token from headers or a secure initial fetch
    // For this implementation, we assume the user is accessing via a link that validates session or public access
    // But typically we need the submission_token to verify identity without login.
    // Assuming the URL might be /interview/:submissionId/:token? 
    // Or we fetch based on ID and check status. 
    // Let's assume we can fetch by ID for now, but RLS policies usually require a token in header.
    // *Constraint Check*: The prompt implies this is the participant view.
    
    // NOTE: The previous implementation used submission_token from local storage or params?
    // Let's check `src/pages/InterviewStartPage.jsx` logic if it exists (not visible but usually how it works).
    // Let's assume for this page, we fetch the data. 
    // Ideally, we need the token to be able to "Write" to the submission table due to RLS.
    // I will extract token from localStorage if it was set during the 'Start' phase or welcome page.
    
    const submissionToken = localStorage.getItem('interview_token');

    useEffect(() => {
        const fetchInterviewDetails = async () => {
            if (!submissionId) return;
            setLoading(true);
            try {
                // We need to use the token to authorize the request if RLS is strict
                const { data, error } = await supabase
                    .from('interview_submissions')
                    .select(`
                        *,
                        interviews (
                            id,
                            status,
                            template_id,
                            interview_templates (
                                name,
                                introduction_video_url,
                                template_questions (
                                    id,
                                    question_text,
                                    question_video_url,
                                    clarification_video_url,
                                    order,
                                    persona_id,
                                    personas ( name, role_title )
                                )
                            )
                        )
                    `)
                    .eq('id', submissionId)
                    .single();

                if (error) throw error;
                if (!data) throw new Error('Interview not found');

                // Sort questions
                if (data.interviews?.interview_templates?.template_questions) {
                    data.interviews.interview_templates.template_questions.sort((a, b) => a.order - b.order);
                }

                setInterviewData(data);
            } catch (err) {
                console.error("Fetch error:", err);
                setError(err.message);
                toast({ 
                    title: 'Error', 
                    description: 'Could not load interview details. Please try again or contact support.', 
                    variant: 'destructive' 
                });
            } finally {
                setLoading(false);
            }
        };

        fetchInterviewDetails();
    }, [submissionId, toast]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100">
                <div className="flex flex-col items-center gap-4">
                    <Loader2 className="h-10 w-10 animate-spin text-blue-500" />
                    <p className="text-slate-400">Preparing your interview environment...</p>
                </div>
            </div>
        );
    }

    if (error) {
         return (
            <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 p-4">
                <div className="max-w-md text-center space-y-4">
                    <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
                    <h2 className="text-xl font-semibold">Unable to Load Interview</h2>
                    <p className="text-slate-400">{error}</p>
                    <Button variant="outline" onClick={() => window.location.reload()}>Try Again</Button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500/30">
            {/* Header / Branding could go here */}
            <header className="border-b border-slate-900 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
                    <div className="font-bold text-xl tracking-tight flex items-center gap-2">
                        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                            <span className="text-white">IV</span>
                        </div>
                        <span className="hidden sm:inline">Intervu.video</span>
                    </div>
                    {interviewData?.interviews?.interview_templates?.name && (
                         <div className="text-sm text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
                            {interviewData.interviews.interview_templates.name}
                         </div>
                    )}
                </div>
            </header>

            <main>
                <ParticipantInterviewFlow 
                    interviewData={interviewData} 
                    submissionId={submissionId}
                    submissionToken={submissionToken}
                />
            </main>
        </div>
    );
};

export default CandidateInterviewPage;
