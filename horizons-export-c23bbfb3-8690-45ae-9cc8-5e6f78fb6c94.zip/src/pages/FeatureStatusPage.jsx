import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Loader, XCircle, Users, Settings, BarChart2, Layers, ShieldCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';

const featureDataConfig = [
  {
    categoryKey: 'roles',
    icon: <Users className="w-6 h-6" />,
    features: [
      { key: 'coreRoles', status: 'implemented' },
      { key: 'secondaryRoles', status: 'partial' },
      { key: 'systemRoles', status: 'planned' },
    ],
  },
  {
    categoryKey: 'modules',
    icon: <Layers className="w-6 h-6" />,
    features: [
      { key: 'asyncVideo', status: 'implemented' },
      { key: 'templateCreation', status: 'implemented' },
      { key: 'surveyModule', status: 'partial' },
      { key: 'aiQuestions', status: 'planned' },
      { key: 'aiScoring', status: 'planned' },
      { key: 'clarificationTools', status: 'partial' },
      { key: 'accessibility', status: 'planned' },
    ],
  },
  {
    categoryKey: 'analytics',
    icon: <BarChart2 className="w-6 h-6" />,
    features: [
      { key: 'aiInsights', status: 'planned' },
      { key: 'rubrics', status: 'planned' },
      { key: 'dashboards', status: 'planned' },
    ],
  },
  {
    categoryKey: 'team',
    icon: <Users className="w-6 h-6" />,
    features: [
      { key: 'invite', status: 'implemented' },
      { key: 'assignRoles', status: 'implemented' },
      { key: 'auditLog', status: 'planned' },
    ],
  },
  {
    categoryKey: 'security',
    icon: <ShieldCheck className="w-6 h-6" />,
    features: [
      { key: 'multiTenancy', status: 'implemented' },
      { key: 'e2ee', status: 'partial' },
      { key: 'gdpr', status: 'partial' },
      { key: 'storage', status: 'planned' },
    ],
  },
  {
    categoryKey: 'integration',
    icon: <Settings className="w-6 h-6" />,
    features: [
      { key: 'byom', status: 'planned' },
      { key: 'calendar', status: 'planned' },
      { key: 'notifications', status: 'partial' },
      { key: 'hris', status: 'planned' },
    ],
  },
];

const StatusIcon = ({ status }) => {
  switch (status) {
    case 'implemented':
      return <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />;
    case 'partial':
      return <Loader className="w-5 h-5 text-yellow-400 flex-shrink-0 animate-spin" />;
    case 'planned':
      return <XCircle className="w-5 h-5 text-red-400 flex-shrink-0" />;
    default:
      return null;
  }
};

const FeatureItem = ({ name, status, description }) => (
  <motion.div 
    className="flex items-start space-x-4 p-4 bg-card rounded-lg border border-border"
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true, amount: 0.5 }}
    transition={{ duration: 0.4 }}
  >
    <StatusIcon status={status} />
    <div>
      <h4 className="font-semibold text-card-foreground flex items-center">
        {name}
        <Badge variant={
          status === 'implemented' ? 'default' : status === 'partial' ? 'secondary' : 'destructive'
        } className={`ml-3 ${
          status === 'implemented' ? 'bg-green-500/20 text-green-300 border-green-500/50' : 
          status === 'partial' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50' : 
          'bg-red-500/20 text-red-300 border-red-500/50'
        }`}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </Badge>
      </h4>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
    </div>
  </motion.div>
);

const FeatureCategory = ({ category, icon, features }) => (
  <motion.section 
    className="mb-10"
    initial={{ opacity: 0 }}
    whileInView={{ opacity: 1 }}
    viewport={{ once: true, amount: 0.2 }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex items-center mb-4">
      <div className="p-2 bg-primary/20 rounded-md mr-3 border border-primary/30">{icon}</div>
      <h3 className="text-2xl font-bold text-primary">{category}</h3>
    </div>
    <div className="space-y-4">
      {features.map(feature => <FeatureItem key={feature.name} {...feature} />)}
    </div>
  </motion.section>
);

const FeatureStatusPage = () => {
  const { t } = useTranslation();

  const translatedFeatureData = featureDataConfig.map(category => ({
    category: t(`featureStatusPage.categories.${category.categoryKey}.title`),
    icon: category.icon,
    features: category.features.map(feature => ({
      name: t(`featureStatusPage.categories.${category.categoryKey}.features.${feature.key}.name`),
      status: feature.status,
      description: t(`featureStatusPage.categories.${category.categoryKey}.features.${feature.key}.description`),
    })),
  }));

  return (
    <>
      <Helmet>
        <title>{t('featureStatusPage.title')}</title>
        <meta name="description" content={t('featureStatusPage.description')} />
      </Helmet>
      <div className="max-w-5xl mx-auto p-2 sm:p-0">
        <motion.header 
          className="text-center mb-10 sm:mb-12 py-6 sm:py-8 bg-gradient-to-r from-primary to-cyan-500 rounded-xl shadow-2xl"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight mb-2 sm:mb-3 text-primary-foreground">{t('featureStatusPage.title')}</h1>
          <p className="text-md sm:text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto px-2">
            {t('featureStatusPage.description')}
          </p>
        </motion.header>

        <div className="p-4 sm:p-6 bg-background/70 rounded-xl shadow-xl border border-border">
          {translatedFeatureData.map(category => <FeatureCategory key={category.category} {...category} />)}
        </div>
      </div>
    </>
  );
};

export default FeatureStatusPage;