
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Users, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const JoinTeamPage = () => {
  const { invitationCode } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [invitation, setInvitation] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const validateInvitation = async () => {
      if (!invitationCode) {
        setError("Invalid link. Please check your URL.");
        setLoading(false);
        return;
      }

      try {
        // Query database for this code
        // We use a specific RPC or direct query if RLS allows public to check codes (usually dangerous)
        // Safer: RPC that returns limited info
        const { data, error } = await supabase
          .from('team_invitations')
          .select('*, organizations(name), roles(name)')
          .eq('invitation_code', invitationCode)
          .eq('status', 'pending')
          .single();

        if (error) throw error;
        
        if (!data) {
             throw new Error("Invitation not found or has expired.");
        }
        
        if (data.is_used) {
            throw new Error("This invitation has already been used.");
        }

        setInvitation(data);
      } catch (err) {
        console.error(err);
        setError(err.message || "Invitation not found");
      } finally {
        setLoading(false);
      }
    };

    validateInvitation();
  }, [invitationCode]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-red-600 flex items-center">
                <AlertCircle className="mr-2 h-5 w-5"/> Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">{error}</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => navigate('/')} variant="outline" className="w-full">Go Home</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 aurora-background">
      <Card className="max-w-md w-full shadow-lg border-t-4 border-t-primary">
        <CardHeader className="text-center pb-2">
            <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit mb-4">
                <Users className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">You've been invited!</CardTitle>
            <CardDescription>
                Join the team at <span className="font-semibold text-foreground">{invitation?.organizations?.name}</span>
            </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Role:</span>
                    <span className="font-medium">{invitation?.roles?.name}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Email:</span>
                    <span className="font-medium">{invitation?.email}</span>
                </div>
                 <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <span className="text-green-600 flex items-center"><CheckCircle2 className="w-3 h-3 mr-1"/> Valid</span>
                </div>
            </div>
            <p className="text-center text-sm text-gray-500">
                Create your account to accept this invitation and get started.
            </p>
        </CardContent>
        <CardFooter>
            <Button className="w-full text-lg py-6" onClick={() => navigate(`/join-team/${invitationCode}/signup`)}>
                Accept & Create Account
            </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default JoinTeamPage;
