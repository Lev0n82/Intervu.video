
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { validateParticipantToken } from '@/lib/ParticipantSessionValidator';
import Logo from '@/components/Logo';

const ParticipantInvitationFlow = () => {
    const { token } = useParams();
    const navigate = useNavigate();
    const [status, setStatus] = useState('validating'); // validating | redirecting

    useEffect(() => {
        let mounted = true;

        const validate = async () => {
            if (!token) {
                navigate('/participant/error/INVALID', { replace: true });
                return;
            }

            try {
                // Short delay to prevent flicker if generic
                await new Promise(r => setTimeout(r, 600));

                const result = await validateParticipantToken(token);

                if (!mounted) return;

                if (!result.valid) {
                    navigate(`/participant/error/${result.errorCode}`, { replace: true });
                    return;
                }

                setStatus('redirecting');
                
                // Route based on type
                if (result.type === 'interview') {
                    navigate(`/interview/device-check/${token}`, { replace: true });
                } else if (result.type === 'survey') {
                    navigate(`/survey/complete/${token}`, { replace: true });
                } else {
                    navigate('/participant/error/SYSTEM_ERROR', { replace: true });
                }

            } catch (error) {
                console.error("Flow error:", error);
                if (mounted) navigate('/participant/error/SYSTEM_ERROR', { replace: true });
            }
        };

        validate();

        return () => { mounted = false; };
    }, [token, navigate]);

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50">
            <div className="mb-8">
                <Logo />
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center max-w-sm w-full text-center">
                <Loader2 className="w-10 h-10 text-primary animate-spin mb-4" />
                <h2 className="text-lg font-semibold text-slate-800">
                    {status === 'validating' ? 'Verifying invitation...' : 'Redirecting...'}
                </h2>
                <p className="text-slate-500 text-sm mt-2">
                    Please wait while we set up your secure session.
                </p>
            </div>
        </div>
    );
};

export default ParticipantInvitationFlow;
