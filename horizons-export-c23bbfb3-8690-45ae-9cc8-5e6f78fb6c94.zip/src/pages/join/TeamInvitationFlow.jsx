
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/use-toast';
import PhoneNumberStep from '@/components/auth/PhoneNumberStep';
import PasswordStep from '@/components/auth/PasswordStep';
import { getDeviceFingerprint } from '@/lib/deviceFingerprint';
import { rememberMeManager } from '@/lib/RememberMeManager';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const TeamInvitationFlow = ({ invitationData }) => {
  const { token } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { session } = useAuth();
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({ phone: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // If user is already authenticated and viewing this, try to link automatically if possible
    // logic handled in handleFinalSubmit typically.
    if (session && invitationData) {
       // If they are logged in, we skip password/phone collection if they want
       // But task says "Auto-sign in" implies we are handling new users or unauth users primarily.
       // We'll proceed with standard flow if unauth.
    }
  }, [session, invitationData]);

  const handlePhoneSubmit = (phone) => {
    setFormData(prev => ({ ...prev, phone }));
    setStep(2);
  };

  const handleFinalSubmit = async (password, rememberMe) => {
    setLoading(true);
    setError(null);
    
    try {
        const fingerprint = await getDeviceFingerprint();

        // 1. Sign Up User via Supabase Auth (client side)
        const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
            email: invitationData.email,
            password: password,
            options: {
                data: {
                    phone_number: formData.phone,
                    full_name: invitationData.email.split('@')[0]
                }
            }
        });

        if (signUpError) {
             if (signUpError.message.includes('already registered')) {
                 // Try signing in instead? Or warn user.
                 throw new Error("This email is already registered. Please login to your existing account to accept the invite.");
             }
             throw signUpError;
        }

        // 2. Call RPC to Link Team and finalize
        if (signUpData.user) {
             const { data: rpcData, error: rpcError } = await supabase.rpc('validate_and_accept_invitation', {
                p_invitation_code: token, // passing token from URL param
                p_phone_number: formData.phone,
                p_password: password, 
                p_device_fingerprint: fingerprint,
                p_remember_me: rememberMe
            });
            
            if (rpcError) throw rpcError;
            if (!rpcData.success) throw new Error(rpcData.message);

            // 3. Handle "Remember Me"
            if (rememberMe && rpcData.session_token) {
                await rememberMeManager.storeSession(rpcData.session_token, fingerprint);
            }

            toast({ title: "Success!", description: "You have joined the team." });
            navigate('/join-team/success');
        } else {
             toast({ title: "Check your email", description: "Please confirm your email address to complete joining the team." });
        }

    } catch (err) {
        console.error("Signup flow error:", err);
        setError(err.message);
        toast({ variant: "destructive", title: "Registration Failed", description: err.message });
    } finally {
        setLoading(false);
    }
  };

  if (!invitationData) return null; // Should be handled by validator

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md mb-8 text-center">
         <h1 className="text-xl font-bold text-gray-800 mb-2">
             Join {invitationData.organizations.name}
         </h1>
         <p className="text-gray-600 mb-4">Complete your account setup to proceed.</p>
         <Progress value={step === 1 ? 50 : 100} className="h-2" />
         <p className="text-xs text-muted-foreground mt-2">Step {step} of 2</p>
      </div>

      <Card className="max-w-md w-full p-6 shadow-lg">
         {step === 1 && (
             <PhoneNumberStep 
                onNext={handlePhoneSubmit} 
                initialPhone={formData.phone}
             />
         )}
         {step === 2 && (
             <PasswordStep 
                onBack={() => setStep(1)} 
                onSubmit={handleFinalSubmit} 
                isLoading={loading}
                error={error}
             />
         )}
      </Card>
    </div>
  );
};

export default TeamInvitationFlow;
