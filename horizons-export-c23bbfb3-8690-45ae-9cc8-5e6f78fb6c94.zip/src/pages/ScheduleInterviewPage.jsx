
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Loader2, Send, Mail, User, CheckCircle2 } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import CopyableCode from '@/components/CopyableCode';

const ScheduleInterviewPage = () => {
    const { templateId } = useParams();
    const { activeOrganization } = useAuth();
    const { isDemo, promptSave } = useDemo();
    const { toast } = useToast();
    const navigate = useNavigate();

    const [template, setTemplate] = useState(null);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [candidateName, setCandidateName] = useState('');
    const [candidateEmail, setCandidateEmail] = useState('');
    const [interviewType, setInterviewType] = useState('one-way');
    const [isPreviewOpen, setIsPreviewOpen] = useState(false);
    const [emailSubject, setEmailSubject] = useState('');
    const [emailBody, setEmailBody] = useState('');
    const [submissionDetails, setSubmissionDetails] = useState(null);
    const [successView, setSuccessView] = useState(false);

    useEffect(() => {
        const fetchTemplate = async () => {
            if (isDemo) {
                setTemplate({ id: 'demo-template-id', name: 'Demo Frontend Role' });
                setLoading(false);
                return;
            }
            if (!templateId) return;
            setLoading(true);
            const { data, error } = await supabase
                .from('interview_templates')
                .select('*')
                .eq('id', templateId)
                .single();

            if (error) {
                toast({ title: 'Error fetching template', description: error.message, variant: 'destructive' });
                navigate('/templates');
            } else {
                setTemplate(data);
                setEmailSubject(`Invitation to Interview for ${data.name}`);
                setEmailBody(`Hello [Candidate Name],\n\nYou have been invited to complete a one-way video interview for the ${data.name} position.\n\nPlease use the link below to begin.\n\n[Invitation Link]\n\nBest regards,\nThe Hiring Team`);
            }
            setLoading(false);
        };
        fetchTemplate();
    }, [templateId, toast, navigate, isDemo]);
    
    const handleScheduleAndInvite = async (e) => {
        e.preventDefault();
        if (promptSave()) return;
        if (!candidateName || !candidateEmail) {
            toast({ title: 'Candidate details required', variant: 'destructive' });
            return;
        }

        setSubmitting(true);
        try {
            const { data, error } = await supabase.rpc('schedule_interview_and_generate_submission', {
                org_id_input: activeOrganization.id,
                template_id_input: templateId,
                interview_title_input: template.name,
                interview_type_input: interviewType,
                candidate_name_input: candidateName,
                candidate_email_input: candidateEmail
            });

            if (error || !data.success) throw new Error(error?.message || data.message);
            
            setSubmissionDetails({ 
                submissionId: data.submission_id,
                code: data.interview_code
            });
            setIsPreviewOpen(true);

        } catch (error) {
            toast({ title: 'Failed to schedule interview', description: error.message, variant: 'destructive' });
        } finally {
            setSubmitting(false);
        }
    };
    
    const handleSendInvitation = async () => {
        if (!submissionDetails?.submissionId) return;
        setSubmitting(true);
        try {
            const { data, error } = await supabase.rpc('send_interview_invitation', {
                submission_id_input: submissionDetails.submissionId,
                email_subject: emailSubject,
                email_body: emailBody,
                site_url: window.location.origin
            });
            
            if (error || !data.success) throw new Error(error?.message || data.message);

            toast({ title: 'Invitation Sent!', description: `An invitation has been emailed to ${candidateEmail}.` });
            setIsPreviewOpen(false);
            setSuccessView(true);

        } catch (error) {
            toast({ title: 'Failed to send invitation', description: error.message, variant: 'destructive' });
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 animate-spin" /></div>;
    }

    if (successView) {
        return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl mx-auto text-center space-y-8 pt-10">
                <div className="flex justify-center">
                    <CheckCircle2 className="w-20 h-20 text-green-500" />
                </div>
                <h2 className="text-3xl font-bold">Interview Scheduled!</h2>
                <p className="text-muted-foreground">
                    We've sent an email to <strong>{candidateEmail}</strong>. You can also share the code or link below manually.
                </p>
                
                <Card className="max-w-md mx-auto text-left">
                    <CardHeader>
                        <CardTitle>Share Options</CardTitle>
                        <CardDescription>Share this code via messaging apps.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <CopyableCode 
                            code={submissionDetails?.code} 
                            label="Interview Code" 
                            description="Candidate can enter this code on the home page."
                        />
                        {/* Assuming the interview link structure is standard */}
                        <CopyableCode 
                            code={`${window.location.origin}/interview/start/${submissionDetails?.submissionId}`} 
                            label="Direct Link" 
                            description="Direct access link for the candidate."
                        />
                    </CardContent>
                    <CardFooter className="flex justify-between">
                         <Button variant="outline" onClick={() => navigate('/interviews')}>Back to Dashboard</Button>
                         <Button onClick={() => setSuccessView(false)}>Schedule Another</Button>
                    </CardFooter>
                </Card>
            </motion.div>
        );
    }

    return (
        <>
            <Helmet>
                <title>Schedule Interview - {template?.name || 'Loading...'}</title>
            </Helmet>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-2xl mx-auto"
            >
                <form onSubmit={handleScheduleAndInvite}>
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-2xl text-primary">Schedule Interview</CardTitle>
                            <CardDescription>Invite a candidate to complete an interview using the "{template?.name}" template.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="candidate-name">Candidate Name</Label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                                    <Input id="candidate-name" value={candidateName} onChange={e => setCandidateName(e.target.value)} required placeholder="Jane Doe" className="pl-10" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="candidate-email">Candidate Email</Label>
                                 <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                                    <Input id="candidate-email" type="email" value={candidateEmail} onChange={e => setCandidateEmail(e.target.value)} required placeholder="jane.doe@example.com" className="pl-10" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="interview-type">Interview Type</Label>
                                <Select value={interviewType} onValueChange={setInterviewType}>
                                    <SelectTrigger id="interview-type">
                                        <SelectValue placeholder="Select interview type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="one-way">One-Way Video Interview</SelectItem>
                                        <SelectItem value="two-way" disabled>Two-Way (Live) Interview (coming soon)</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </CardContent>
                        <CardFooter>
                            <Button type="submit" disabled={submitting || !template} className="w-full">
                                {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                                Preview & Send Invitation
                            </Button>
                        </CardFooter>
                    </Card>
                </form>
            </motion.div>
            
            <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
                <DialogContent className="sm:max-w-[625px]">
                    <DialogHeader>
                        <DialogTitle>Preview Invitation Email</DialogTitle>
                        <DialogDescription>Review and edit the invitation before sending it to {candidateEmail}.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="email-subject">Subject</Label>
                            <Input id="email-subject" value={emailSubject} onChange={e => setEmailSubject(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="email-body">Body</Label>
                            <Textarea id="email-body" value={emailBody} onChange={e => setEmailBody(e.target.value)} className="min-h-[200px]" />
                            <p className="text-xs text-muted-foreground">Use placeholders like [Candidate Name] and [Invitation Link].</p>
                        </div>
                        
                        {/* Show generated code here as well, so recruiter knows it exists */}
                         <div className="pt-4 border-t">
                            <Label className="text-xs font-semibold uppercase text-muted-foreground mb-2 block">Generated Access Code</Label>
                            <div className="font-mono bg-muted p-2 rounded text-sm text-center border">
                                {submissionDetails?.code}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">This code will be saved even if email fails.</p>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsPreviewOpen(false)} disabled={submitting}>Cancel</Button>
                        <Button onClick={handleSendInvitation} disabled={submitting}>
                            {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                            Send Invitation
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default ScheduleInterviewPage;
