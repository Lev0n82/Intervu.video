import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const ViewSubmissionPage = () => {
  const { submissionId } = useParams();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [submission, setSubmission] = useState(null);
  const [answers, setAnswers] = useState([]);

  useEffect(() => {
    const fetchSubmission = async () => {
      setLoading(true);

      const { data: subData, error: subError } = await supabase
        .from('interview_submissions')
        .select('*, interviews(*, interview_templates(*))')
        .eq('id', submissionId)
        .single();
      
      if (subError) {
        toast({ variant: 'destructive', title: 'Error fetching submission', description: subError.message });
        setLoading(false);
        return;
      }
      setSubmission(subData);

      const { data: ansData, error: ansError } = await supabase
        .from('submission_answers')
        .select('*, template_questions(*, questions(*))')
        .eq('submission_id', submissionId)
        .order('created_at', { ascending: true });
        
      if (ansError) {
        toast({ variant: 'destructive', title: 'Error fetching answers', description: ansError.message });
      } else {
        setAnswers(ansData);
      }

      setLoading(false);
    };
    fetchSubmission();
  }, [submissionId, toast]);

  if (loading) return <p className="p-4">Loading submission...</p>;
  if (!submission) return <p className="p-4">Submission not found.</p>;

  return (
    <div className="container mx-auto p-4">
      <Card className="mb-6">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-3xl">Interview Submission</CardTitle>
              <CardDescription>
                For: {submission.interviews.interview_templates.name}
              </CardDescription>
            </div>
            <Badge>{submission.status}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p><strong>Candidate:</strong> {submission.candidate_name || submission.candidate_email}</p>
          <p><strong>Submitted At:</strong> {new Date(submission.completed_at || submission.created_at).toLocaleString()}</p>
        </CardContent>
      </Card>
      
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Candidate Responses</h2>
        {answers.length > 0 ? (
            answers.map((answer, index) => (
              <Card key={answer.id}>
                <CardHeader>
                  <CardTitle>Question {index + 1}: {answer.template_questions.questions.question_text}</CardTitle>
                </CardHeader>
                <CardContent>
                  {answer.response_video_url ? (
                    <video controls src={answer.response_video_url} className="w-full max-w-lg rounded-md" />
                  ) : (
                    <p className="text-slate-500">No video response was recorded for this question.</p>
                  )}
                </CardContent>
              </Card>
            ))
        ) : (
          <p>No answers have been submitted for this interview yet.</p>
        )}
      </div>
    </div>
  );
};

export default ViewSubmissionPage;