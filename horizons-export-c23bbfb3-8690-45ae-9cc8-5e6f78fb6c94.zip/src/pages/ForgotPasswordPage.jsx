import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Mail, KeyRound, ArrowLeft, Loader2 } from 'lucide-react';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.state?.email) {
      setEmail(location.state.email);
    }
  }, [location.state]);

  const handlePasswordResetRequest = async (e) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: 'Email Required',
        description: 'Please enter your email address to request a password reset.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/password-reset`,
      });

      if (error) {
        console.error('Password reset request error:', error);
        throw error;
      }
      
      toast({
        title: 'Request Submitted',
        description: 'If an account exists for this email, we will send you a password reset link.',
        duration: 7000,
      });
      setEmail(''); 
    } catch (error) {
      console.error('Unexpected error during password reset request:', error);
      toast({
        title: 'Error',
        description: error.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const pageVariants = {
    initial: { opacity: 0, scale: 0.95, y: 20 },
    in: { opacity: 1, scale: 1, y: 0 },
    out: { opacity: 0, scale: 0.95, y: -20 },
  };

  const pageTransition = {
    type: "tween",
    ease: "anticipate",
    duration: 0.5,
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-transparent p-4">
      <motion.div
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
        className="w-full max-w-md"
      >
        <div className="bg-card/80 backdrop-blur-sm p-6 sm:p-8 rounded-xl shadow-2xl border border-border/20">
          <div className="text-center mb-8">
            <div className="inline-block p-3 bg-primary rounded-full shadow-lg mb-4">
              <KeyRound className="w-10 h-10 text-primary-foreground" />
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-foreground tracking-tight">
              Forgot Your Password?
            </h1>
            <p className="text-muted-foreground mt-2 text-sm sm:text-base">
              No worries! Enter your email below and we'll help you reset it.
            </p>
          </div>

          <form onSubmit={handlePasswordResetRequest} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="reset-email" className="text-foreground/80">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="reset-email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-10"
                  aria-label="Email address for password reset"
                  disabled={isLoading}
                />
              </div>
            </div>
            <Button type="submit" className="w-full py-3 text-base" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {isLoading ? 'Sending...' : 'Request Password Reset'}
            </Button>
          </form>
          <div className="mt-6 text-center">
            <Link
              to="/auth"
              className="text-primary hover:text-primary/80 text-sm inline-flex items-center"
              aria-label="Back to Login"
            >
              <ArrowLeft className="w-4 h-4 mr-1.5" aria-hidden="true" /> Back to Login
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ForgotPasswordPage;