
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PlusCircle, Video, FileText, Loader2, MoreHorizontal, Trash2, Edit, BarChart2, Eye, Share2, Copy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDemo } from '@/contexts/DemoContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Badge } from '@/components/ui/badge';
import SurveyDistributionDialog from '@/components/SurveyDistributionDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu"

const demoSurveys = [
    { id: 'demo-s1', title: 'Q2 Candidate Experience Feedback', created_at: new Date().toISOString(), survey_type: 'text', status: 'active' },
    { id: 'demo-s2', title: 'New Feature Video Poll', created_at: new Date(Date.now() - 86400000 * 2).toISOString(), survey_type: 'video', status: 'draft' },
    { id: 'demo-s3', title: 'Onboarding Process Review', created_at: new Date(Date.now() - 86400000 * 5).toISOString(), survey_type: 'text', status: 'completed' },
];

const SurveyManagementPage = () => {
    const navigate = useNavigate();
    const { userProfile, activeOrganization } = useAuth();
    const { isDemo, promptSave } = useDemo();
    const { toast } = useToast();
    const canCreate = isDemo || (userProfile && ['Admin', 'Manager'].includes(userProfile.team_memberships?.find(m => m.organization_id === activeOrganization?.id)?.role.name));

    const [surveys, setSurveys] = useState([]);
    const [loading, setLoading] = useState(true);
    const [distributionSurvey, setDistributionSurvey] = useState(null);

    useEffect(() => {
        const fetchSurveys = async () => {
            if (isDemo) {
                setSurveys(demoSurveys);
                setLoading(false);
                return;
            }
            if (!activeOrganization?.id) {
                setLoading(false);
                return;
            };

            try {
                setLoading(true);
                const { data, error } = await supabase
                    .from('surveys')
                    .select('*')
                    .eq('organization_id', activeOrganization.id)
                    .order('created_at', { ascending: false });

                if (error) throw error;
                setSurveys(data);
            } catch (error) {
                toast({
                    title: "Error fetching surveys",
                    description: error.message,
                    variant: "destructive",
                });
            } finally {
                setLoading(false);
            }
        };
        fetchSurveys();
    }, [activeOrganization, toast, isDemo]);
    
    const handleDeleteSurvey = async (surveyId, surveyTitle) => {
        if (promptSave()) return;
        if (!window.confirm(`Are you sure you want to delete the survey "${surveyTitle}"? This action cannot be undone.`)) return;

        try {
            const { error } = await supabase.from('surveys').delete().eq('id', surveyId);
            if (error) throw error;
            setSurveys(surveys.filter(s => s.id !== surveyId));
            toast({ title: "Survey Deleted", description: `"${surveyTitle}" has been permanently deleted.`});
        } catch (error) {
            toast({ title: "Error deleting survey", description: error.message, variant: "destructive" });
        }
    };
    
    const handleEditSurvey = (survey) => {
        if (promptSave()) return;
        const path = survey.survey_type === 'video' ? `/surveys/video/edit/${survey.id}` : `/surveys/edit/${survey.id}`;
        navigate(isDemo ? `/demo${path}` : path);
    }
    
    const handleViewResults = (surveyId) => {
        if (promptSave()) return;
        const path = `/surveys/results/${surveyId}`;
        navigate(isDemo ? `/demo${path}` : path);
    }
    
    const handlePreview = (surveyId) => {
        if(promptSave()) return;
        const path = `/s/${surveyId}`; 
        window.open(isDemo ? `/demo${path}` : path, '_blank');
    }

    const handleCopyLink = (surveyId) => {
        const link = `${window.location.origin}/s/${surveyId}`;
        navigator.clipboard.writeText(link);
        toast({ title: "Link Copied", description: "Public survey link copied to clipboard." });
    }

    const handleDistribute = (survey) => {
        if (isDemo) {
             toast({ title: "Demo Mode", description: "Distribution features are disabled in demo mode." });
             return;
        }
        if (survey.status !== 'active') {
             toast({ title: "Survey Not Active", description: "You must activate the survey before distributing it.", variant: "secondary" });
             return;
        }
        setDistributionSurvey(survey);
    };

    const getCreatePath = (path) => isDemo ? `/demo${path}` : path;

    const SurveyList = () => (
        <div className="space-y-4">
            {surveys.map((survey) => (
                <Card key={survey.id} className="transition-all hover:shadow-md">
                    <CardContent className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                            {survey.survey_type === 'video' ? 
                                <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                                    <Video className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                                </div> : 
                                <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                                    <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                                </div>
                            }
                            <div>
                                <p className="font-semibold text-card-foreground text-lg">{survey.title}</p>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                                    <span>Created {new Date(survey.created_at).toLocaleDateString()}</span>
                                    <span>•</span>
                                    <Badge variant={survey.status === 'active' ? 'success' : 'secondary'} className="capitalize text-xs">
                                        {survey.status}
                                    </Badge>
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 self-end sm:self-auto">
                            {survey.status === 'active' && (
                                <Button variant="outline" size="sm" onClick={() => handleDistribute(survey)} className="hidden sm:flex">
                                    <Share2 className="w-4 h-4 mr-2" />
                                    Share
                                </Button>
                            )}
                             <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                        <span className="sr-only">Open menu for {survey.title}</span>
                                        <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => handleViewResults(survey.id)}>
                                        <BarChart2 className="mr-2 h-4 w-4" />
                                        View Results
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handlePreview(survey.id)}>
                                        <Eye className="mr-2 h-4 w-4" />
                                        Preview
                                    </DropdownMenuItem>
                                    {survey.status === 'active' && (
                                        <>
                                            <DropdownMenuItem onClick={() => handleCopyLink(survey.id)}>
                                                <Copy className="mr-2 h-4 w-4" />
                                                Copy Public Link
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => handleDistribute(survey)}>
                                                <Share2 className="mr-2 h-4 w-4" />
                                                Share / Invite
                                            </DropdownMenuItem>
                                        </>
                                    )}
                                    <DropdownMenuItem onClick={() => handleEditSurvey(survey)}>
                                        <Edit className="mr-2 h-4 w-4" />
                                        Edit Survey
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                     <DropdownMenuItem onClick={() => handleDeleteSurvey(survey.id, survey.title)} className="text-destructive focus:text-destructive">
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Delete
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );

    const EmptyState = () => (
        <div className="text-center py-20 bg-secondary/30 rounded-lg border border-dashed border-border">
            <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">You haven't created any surveys yet.</p>
            {canCreate && (
                <div className="mt-6 flex justify-center gap-4">
                    <Button onClick={() => navigate(getCreatePath('/surveys/video/new'))}>
                        <Video className="w-5 h-5 mr-2" />
                        Create Your First Video Survey
                    </Button>
                    <Button variant="outline" onClick={() => navigate(getCreatePath('/surveys/new'))}>
                        <FileText className="w-5 h-5 mr-2" />
                        Create a Text Survey
                    </Button>
                </div>
            )}
        </div>
    );

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 sm:p-6"
        >
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 pb-4 border-b border-border">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-primary">Survey Management</h1>
                    <p className="text-muted-foreground mt-1">Manage, create, and view all your surveys.</p>
                </div>
                {canCreate && (
                    <div className="flex items-center gap-2 mt-4 sm:mt-0">
                         <Button onClick={() => navigate(getCreatePath('/surveys/video/new'))}>
                            <Video className="w-5 h-5 mr-2" />
                            Create Video Survey
                        </Button>
                        <Button onClick={() => navigate(getCreatePath('/surveys/new'))} variant="outline">
                            <PlusCircle className="w-5 h-5 mr-2" />
                            Create Text Survey
                        </Button>
                    </div>
                )}
            </header>

            <section aria-labelledby="existing-surveys-title">
                {loading ? (
                    <div className="flex justify-center items-center py-20">
                        <Loader2 className="w-8 h-8 text-primary animate-spin" />
                    </div>
                ) : surveys.length > 0 ? (
                    <SurveyList />
                ) : (
                    <EmptyState />
                )}
            </section>
            
            <SurveyDistributionDialog 
                open={!!distributionSurvey} 
                onOpenChange={(open) => !open && setDistributionSurvey(null)} 
                survey={distributionSurvey}
            />
        </motion.div>
    );
};

export default SurveyManagementPage;
