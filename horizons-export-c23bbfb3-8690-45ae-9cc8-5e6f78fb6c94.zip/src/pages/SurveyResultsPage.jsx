import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Loader2, AlertTriangle, FileText, Star, Users, CheckSquare } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#00C49F', '#FFBB28', '#FF8042'];

const SurveyResultsPage = () => {
    const { surveyId } = useParams();
    const { toast } = useToast();
    const navigate = useNavigate();
    const { activeOrganization } = useAuth();
    const [loading, setLoading] = useState(true);
    const [survey, setSurvey] = useState(null);
    const [submissions, setSubmissions] = useState([]);
    const [answers, setAnswers] = useState([]);
    const [questions, setQuestions] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            if (!surveyId || !activeOrganization) return;
            setLoading(true);

            try {
                // Fetch survey, questions, submissions, and answers
                const { data: surveyData, error: surveyError } = await supabase.from('surveys').select('*').eq('id', surveyId).single();
                if (surveyError) throw surveyError;
                setSurvey(surveyData);
                
                const { data: qData, error: qError } = await supabase.from('survey_questions').select('*').eq('survey_id', surveyId).order('sequence_order');
                if (qError) throw qError;
                setQuestions(qData);
                
                const { data: subData, error: subError } = await supabase.from('survey_submissions').select('*').eq('survey_id', surveyId);
                if (subError) throw subError;
                setSubmissions(subData);
                
                if (subData.length > 0) {
                    const subIds = subData.map(s => s.id);
                    const { data: ansData, error: ansError } = await supabase.from('survey_answers').select('*').in('submission_id', subIds);
                    if (ansError) throw ansError;
                    setAnswers(ansData);
                }

            } catch (error) {
                toast({ variant: 'destructive', title: 'Error fetching results', description: error.message });
                navigate('/surveys');
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [surveyId, activeOrganization, navigate, toast]);

    const aggregatedResults = useMemo(() => {
        if (!questions.length || !answers.length) return [];
        return questions.map(q => {
            const questionAnswers = answers.filter(a => a.question_id === q.id);
            let data = [];
            switch (q.question_type) {
                case 'multiple-choice':
                case 'likert':
                case 'yes-no':
                    data = q.options.options.map(opt => ({
                        name: opt,
                        count: questionAnswers.filter(a => a.answer.answer === opt).length
                    }));
                    break;
                case 'rating':
                    data = [1, 2, 3, 4, 5].map(rating => ({
                        name: `${rating} Star${rating > 1 ? 's' : ''}`,
                        count: questionAnswers.filter(a => a.answer.answer === rating).length
                    }));
                    break;
                default:
                    break;
            }
            return {
                id: q.id,
                text: q.question_text,
                type: q.question_type,
                totalResponses: questionAnswers.length,
                data
            };
        });
    }, [questions, answers]);
    
    const textAnswers = useMemo(() => {
        if (!questions.length || !answers.length) return [];
        const textQuestions = questions.filter(q => q.question_type === 'text');
        return textQuestions.map(q => ({
            id: q.id,
            text: q.question_text,
            responses: answers.filter(a => a.question_id === q.id).map(a => ({
                id: a.id,
                text: a.answer.answer
            }))
        }));
    }, [questions, answers]);


    if (loading) return <div className="flex items-center justify-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
    if (!survey) return <div className="p-4 text-center"><AlertTriangle className="mx-auto h-12 w-12 text-destructive" /><h1 className="mt-4 text-xl">Survey not found.</h1></div>;

    return (
        <div className="p-4 sm:p-6 max-w-7xl mx-auto">
            <Card className="mb-6">
                <CardHeader>
                    <CardTitle className="text-3xl font-bold text-primary">{survey.title}</CardTitle>
                    <CardDescription>{survey.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex items-center gap-4">
                    <div className="flex items-center text-muted-foreground"><Users className="w-5 h-5 mr-2" /> {submissions.length} Total Submissions</div>
                    <Badge variant={survey.status === 'active' ? 'success' : 'secondary'} className="capitalize">{survey.status}</Badge>
                </CardContent>
            </Card>

            <Tabs defaultValue="summary">
                <TabsList className="mb-4">
                    <TabsTrigger value="summary">Visual Summary</TabsTrigger>
                    <TabsTrigger value="text-responses">Text Responses</TabsTrigger>
                </TabsList>
                <TabsContent value="summary">
                    {aggregatedResults.length === 0 && (
                        <Card><CardContent className="p-10 text-center text-muted-foreground">No analyzable responses for this survey yet.</CardContent></Card>
                    )}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {aggregatedResults.map(result => (
                            <Card key={result.id}>
                                <CardHeader>
                                    <CardTitle>{result.text}</CardTitle>
                                    <CardDescription>{result.totalResponses} responses</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    {result.data.length > 0 ? (
                                        <ResponsiveContainer width="100%" height={300}>
                                            {result.data.length > 3 ? (
                                                <BarChart data={result.data}>
                                                    <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                                                    <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                                                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }}/>
                                                    <Bar dataKey="count" fill="currentColor" radius={[4, 4, 0, 0]} className="fill-primary" />
                                                </BarChart>
                                            ) : (
                                                <PieChart>
                                                    <Pie data={result.data} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                                                        {result.data.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                                                    </Pie>
                                                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }}/>
                                                </PieChart>
                                            )}
                                        </ResponsiveContainer>
                                    ) : (
                                        <p className="text-muted-foreground">No data to display for this question.</p>
                                    )}
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </TabsContent>
                <TabsContent value="text-responses">
                    <div className="space-y-6">
                        {textAnswers.length === 0 && (
                             <Card><CardContent className="p-10 text-center text-muted-foreground">This survey has no open text questions.</CardContent></Card>
                        )}
                        {textAnswers.map(question => (
                            <Card key={question.id}>
                                <CardHeader>
                                    <CardTitle>{question.text}</CardTitle>
                                    <CardDescription>{question.responses.length} responses</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    {question.responses.length > 0 ? (
                                        <ul className="space-y-3">
                                            {question.responses.map(response => (
                                                <li key={response.id} className="p-3 bg-muted/50 border rounded-md text-sm">{response.text}</li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="text-muted-foreground">No responses for this question yet.</p>
                                    )}
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default SurveyResultsPage;