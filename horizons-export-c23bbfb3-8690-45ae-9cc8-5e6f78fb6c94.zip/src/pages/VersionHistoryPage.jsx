import React from 'react';
import { motion } from 'framer-motion';
import { GitCommit, Calendar, AlertTriangle, User, Bot } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';
import { versionHistory } from '@/lib/versionHistory';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const VersionHistoryPage = () => {
  const { t } = useTranslation();

  return (
    <>
      <Helmet>
        <title>{t('versionHistoryPage.title')}</title>
        <meta name="description" content={t('versionHistoryPage.description')} />
      </Helmet>
      <div className="max-w-5xl mx-auto p-4 sm:p-8">
        <motion.header
          className="text-center mb-10"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-primary">
            {t('versionHistoryPage.title')}
          </h1>
          <p className="mt-3 text-lg text-muted-foreground max-w-3xl mx-auto">
            {t('versionHistoryPage.description')}
          </p>
        </motion.header>

        <div className="space-y-12">
          {versionHistory.sort((a, b) => new Date(b.date) - new Date(a.date)).map((version, index) => (
            <motion.div
              key={version.build}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden shadow-lg border-border/50 hover:border-primary/50 transition-all duration-300">
                <CardHeader className="bg-muted/50 p-4 sm:p-6 border-b">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                    <CardTitle className="text-2xl font-bold flex items-center">
                      <GitCommit className="w-6 h-6 mr-3 text-primary" />
                      Build {version.build}
                    </CardTitle>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{new Date(version.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 space-y-6">
                  
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg flex items-center text-slate-300">
                      <AlertTriangle className="w-5 h-5 mr-2 text-yellow-400" />
                      Problem Identified
                    </h3>
                    <p className="text-muted-foreground text-base leading-relaxed pl-7">{version.problem}</p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg flex items-center text-slate-300">
                      <User className="w-5 h-5 mr-2 text-sky-400" />
                      User Prompt
                    </h3>
                    <blockquote className="text-muted-foreground text-base leading-relaxed pl-7 border-l-4 border-sky-400/50 italic bg-slate-800/30 p-3 rounded-r-lg">
                      "{version.prompt}"
                    </blockquote>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg flex items-center text-slate-300">
                      <Bot className="w-5 h-5 mr-2 text-green-400" />
                      Analysis & Actions Performed
                    </h3>
                    <div className="text-muted-foreground text-base leading-relaxed pl-7">{version.analysisAndActions}</div>
                  </div>

                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
};

export default VersionHistoryPage;