import React from 'react';
import { motion } from 'framer-motion';
import { Database, ShieldCheck, Cpu, Network, Users, FileJson, Lock, Layers, Eye, Mic, GitBranch } from 'lucide-react';
import { Helmet } from 'react-helmet-async';

const SectionTitle = ({ title, icon }) => (
  <div className="flex items-center mb-4 sm:mb-6 mt-8 sm:mt-10">
    {React.cloneElement(icon, { size: 28, className: "text-primary mr-2 sm:mr-3 flex-shrink-0" })}
    <h2 className="text-2xl sm:text-3xl font-bold text-primary">{title}</h2>
  </div>
);

const SubSectionTitle = ({ title, icon }) => (
  <div className="flex items-center mb-3 sm:mb-4 mt-4 sm:mt-6">
     {React.cloneElement(icon, { size: 22, className: "text-primary/80 mr-2 flex-shrink-0" })}
    <h3 className="text-xl sm:text-2xl font-semibold text-foreground">{title}</h3>
  </div>
);

const ListItem = ({ children }) => (
  <li className="text-muted-foreground mb-1 ml-2 text-sm before:content-['▹'] before:mr-2 before:text-primary">{children}</li>
);

const TechnicalDetailsPage = () => {
  return (
    <>
      <Helmet>
        <title>AI Technology & Technical Architecture</title>
        <meta name="description" content="Explore the advanced AI technology behind Intervu.video, including our deception detection capabilities, technical architecture, and ethical AI framework." />
      </Helmet>
      <motion.div 
        className="container mx-auto max-w-5xl py-12 sm:py-16 px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <header className="text-center mb-8 sm:mb-10 pb-4 sm:pb-6 border-b border-border">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-primary mb-3">Advanced AI Technology: Deception Detection</h1>
          <p className="text-md sm:text-lg text-muted-foreground max-w-3xl mx-auto px-2">
            Our platform integrates cutting-edge behavioral analysis based on decades of scientific research to provide insights into candidate authenticity.
          </p>
        </header>

        <section>
          <SectionTitle title="The Science of Behavioral Analysis" icon={<Cpu />} />
          <p className="text-muted-foreground mb-4 sm:mb-6 text-base">
            Our technology is built on the pioneering work of Dr. Paul Ekman and other leading researchers in deception detection and emotional analysis. By combining facial expression analysis with voice pattern recognition, our system achieves significantly higher accuracy than single-modality approaches.
          </p>

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div className="bg-card p-6 rounded-lg border border-border">
              <SubSectionTitle title="Facial Expression Analysis" icon={<Eye />} />
              <ul className="space-y-2">
                <ListItem><strong>Micro-Expression Detection:</strong> Identifies brief, involuntary facial expressions that reveal genuine emotions.</ListItem>
                <ListItem><strong>Facial Action Coding System (FACS):</strong> Analyzes 44 distinct facial muscle movements to assess emotional authenticity.</ListItem>
                <ListItem><strong>Asymmetry & Timing Analysis:</strong> Detects unnatural facial asymmetries and evaluates the timing of emotional expressions to spot fabrications.</ListItem>
              </ul>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border">
              <SubSectionTitle title="Voice Pattern Analysis" icon={<Mic />} />
              <ul className="space-y-2">
                <ListItem><strong>Pitch Variation Tracking:</strong> Monitors fundamental frequency changes that occur during stress or deception.</ListItem>
                <ListItem><strong>Speech Pattern Analysis:</strong> Identifies increased pauses, hesitations, and speech errors associated with cognitive load.</ListItem>
                <ListItem><strong>Vocal Stress Indicators:</strong> Analyzes micro-tremors, jitter, and other acoustic markers of emotional stress.</ListItem>
              </ul>
            </div>
          </div>
        </section>

        <section>
          <SectionTitle title="Ethical Framework and Safeguards" icon={<ShieldCheck />} />
          <p className="text-muted-foreground mb-4 sm:mb-6 text-base">
            We recognize the significant responsibility that comes with behavioral analysis technology. Our implementation prioritizes transparency, fairness, and human oversight.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-card p-4 rounded-lg border border-border">
              <h4 className="font-semibold text-card-foreground mb-2">Candidate Transparency</h4>
              <p className="text-sm text-muted-foreground">All candidates are informed about behavioral analysis and must opt-in. We provide clear explanations of what the system detects.</p>
            </div>
            <div className="bg-card p-4 rounded-lg border border-border">
              <h4 className="font-semibold text-card-foreground mb-2">Human Oversight</h4>
              <p className="text-sm text-muted-foreground">AI analysis informs but never replaces human decision-making. All insights are reviewed by hiring managers who make the final call.</p>
            </div>
            <div className="bg-card p-4 rounded-lg border border-border">
              <h4 className="font-semibold text-card-foreground mb-2">Bias Mitigation</h4>
              <p className="text-sm text-muted-foreground">Our algorithms are regularly audited and calibrated on diverse datasets to ensure fairness across all demographic groups.</p>
            </div>
          </div>
        </section>

        <section>
          <SectionTitle title="System Architecture" icon={<Network />} />
          <p className="text-muted-foreground mb-4 sm:mb-6 text-base">
            Our platform is built on a modular architecture designed for scalability and resilience. Core services communicate via secure APIs, allowing for flexible integration of AI models.
          </p>
          <div className="bg-card p-6 rounded-lg border border-border">
            <SubSectionTitle title="Multimodal Fusion Architecture" icon={<GitBranch />} />
            <p className="text-muted-foreground">
              We use a hybrid fusion approach that processes facial and vocal streams in parallel. Cross-modal attention mechanisms allow the model to weigh different indicators contextually, providing a holistic and robust assessment of candidate authenticity. This balances accuracy with interpretability, avoiding "black box" decisions.
            </p>
          </div>
        </section>
      </motion.div>
    </>
  );
};

export default TechnicalDetailsPage;