import React from 'react';
import { TabsList, TabsTrigger } from '@/components/ui/tabs';

const AuthTabs = ({ activeTab, setActiveTab }) => {
  return (
    <TabsList className="grid w-full grid-cols-3 bg-secondary/50 p-1 rounded-lg mb-6">
      <TabsTrigger 
        value="login" 
        className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md text-muted-foreground py-2 sm:py-2.5 text-sm sm:text-base"
        onClick={() => setActiveTab('login')}
        aria-controls="login-content"
        aria-selected={activeTab === 'login'}
      >
        Email
      </TabsTrigger>
      <TabsTrigger 
        value="sms" 
        className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md text-muted-foreground py-2 sm:py-2.5 text-sm sm:text-base"
        onClick={() => setActiveTab('sms')}
        aria-controls="sms-content"
        aria-selected={activeTab === 'sms'}
      >
        Phone
      </TabsTrigger>
      <TabsTrigger 
        value="signup" 
        className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md text-muted-foreground py-2 sm:py-2.5 text-sm sm:text-base"
        onClick={() => setActiveTab('signup')}
        aria-controls="signup-content"
        aria-selected={activeTab === 'signup'}
      >
        Sign Up
      </TabsTrigger>
    </TabsList>
  );
};

export default AuthTabs;