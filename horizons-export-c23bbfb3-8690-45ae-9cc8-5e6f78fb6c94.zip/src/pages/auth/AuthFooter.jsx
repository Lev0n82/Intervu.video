import React from 'react';
import { Link } from 'react-router-dom';
import { Info, Code2, Gavel } from 'lucide-react';

const AuthFooter = () => {
  return (
    <footer className="mt-8 text-center text-muted-foreground text-xs sm:text-sm" role="contentinfo">
      <div className="mb-3 space-x-2 sm:space-x-6 flex flex-col sm:flex-row justify-center items-center flex-wrap">
        <Link to="/about" className="flex items-center text-muted-foreground hover:text-primary transition-colors my-1 py-1" aria-label="About Us">
          <Info className="w-4 h-4 mr-1 sm:mr-1.5" aria-hidden="true" /> About Us
        </Link>
        <Link to="/about/technical-details" className="flex items-center text-muted-foreground hover:text-primary transition-colors my-1 py-1" aria-label="Technical Details">
          <Code2 className="w-4 h-4 mr-1 sm:mr-1.5" aria-hidden="true" /> Tech Details
        </Link>
        <Link to="/terms-and-conditions" className="flex items-center text-muted-foreground hover:text-primary transition-colors my-1 py-1" aria-label="Terms and Conditions">
          <Gavel className="w-4 h-4 mr-1 sm:mr-1.5" aria-hidden="true" /> Terms & Conditions
        </Link>
      </div>
      <p>&copy; {new Date().getFullYear()} intervu.video. All rights reserved.</p>
      <p className="text-xs text-muted-foreground/80 mt-1">Empowering recruitment through intelligent automation.</p>
    </footer>
  );
};

export default AuthFooter;