import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Building, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import CreateOrganizationDialog from '@/components/organization/CreateOrganizationDialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const RoleSelectionPage = () => {
  const [selectedRole, setSelectedRole] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { refreshUserProfile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
    if (role === 'Hiring') {
      setIsDialogOpen(true);
    } else if (role === 'Candidate') {
      handleCompleteOnboarding('Candidate');
    }
  };

  const handleCompleteOnboarding = async (role, orgName = null, department = null, title = null) => {
    const { data, error } = await supabase.rpc('handle_new_user_onboarding', {
      p_user_type: role,
      p_org_name: orgName,
      p_department: department,
    });

    if (error || (data && data.success === false)) {
      toast({
        variant: 'destructive',
        title: 'Onboarding Failed',
        description: error?.message || data?.message || 'Could not complete your profile setup.',
      });
      return;
    }
    
    await refreshUserProfile();
    
    // The AppContent component will handle the final redirect, so we just navigate to root.
    navigate('/', { replace: true }); 
  };
  
  return (
    <>
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="w-full max-w-lg mx-auto shadow-2xl">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Welcome to Intervu.video!</CardTitle>
              <CardDescription className="text-lg text-muted-foreground pt-2">
                To get started, please tell us how you'll be using the platform.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
              <motion.div whileHover={{ y: -5 }}>
                <Card
                  onClick={() => handleRoleSelect('Hiring')}
                  className={cn(
                    'p-6 text-center cursor-pointer transition-all duration-300 border-2',
                    selectedRole === 'Hiring' ? 'border-primary shadow-lg' : 'hover:border-primary/50'
                  )}
                >
                  <Building className="mx-auto h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-semibold">I'm Hiring</h3>
                  <p className="text-muted-foreground mt-1">Create interviews, surveys, and manage candidates.</p>
                </Card>
              </motion.div>
              <motion.div whileHover={{ y: -5 }}>
                <Card
                  onClick={() => handleRoleSelect('Candidate')}
                  className={cn(
                    'p-6 text-center cursor-pointer transition-all duration-300 border-2',
                    selectedRole === 'Candidate' ? 'border-primary shadow-lg' : 'hover:border-primary/50'
                  )}
                >
                  <User className="mx-auto h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-semibold">I'm a Candidate</h3>
                  <p className="text-muted-foreground mt-1">Respond to interviews or surveys I've been invited to.</p>
                </Card>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <CreateOrganizationDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onOrganizationCreated={(orgData) => {
          handleCompleteOnboarding('Hiring', orgData.orgName, orgData.department, orgData.title);
        }}
      />
    </>
  );
};

export default RoleSelectionPage;