import React from 'react';

const Logo = ({ className = 'h-10', ...props }) => (
  <svg
    viewBox="0 0 230 40"
    className={className}
    aria-labelledby="logoTitle"
    role="img"
    {...props}
  >
    <title id="logoTitle">intervu.video Logo</title>
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="100%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="hsl(var(--primary))" />
        <stop offset="100%" stopColor="hsl(200 100% 100%)" />
      </linearGradient>
    </defs>
    
    <g style={{ fontFamily: "'Poppins', sans-serif", fontSize: '32px', fontWeight: 600, fill: 'url(#logoGradient)', letterSpacing: '-0.5px' }}>
      <text x="0" y="30">intervu.video</text>
    </g>
  </svg>
);

export default Logo;