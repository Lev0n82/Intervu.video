
import React from 'react';

/**
 * Renders the HTML content for invitation emails.
 * Note: This component is intended to be used server-side or converted to string
 * for email sending.
 */
export const InvitationEmailTemplate = ({ 
    type = 'team', // 'team' | 'interview' | 'survey'
    inviteLink,
    recipientName,
    inviterName,
    organizationName,
    expiryDate,
    title // "Senior Developer Interview" or "Q1 Feedback Survey"
}) => {
    
    const getActionText = () => {
        switch(type) {
            case 'team': return 'Join Team';
            case 'interview': return 'Start Interview';
            case 'survey': return 'Start Survey';
            default: return 'View Invitation';
        }
    };

    const getMessageText = () => {
        switch(type) {
            case 'team': 
                return `You have been invited to join the <strong>${organizationName}</strong> team on Intervu.video.`;
            case 'interview': 
                return `You have been invited to a video interview for <strong>${title}</strong> at ${organizationName}.`;
            case 'survey': 
                return `We'd love your input! Please participate in our video survey: <strong>${title}</strong>.`;
            default: return '';
        }
    };

    // Inline styles for email compatibility
    const styles = {
        container: {
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            maxWidth: '600px',
            margin: '0 auto',
            backgroundColor: '#ffffff',
            padding: '20px',
            borderRadius: '8px',
            border: '1px solid #e2e8f0'
        },
        header: {
            textAlign: 'center',
            marginBottom: '30px',
            borderBottom: '1px solid #e2e8f0',
            paddingBottom: '20px'
        },
        logo: {
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#0f172a',
            textDecoration: 'none'
        },
        content: {
            color: '#334155',
            lineHeight: '1.6',
            marginBottom: '30px'
        },
        buttonContainer: {
            textAlign: 'center',
            margin: '30px 0'
        },
        button: {
            backgroundColor: '#2563eb',
            color: '#ffffff',
            padding: '12px 24px',
            borderRadius: '6px',
            textDecoration: 'none',
            fontWeight: 'bold',
            display: 'inline-block'
        },
        footer: {
            marginTop: '40px',
            textAlign: 'center',
            fontSize: '12px',
            color: '#94a3b8',
            borderTop: '1px solid #e2e8f0',
            paddingTop: '20px'
        }
    };

    return (
        <div style={styles.container}>
            <div style={styles.header}>
                <a href="https://intervu.video" style={styles.logo}>Intervu.video</a>
            </div>
            
            <div style={styles.content}>
                <p>Hello {recipientName || 'there'},</p>
                
                <p dangerouslySetInnerHTML={{ __html: getMessageText() }} />
                
                <div style={styles.buttonContainer}>
                    <a href={inviteLink} style={styles.button}>
                        {getActionText()}
                    </a>
                </div>
                
                {inviterName && <p>Invited by: {inviterName}</p>}
                
                {expiryDate && (
                    <p style={{ fontSize: '14px', color: '#64748b' }}>
                        This invitation expires on {new Date(expiryDate).toLocaleDateString()}.
                    </p>
                )}
            </div>
            
            <div style={styles.footer}>
                <p>&copy; {new Date().getFullYear()} Intervu.video. All rights reserved.</p>
                <p>
                    <small>If you didn't request this email, you can safely ignore it.</small>
                </p>
            </div>
        </div>
    );
};
