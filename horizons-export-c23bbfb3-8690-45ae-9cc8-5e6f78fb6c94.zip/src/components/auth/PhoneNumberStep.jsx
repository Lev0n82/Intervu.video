
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Phone, ArrowRight, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const PhoneNumberStep = ({ onNext, initialPhone }) => {
  const [phone, setPhone] = useState(initialPhone || '');
  const [countryCode, setCountryCode] = useState('+1');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const validatePhone = (number) => {
    // Basic validation: removes non-digits and checks length
    const cleaned = number.replace(/\D/g, '');
    return cleaned.length >= 10;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    if (!validatePhone(phone)) {
      toast({
        variant: "destructive",
        title: "Invalid Phone Number",
        description: "Please enter a valid phone number with at least 10 digits.",
      });
      setLoading(false);
      return;
    }

    // Simulate a small delay for better UX
    setTimeout(() => {
      setLoading(false);
      // Pass combined number
      onNext(`${countryCode}${phone}`);
    }, 500);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-semibold tracking-tight">Enter your phone number</h2>
        <p className="text-sm text-muted-foreground">
          We'll use this to secure your account and for important notifications.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <div className="flex gap-2">
            <Select value={countryCode} onValueChange={setCountryCode}>
              <SelectTrigger className="w-[100px]">
                <SelectValue placeholder="+1" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="+1">🇺🇸 +1</SelectItem>
                <SelectItem value="+44">🇬🇧 +44</SelectItem>
                <SelectItem value="+33">🇫🇷 +33</SelectItem>
                <SelectItem value="+49">🇩🇪 +49</SelectItem>
                <SelectItem value="+81">🇯🇵 +81</SelectItem>
                {/* Add more as needed */}
              </SelectContent>
            </Select>
            <div className="relative flex-1">
              <Phone className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                placeholder="(555) 123-4567"
                className="pl-9"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                autoFocus
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            We will never share your phone number with third parties.
          </p>
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
          Continue
        </Button>
      </form>
    </div>
  );
};

export default PhoneNumberStep;
