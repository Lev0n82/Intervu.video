import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Checkbox } from '@/components/ui/checkbox';
    import { motion } from 'framer-motion';
    import { Trash2, PlusCircle, GripVertical, Text, CheckSquare, Star, List, ToggleRight } from 'lucide-react';

    const SurveyQuestionBuilder = ({ question, index, onQuestionChange, onRemoveQuestion, disabled }) => {
      const [options, setOptions] = useState(question.options || ['']);

      useEffect(() => {
        if (question.type === 'likert') {
          const likertOptions = ['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'];
          setOptions(likertOptions);
          onQuestionChange(question.id, 'options', likertOptions);
        } else if (question.type === 'yes-no') {
          const yesNoOptions = ['Yes', 'No'];
          setOptions(yesNoOptions);
          onQuestionChange(question.id, 'options', yesNoOptions);
        } else if (question.type === 'rating') {
          onQuestionChange(question.id, 'options', []);
        }
      }, [question.type, question.id, onQuestionChange]);

      const handleOptionChange = (optionIndex, value) => {
        const newOptions = [...options];
        newOptions[optionIndex] = value;
        setOptions(newOptions);
        onQuestionChange(question.id, 'options', newOptions.filter(Boolean));
      };

      const addOption = () => {
        setOptions([...options, '']);
      };

      const removeOption = (optionIndex) => {
        const newOptions = options.filter((_, i) => i !== optionIndex);
        setOptions(newOptions);
        onQuestionChange(question.id, 'options', newOptions.filter(Boolean));
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 sm:p-6 bg-card/80 dark:bg-slate-700/50 rounded-lg border border-border space-y-4"
          role="group"
          aria-labelledby={`question-group-heading-${index}`}
        >
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <GripVertical className="w-5 h-5 text-muted-foreground mr-2 cursor-grab" aria-hidden="true" />
              <h3 id={`question-group-heading-${index}`} className="text-lg font-medium text-card-foreground">Question {index + 1}</h3>
            </div>
            <Button type="button" variant="ghost" size="icon" onClick={() => onRemoveQuestion(question.id)} className="text-destructive hover:text-destructive/80 hover:bg-destructive/10" aria-label={`Remove question ${index + 1}`} disabled={disabled}>
              <Trash2 className="w-5 h-5" aria-hidden="true" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor={`questionText-${question.id}`}>Question Text</Label>
              <Textarea
                id={`questionText-${question.id}`}
                value={question.text || ''} 
                onChange={(e) => onQuestionChange(question.id, 'text', e.target.value)}
                placeholder="e.g., How satisfied are you with the interview process?"
                required
                className="mt-1"
                disabled={disabled}
              />
            </div>
            <div>
              <Label htmlFor={`questionType-${question.id}`}>Question Type</Label>
              <Select value={question.type} onValueChange={(value) => onQuestionChange(question.id, 'type', value)} disabled={disabled}>
                <SelectTrigger id={`questionType-${question.id}`} className="mt-1">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text"><span className="flex items-center"><Text className="w-4 h-4 mr-2" aria-hidden="true"/>Text</span></SelectItem>
                  <SelectItem value="multiple-choice"><span className="flex items-center"><CheckSquare className="w-4 h-4 mr-2" aria-hidden="true"/>Multiple Choice</span></SelectItem>
                  <SelectItem value="rating"><span className="flex items-center"><Star className="w-4 h-4 mr-2" aria-hidden="true"/>Rating (1-5)</span></SelectItem>
                  <SelectItem value="likert"><span className="flex items-center"><List className="w-4 h-4 mr-2" aria-hidden="true"/>Likert Scale</span></SelectItem>
                  <SelectItem value="yes-no"><span className="flex items-center"><ToggleRight className="w-4 h-4 mr-2" aria-hidden="true"/>Yes/No</span></SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center pt-6">
              <Checkbox
                id={`isRequired-${question.id}`}
                checked={question.isRequired}
                onCheckedChange={(checked) => onQuestionChange(question.id, 'isRequired', checked)}
                aria-labelledby={`isRequired-label-${question.id}`}
                disabled={disabled}
              />
              <Label htmlFor={`isRequired-${question.id}`} id={`isRequired-label-${question.id}`} className="ml-2">Required</Label>
            </div>
          </div>

          {question.type === 'multiple-choice' && (
            <div className="space-y-2 pt-2">
              <Label>Options</Label>
              {options.map((option, optionIndex) => (
                <div key={optionIndex} className="flex items-center gap-2">
                  <Input
                    type="text"
                    value={option}
                    onChange={(e) => handleOptionChange(optionIndex, e.target.value)}
                    placeholder={`Option ${optionIndex + 1}`}
                    aria-label={`Option ${optionIndex + 1} for question ${index + 1}`}
                    disabled={disabled}
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeOption(optionIndex)} className="text-destructive hover:text-destructive/80" aria-label={`Remove option ${optionIndex + 1}`} disabled={disabled}>
                    <Trash2 className="w-4 h-4" aria-hidden="true" />
                  </Button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={addOption} disabled={disabled}>
                <PlusCircle className="w-4 h-4 mr-2" aria-hidden="true" /> Add Option
              </Button>
            </div>
          )}
        </motion.div>
      );
    };

    export default SurveyQuestionBuilder;