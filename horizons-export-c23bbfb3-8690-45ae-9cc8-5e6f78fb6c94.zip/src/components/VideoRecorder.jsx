
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { 
  Video, Mic, Loader2, RotateCcw, 
  Grid3X3, Sun, X, Wand2, Type, Aperture,
  CheckCircle, Square, AlertCircle, Info
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';
import { generateThumbnail, getMediaDevices } from '@/lib/mediaUtils';

// Helper: Format seconds to MM:SS
const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const VideoRecorder = ({ open, onOpenChange, onUploadComplete, storagePath = 'template-videos', bucketName = 'template-videos' }) => {
  const { toast } = useToast();
  
  // --- State: Machine ---
  const [status, setStatus] = useState('idle'); // idle, recording, review, uploading
  const [stream, setStream] = useState(null);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  
  // --- State: Settings & Hardware ---
  const [videoDevices, setVideoDevices] = useState([]);
  const [selectedCamera, setSelectedCamera] = useState('');
  const [resolution, setResolution] = useState('720p'); 
  const [showGrid, setShowGrid] = useState(false);
  const [isBlurred, setIsBlurred] = useState(false);
  
  // --- State: Editing & AI ---
  const [editSettings, setEditSettings] = useState({ brightness: 100, contrast: 100, saturation: 100 });
  const [transcription, setTranscription] = useState('');
  
  // --- State: Metrics ---
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const [lightingScore, setLightingScore] = useState(null);
  const [cameraError, setCameraError] = useState(null);
  const [blobSizeWarning, setBlobSizeWarning] = useState(false);

  // --- Refs ---
  const videoRef = useRef(null);
  const previewVideoRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const timerIntervalRef = useRef(null);
  const recognitionRef = useRef(null);
  
  // CRITICAL: Use a Ref for stream to prevent dependency cycles in useEffects
  const streamRef = useRef(null);
  // CRITICAL: Use a Ref for chunks to ensure we capture them across any renders
  const chunksRef = useRef([]);

  // --- Cleanup ---
  const stopStream = useCallback(() => {
    // Stop tracks on the actual stream object reference
    if (streamRef.current) {
      console.log("[VideoRecorder] Stopping all tracks in stream:", streamRef.current.id);
      streamRef.current.getTracks().forEach(track => {
          try { 
            track.stop(); 
            console.log(`[VideoRecorder] Track stopped: ${track.kind} (${track.label})`);
          } catch (e) { 
            console.warn("Error stopping track", e); 
          }
      });
      streamRef.current = null;
    }
    
    // Also clear state
    setStream(null);
    
    if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
        audioContextRef.current = null;
    }
  }, []); // Empty dependency array = Stable function!

  const cleanup = useCallback(() => {
    console.log("[VideoRecorder] Full cleanup triggered");
    stopStream();
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
    }
    
    // Reset States
    setStatus('idle');
    setRecordedBlob(null);
    setPreviewUrl(null);
    setRecordingTime(0);
    setTranscription('');
    setEditSettings({ brightness: 100, contrast: 100, saturation: 100 });
    setCameraError(null);
    setMediaRecorder(null);
    setAudioLevel(0);
    setBlobSizeWarning(false);
    chunksRef.current = [];
  }, [previewUrl, stopStream]);

  // --- Initialization ---

  // Load Devices - Initial attempt
  useEffect(() => {
    if (open) {
      getMediaDevices().then(({ videoDevices }) => {
        setVideoDevices(videoDevices);
        if (videoDevices.length > 0 && !selectedCamera) {
          setSelectedCamera(videoDevices[0].deviceId);
        }
      });
    }
  }, [open]); // Removed selectedCamera from deps to prevent loops

  // Init Camera Function
  const initializeCamera = useCallback(async () => {
    // 1. Clean up existing stream properly first
    stopStream();
    setCameraError(null);
    setStatus('idle');

    // 2. Define Constraints
    const width = resolution === '1080p' ? 1920 : resolution === '720p' ? 1280 : 640;
    const height = resolution === '1080p' ? 1080 : resolution === '720p' ? 720 : 480;

    const constraints = {
      audio: true, 
      video: {
        deviceId: selectedCamera ? { exact: selectedCamera } : undefined,
        width: { ideal: width },
        height: { ideal: height },
        facingMode: 'user' 
      }
    };

    console.log("[VideoRecorder] getUserMedia called with constraints:", JSON.stringify(constraints));

    try {
      // 3. Request Permission & Stream
      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      // 4. Verify Tracks
      const videoTracks = newStream.getVideoTracks();
      const audioTracks = newStream.getAudioTracks();

      console.log(`[VideoRecorder] Stream acquired. ID: ${newStream.id}`);
      console.log(`[VideoRecorder] Video Tracks: ${videoTracks.length}`);
      
      if (videoTracks.length === 0) {
        throw new Error("No video track found in stream. Please check camera availability.");
      }
      
      if (audioTracks.length === 0) {
        console.warn("[VideoRecorder] No audio track found. Recording will be silent.");
        toast({ title: "Microphone Warning", description: "No audio detected. Check your microphone settings.", variant: "warning" });
      }

      // 5. Update Ref AND State
      streamRef.current = newStream;
      setStream(newStream);
      
      // 6. Audio Analysis Setup (Visualizer)
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
            const audioCtx = new AudioContext();
            const analyser = audioCtx.createAnalyser();
            const source = audioCtx.createMediaStreamSource(newStream);
            source.connect(analyser);
            analyser.fftSize = 64;
            audioContextRef.current = audioCtx;
            analyserRef.current = analyser;
            analyzeAudio();
        }
      } catch (e) {
        console.error("Audio Context Error:", e);
      }

      // 7. Web Speech API Setup
      if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';
        recognition.onresult = (event) => {
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            }
          }
          if (finalTranscript) {
             setTranscription(prev => (prev ? prev + ' ' : '') + finalTranscript);
          }
        };
        recognitionRef.current = recognition;
      }

    } catch (error) {
      console.error("[VideoRecorder] Camera Init Failed:", error);
      
      let errorMessage = "Could not access camera/mic.";
      
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
          errorMessage = "Permission denied. Please allow camera and microphone access in your browser settings.";
      } else if (error.name === 'NotFoundError') {
          errorMessage = "No camera or microphone device found.";
      } else if (error.name === 'NotReadableError') {
          errorMessage = "Camera/Mic is busy or being used by another application.";
      } else if (error.name === 'OverconstrainedError') {
          errorMessage = "Camera does not support the requested resolution.";
      }

      setCameraError(errorMessage);
      toast({ 
        title: "Camera Access Error", 
        description: errorMessage, 
        variant: "destructive" 
      });
    }
  }, [resolution, selectedCamera, stopStream, toast]); // Dependencies should be stable or settings-related

  // Connect Stream to Video Element
  useEffect(() => {
    const videoEl = videoRef.current;
    if (videoEl && stream) {
        // Only assign if it's different to prevent freezing/flickering
        if (videoEl.srcObject !== stream) {
            console.log("[VideoRecorder] Assigning stream to video element");
            videoEl.srcObject = stream;
        }
        
        // Ensure playback starts
        const playPromise = videoEl.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.error("[VideoRecorder] Error attempting to play video:", error);
          });
        }
    }
  }, [stream]); // Only re-run when stream object changes, NOT on status change

  // Main Lifecycle Effect - Handles Open/Close and Settings Changes
  useEffect(() => {
    if (open) {
        // Only initialize if we aren't already reviewing a recorded blob
        if (!recordedBlob) {
            initializeCamera();
        }
    } else {
        // Full cleanup when dialog closes
        cleanup();
    }
    
    // Cleanup function for when dependencies change (e.g. resolution changes)
    return () => {
        // We stop stream here to ensure clean restart on settings change
        // OR when component unmounts
        stopStream();
    };
  }, [open, initializeCamera, stopStream, recordedBlob]); 

  // --- Loops ---
  const analyzeAudio = () => {
    if (!analyserRef.current || status === 'review') return;
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);
    const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
    setAudioLevel(average);
    animationFrameRef.current = requestAnimationFrame(analyzeAudio);
  };

  useEffect(() => {
    const lightingInterval = setInterval(() => {
        if (videoRef.current && stream && status !== 'review' && videoRef.current.readyState === 4) {
            analyzeLighting();
        }
    }, 1000);
    return () => clearInterval(lightingInterval);
  }, [stream, status]);

  const analyzeLighting = () => {
    if (!videoRef.current) return;
    try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 50; canvas.height = 50;
        ctx.drawImage(videoRef.current, 0, 0, 50, 50);
        const data = ctx.getImageData(0, 0, 50, 50).data;
        let total = 0;
        for (let i = 0; i < data.length; i += 4) total += (data[i] + data[i+1] + data[i+2]) / 3;
        const avg = total / (data.length / 4);
        setLightingScore(avg < 50 ? 'dark' : avg > 200 ? 'bright' : 'good');
    } catch (e) {}
  };

  // --- Controls ---
  const startRecording = () => {
    if (!stream) {
        console.error("[VideoRecorder] Cannot start recording: No stream available");
        return;
    }
    
    // Check supported types - prioritize standard types
    const mimeTypes = [
        'video/webm;codecs=vp9,opus', 
        'video/webm;codecs=vp8,opus', 
        'video/webm', 
        'video/mp4',
        'video/quicktime' // Added support for .mov
    ];
    
    const mimeType = mimeTypes.find(t => MediaRecorder.isTypeSupported(t));
    
    if (!mimeType) {
        console.error("[VideoRecorder] No supported MIME types found for MediaRecorder.");
        toast({ title: "Error", description: "Your browser does not support video recording.", variant: "destructive" });
        return;
    }

    console.log(`[VideoRecorder] Starting recording with mimeType: ${mimeType}`);

    // Clear previous chunks
    chunksRef.current = [];

    try {
        const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 2500000 }); // ~2.5Mbps
        
        recorder.ondataavailable = e => { 
            console.log(`[VideoRecorder] Chunk received: ${e.data.size} bytes`);
            if (e.data && e.data.size > 0) {
                chunksRef.current.push(e.data); 
            }
        };
        
        recorder.onstart = () => {
             console.log("[VideoRecorder] MediaRecorder started successfully.");
             setStatus('recording');
        };

        recorder.onerror = (e) => {
             console.error("[VideoRecorder] MediaRecorder Error:", e);
             toast({ title: "Recording Error", description: "An error occurred during recording.", variant: "destructive" });
        };
        
        recorder.onstop = () => {
          console.log(`[VideoRecorder] Recording stopped. Chunks collected: ${chunksRef.current.length}`);
          const blob = new Blob(chunksRef.current, { type: mimeType });
          
          console.log(`[VideoRecorder] Final Blob Size: ${blob.size} bytes, Type: ${blob.type}`);
          
          if (blob.size < 1000) { // Less than 1KB is suspicious
              console.error("[VideoRecorder] Recorded blob is suspiciously small!");
              setBlobSizeWarning(true);
          } else {
              setBlobSizeWarning(false);
          }

          setRecordedBlob(blob);
          const url = URL.createObjectURL(blob);
          setPreviewUrl(url);
          setStatus('review');
          
          // Stop recognition
          if (recognitionRef.current) {
              try { recognitionRef.current.stop(); } catch(e) {}
          }
          
          // IMPORTANT: Do NOT stop the stream here if you want to allow "Retake" instantly without re-init.
          // However, for "Review" mode, stopping it saves battery/resources.
          // Since our logic re-initializes on "Retake", it's fine to stop here.
          stopStream(); 
        };

        // Start recording with 1000ms timeslice to ensure frequent ondataavailable events
        recorder.start(1000); 
        setMediaRecorder(recorder);
        setRecordingTime(0);
        setTranscription(''); // Reset transcript
        
        if (recognitionRef.current) {
            try { recognitionRef.current.start(); } catch(e) { console.log('Speech recognition already started or failed'); }
        }

        // Timer
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = setInterval(() => setRecordingTime(p => p + 1), 1000);

    } catch (e) {
        console.error("[VideoRecorder] Failed to start MediaRecorder:", e);
        toast({ title: "Recording Error", description: "Failed to start recording. Please refresh and try again.", variant: "destructive" });
    }
  };

  const stopRecording = () => {
    console.log("[VideoRecorder] Stop button clicked. Recorder State:", mediaRecorder?.state);
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  };

  const handleRetake = () => {
      console.log("[VideoRecorder] Retaking video...");
      setStatus('idle');
      setRecordedBlob(null);
      setPreviewUrl(null);
      setTranscription('');
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      chunksRef.current = [];
      // Camera will auto-reinitialize due to useEffect on 'recordedBlob' change (becoming null)
  };

  const saveVideo = async () => {
    if (!recordedBlob) return;
    setStatus('uploading');

    try {
        // 1. Determine Extension
        let ext = 'webm';
        if (recordedBlob.type.includes('mp4')) ext = 'mp4';
        if (recordedBlob.type.includes('quicktime')) ext = 'mov';

        // 2. Construct File Name
        // Ensure we don't double-nest the folder if storagePath already includes it
        // The bucket is 'template-videos'. If storagePath is 'template-videos', we just want the filename.
        // However, Supabase storage paths are relative to the bucket root.
        // If bucket is 'template-videos', and we upload to 'template-videos/file.mp4', it creates a folder named 'template-videos' inside the bucket.
        // Usually, storagePath passed in is just the folder name inside the bucket, or empty if root.
        
        // Fix: If storagePath is exactly the same as bucketName, we might want to upload to root, or just use it as a folder.
        // But the user specifically asked to prevent 'template-videos/template-videos/'.
        // Let's assume storagePath is meant to be a folder. If it equals bucketName, we might be duplicating.
        // A safer approach is to just use the filename if we want root, or a specific folder.
        // Given the prompt "Ensure uploaded videos are stored in 'template-videos/' path (not 'template-videos/template-videos/')",
        // it implies the bucket is 'template-videos' and we are currently appending 'template-videos/' to the path.
        
        // If bucket is 'template-videos', uploading to 'filename.mp4' puts it in root.
        // If we want it in a folder, we prepend 'folder/'.
        // The prompt says "stored in 'template-videos/' path". This is ambiguous. Does it mean the bucket root? Or a folder named template-videos?
        // "not 'template-videos/template-videos/'" suggests we were doing `template-videos/${filename}` inside the `template-videos` bucket.
        // So we should probably just upload to `${filename}` if we want it in the root of the bucket, OR if storagePath was meant to be the bucket name, we ignore it in the path.
        
        let fileName;
        if (storagePath === bucketName) {
             // If the intended path is the same as the bucket, we probably mean root of that bucket
             fileName = `rec-${Date.now()}.${ext}`;
        } else {
             // Otherwise, treat storagePath as a subfolder
             fileName = `${storagePath}/rec-${Date.now()}.${ext}`;
        }
        
        // Remove any leading slashes just in case
        fileName = fileName.replace(/^\/+/, '');

        console.log(`[VideoRecorder] Uploading to Bucket: ${bucketName}, Path: ${fileName}, Type: ${recordedBlob.type}`);
        
        const { data: videoData, error: videoError } = await supabase.storage
            .from(bucketName).upload(fileName, recordedBlob, { contentType: recordedBlob.type, upsert: false });
            
        if (videoError) throw videoError;
        
        const { data: { publicUrl: videoUrl } } = supabase.storage.from(bucketName).getPublicUrl(videoData.path);

        // 3. Generate & Upload Thumbnail
        let thumbUrl = null;
        try {
            const thumbBlob = await generateThumbnail(recordedBlob, 1); 
            
            let thumbName;
            if (storagePath === bucketName) {
                thumbName = `thumb-${Date.now()}.jpg`;
            } else {
                thumbName = `${storagePath}/thumb-${Date.now()}.jpg`;
            }
            thumbName = thumbName.replace(/^\/+/, '');

            const { data: thumbData, error: thumbError } = await supabase.storage
                .from(bucketName).upload(thumbName, thumbBlob, { contentType: 'image/jpeg', upsert: false });
            
            if (!thumbError) {
                const { data: { publicUrl } } = supabase.storage.from(bucketName).getPublicUrl(thumbData.path);
                thumbUrl = publicUrl;
            }
        } catch (e) {
            console.warn("Thumbnail generation failed", e);
        }

        // 4. Complete
        onUploadComplete({
            url: videoUrl,
            thumbnail_url: thumbUrl,
            transcription: transcription,
            duration: recordingTime,
            edit_settings: editSettings
        });
        
        toast({ title: "Saved", description: "Video uploaded successfully.", className: "bg-green-600 text-white" });
        onOpenChange(false);
    } catch (error) {
        console.error("Upload failed:", error);
        let message = error.message;
        // Provide user-friendly error for missing bucket
        if (message && (message.includes("The resource was not found") || message.includes("Bucket not found"))) {
            message = `System Error: The storage bucket '${bucketName}' does not exist. Please contact support.`;
        }
        toast({ title: "Upload Failed", description: message, variant: "destructive" });
        setStatus('review');
    }
  };

  const filterStyle = {
    filter: `brightness(${editSettings.brightness}%) contrast(${editSettings.contrast}%) saturate(${editSettings.saturation}%)`
  };

  // --- Render ---
  return (
    <Dialog open={open} onOpenChange={(val) => { 
        if(!val) cleanup(); 
        onOpenChange(val); 
    }}>
      <DialogContent className="sm:max-w-[1000px] p-0 bg-zinc-950 border-zinc-800 text-zinc-100 overflow-hidden shadow-2xl flex flex-col h-[95vh] sm:h-auto z-[100] outline-none">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm z-20">
          <div className="flex items-center space-x-2">
            <div className={cn("w-2 h-2 rounded-full", status === 'recording' ? "bg-red-500 animate-pulse" : "bg-zinc-500")} />
            <DialogTitle className="text-sm font-medium tracking-wide uppercase text-zinc-400">
               {status === 'recording' ? 'Recording' : status === 'review' ? 'Studio Editor' : 'Studio Recorder'}
            </DialogTitle>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white" onClick={() => onOpenChange(false)}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row h-full overflow-hidden">
            
            {/* Main Video Area */}
            <div className="flex-1 bg-black flex flex-col relative group">
                 {/* Video Container */}
                 <div className="relative flex-grow flex items-center justify-center bg-black overflow-hidden">
                    {/* Error / Loading */}
                    {cameraError && (
                        <div className="text-red-400 flex flex-col items-center px-4 text-center">
                            <AlertCircle className="w-12 h-12 mb-2 opacity-50"/>
                            <p className="font-semibold">Camera Access Error</p>
                            <p className="text-sm opacity-80 mt-1">{cameraError}</p>
                            <Button variant="outline" size="sm" onClick={initializeCamera} className="mt-4 border-red-900 text-red-400 hover:bg-red-900/20">
                                Try Again
                            </Button>
                        </div>
                    )}
                    
                    {!stream && !cameraError && !recordedBlob && (
                        <div className="text-zinc-500 flex flex-col items-center">
                            <Loader2 className="w-8 h-8 animate-spin mb-2"/>
                            Initializing Camera...
                        </div>
                    )}
                    
                    {/* Video Element */}
                    <div className="relative w-full h-full max-h-[60vh] aspect-video flex items-center justify-center">
                        {status === 'review' ? (
                            <div className="relative w-full h-full flex items-center justify-center">
                                <video 
                                    ref={previewVideoRef}
                                    src={previewUrl} 
                                    controls 
                                    className="w-full h-full object-contain bg-black" 
                                    style={filterStyle}
                                />
                                {blobSizeWarning && (
                                    <div className="absolute top-4 left-4 right-4 bg-yellow-500/90 text-black px-4 py-2 rounded-md font-medium text-sm flex items-center shadow-lg z-30">
                                        <AlertCircle className="w-5 h-5 mr-2 shrink-0" />
                                        Warning: The recording size is unusually small. It may not have captured correctly.
                                    </div>
                                )}
                            </div>
                        ) : (
                            <video 
                                ref={videoRef}
                                autoPlay 
                                playsInline
                                muted={true} // MUST be muted to prevent feedback loop
                                onLoadedMetadata={() => console.log("[VideoRecorder] Video: loadedmetadata")}
                                onLoadedData={() => console.log("[VideoRecorder] Video: loadeddata (First frame ready)")}
                                onCanPlay={() => console.log("[VideoRecorder] Video: canplay")}
                                onPlaying={() => console.log("[VideoRecorder] Video: playing")}
                                onError={(e) => console.error("[VideoRecorder] Video Error:", e.target.error)}
                                className={cn("w-full h-full object-cover transition-all", status === 'recording' && "scale-105", "transform -scale-x-100")} 
                                style={filterStyle} 
                            />
                        )}
                        
                        {showGrid && status !== 'review' && (
                             <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none z-10 opacity-30">
                                {[...Array(9)].map((_, i) => <div key={i} className="border border-white/20"></div>)}
                            </div>
                        )}
                        
                        {/* Recording Badge */}
                        {status === 'recording' && (
                            <div className="absolute top-4 right-4 z-20 bg-red-500/90 text-white px-3 py-1.5 rounded-full font-mono text-sm font-bold flex items-center shadow-lg animate-pulse">
                                <div className="w-2 h-2 rounded-full bg-white mr-2" />
                                {formatTime(recordingTime)}
                            </div>
                        )}
                        
                         {/* Live Transcription Overlay */}
                         {status === 'recording' && transcription && (
                            <div className="absolute bottom-8 left-0 right-0 px-8 text-center pointer-events-none z-30">
                                <span className="inline-block bg-black/60 text-white px-4 py-2 rounded-lg text-lg backdrop-blur-md">
                                    {transcription.slice(-50)}
                                    <span className="animate-pulse">|</span>
                                </span>
                            </div>
                        )}
                    </div>
                 </div>

                 {/* Bottom Controls Bar */}
                 <div className="h-20 bg-zinc-900 border-t border-zinc-800 flex items-center justify-between px-6 shrink-0 z-20">
                    <div className="flex items-center gap-4 w-1/3">
                        {status !== 'review' && (
                            <div className="flex items-center gap-2">
                                <Button variant="ghost" size="icon" onClick={() => setShowGrid(!showGrid)} className={showGrid ? "text-indigo-400 bg-indigo-400/10" : "text-zinc-400"}>
                                    <Grid3X3 className="w-5 h-5" />
                                </Button>
                                {/* Blur Toggle */}
                                <Button variant="ghost" size="icon" onClick={() => { setIsBlurred(!isBlurred); initializeCamera(); }} className={isBlurred ? "text-indigo-400 bg-indigo-400/10" : "text-zinc-400"}>
                                    <Aperture className="w-5 h-5" />
                                </Button>
                            </div>
                        )}
                    </div>

                    <div className="flex items-center justify-center gap-4 w-1/3">
                        {status === 'idle' && (
                            <Button size="icon" className="h-14 w-14 rounded-full bg-red-600 hover:bg-red-700 shadow-xl border-4 border-zinc-800 transition-transform hover:scale-105 active:scale-95" onClick={startRecording} disabled={!stream}>
                                <div className="w-4 h-4 bg-white rounded-sm" />
                            </Button>
                        )}
                        {status === 'recording' && (
                            <Button size="icon" className="h-14 w-14 rounded-full bg-zinc-100 hover:bg-white text-red-600 shadow-xl border-4 border-zinc-800 transition-transform hover:scale-105 active:scale-95" onClick={stopRecording}>
                                <Square className="w-5 h-5 fill-current" />
                            </Button>
                        )}
                        {status === 'review' && (
                             <div className="flex gap-2">
                                <Button variant="secondary" onClick={handleRetake} disabled={status === 'uploading'}>
                                    <RotateCcw className="w-4 h-4 mr-2" /> Retake
                                </Button>
                                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white min-w-[100px]" onClick={saveVideo} disabled={status === 'uploading'}>
                                    {status === 'uploading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <span className="flex items-center"><CheckCircle className="w-4 h-4 mr-2"/> Save Video</span>}
                                </Button>
                             </div>
                        )}
                    </div>

                    <div className="flex items-center justify-end gap-2 w-1/3">
                        {/* Audio Meter */}
                        {status !== 'review' && (
                            <div className="h-8 w-24 bg-zinc-800 rounded-full overflow-hidden flex items-center px-2 gap-1 border border-zinc-700">
                                <Mic className="w-3 h-3 text-zinc-500" />
                                <div className="flex-1 h-1 bg-zinc-700 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-500 transition-all duration-75" style={{ width: `${Math.min((audioLevel/128)*100, 100)}%` }} />
                                </div>
                            </div>
                        )}
                    </div>
                 </div>
            </div>

            {/* Right Sidebar (Settings / Editing) */}
            <div className="w-full sm:w-80 bg-zinc-950 border-l border-zinc-800 flex flex-col">
                <Tabs defaultValue={status === 'review' ? 'edit' : 'settings'} value={status === 'review' ? 'edit' : 'settings'} className="flex-1 flex flex-col">
                    <TabsList className="grid w-full grid-cols-2 bg-zinc-900 rounded-none border-b border-zinc-800">
                        <TabsTrigger value="settings" disabled={status === 'review'} className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400">Settings</TabsTrigger>
                        <TabsTrigger value="edit" disabled={status !== 'review'} className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400">Edit</TabsTrigger>
                    </TabsList>

                    <TabsContent value="settings" className="p-6 space-y-6 flex-1 overflow-y-auto">
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-xs font-medium text-zinc-400 uppercase tracking-wider">Camera</label>
                                <Select value={selectedCamera} onValueChange={(val) => { setSelectedCamera(val); }}>
                                    <SelectTrigger className="bg-zinc-900 border-zinc-800 text-zinc-200">
                                        <SelectValue placeholder="Select Camera" />
                                    </SelectTrigger>
                                    <SelectContent className="bg-zinc-900 border-zinc-800 text-zinc-200">
                                        {videoDevices.map(device => (
                                            <SelectItem key={device.deviceId} value={device.deviceId}>{device.label || `Camera ${device.deviceId.slice(0,4)}`}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <label className="text-xs font-medium text-zinc-400 uppercase tracking-wider">Quality</label>
                                <Select value={resolution} onValueChange={(val) => { setResolution(val); }}>
                                    <SelectTrigger className="bg-zinc-900 border-zinc-800 text-zinc-200"><SelectValue /></SelectTrigger>
                                    <SelectContent className="bg-zinc-900 border-zinc-800 text-zinc-200">
                                        <SelectItem value="1080p">1080p Full HD</SelectItem>
                                        <SelectItem value="720p">720p HD (Recommended)</SelectItem>
                                        <SelectItem value="480p">480p SD</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            <div className="pt-4 border-t border-zinc-800">
                                <div className="flex items-center gap-2 mb-2">
                                    <Sun className={cn("w-4 h-4", lightingScore === 'good' ? "text-green-500" : "text-yellow-500")} />
                                    <span className="text-sm font-medium text-zinc-300">Lighting Check</span>
                                </div>
                                <p className="text-xs text-zinc-500">
                                    {lightingScore === 'dark' ? 'Environment is too dark.' : lightingScore === 'bright' ? 'Environment is too bright.' : 'Lighting is optimal.'}
                                </p>
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="edit" className="p-6 space-y-6 flex-1 overflow-y-auto">
                         <div className="space-y-6">
                            <div className="flex items-center gap-2 text-indigo-400 mb-2">
                                <Wand2 className="w-4 h-4" />
                                <span className="text-sm font-bold uppercase tracking-wider">Visual Effects</span>
                            </div>

                            <div className="space-y-3">
                                <div className="flex justify-between text-xs text-zinc-400"><span>Brightness</span><span>{editSettings.brightness}%</span></div>
                                <Slider 
                                    min={50} max={150} step={1} 
                                    value={[editSettings.brightness]} 
                                    onValueChange={([val]) => setEditSettings(p => ({...p, brightness: val}))} 
                                    className="[&>.relative>.absolute]:bg-indigo-500"
                                />
                            </div>

                            <div className="space-y-3">
                                <div className="flex justify-between text-xs text-zinc-400"><span>Contrast</span><span>{editSettings.contrast}%</span></div>
                                <Slider 
                                    min={50} max={150} step={1} 
                                    value={[editSettings.contrast]} 
                                    onValueChange={([val]) => setEditSettings(p => ({...p, contrast: val}))} 
                                    className="[&>.relative>.absolute]:bg-indigo-500"
                                />
                            </div>

                            <div className="space-y-3">
                                <div className="flex justify-between text-xs text-zinc-400"><span>Saturation</span><span>{editSettings.saturation}%</span></div>
                                <Slider 
                                    min={0} max={200} step={1} 
                                    value={[editSettings.saturation]} 
                                    onValueChange={([val]) => setEditSettings(p => ({...p, saturation: val}))} 
                                    className="[&>.relative>.absolute]:bg-indigo-500"
                                />
                            </div>

                            <Button variant="outline" size="sm" className="w-full mt-4 border-zinc-800 text-zinc-400" onClick={() => setEditSettings({brightness: 100, contrast: 100, saturation: 100})}>
                                Reset Effects
                            </Button>

                            {transcription && (
                                <div className="mt-8 pt-6 border-t border-zinc-800">
                                    <div className="flex items-center gap-2 text-indigo-400 mb-3">
                                        <Type className="w-4 h-4" />
                                        <span className="text-sm font-bold uppercase tracking-wider">Transcription</span>
                                    </div>
                                    <p className="text-xs text-zinc-400 italic bg-zinc-900 p-3 rounded-lg border border-zinc-800 max-h-[150px] overflow-y-auto">
                                        "{transcription}"
                                    </p>
                                </div>
                            )}
                         </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoRecorder;
