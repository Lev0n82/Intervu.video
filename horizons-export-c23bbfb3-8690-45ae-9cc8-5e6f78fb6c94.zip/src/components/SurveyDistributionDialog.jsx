
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Copy, Send, Loader2, Link as LinkIcon, Mail, CheckCircle, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import CopyableCode from '@/components/CopyableCode';

const SurveyDistributionDialog = ({ open, onOpenChange, survey }) => {
  const [activeTab, setActiveTab] = useState('link');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteSubject, setInviteSubject] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [invitations, setInvitations] = useState([]);
  const [isLoadingInvites, setIsLoadingInvites] = useState(false);
  const { toast } = useToast();

  const publicLink = survey ? `${window.location.origin}/s/${survey.id}` : '';

  useEffect(() => {
    if (survey) {
        setInviteSubject(`You're invited to complete a survey: ${survey.title}`);
        setInviteMessage(`Hello,\n\nWe would appreciate your feedback. Please click the link below to start the survey.\n\nThank you!`);
    }
  }, [survey]);

  useEffect(() => {
    if (open && survey && activeTab === 'email') {
      fetchInvitations();
    }
  }, [open, survey, activeTab]);

  const fetchInvitations = async () => {
    setIsLoadingInvites(true);
    try {
      const { data, error } = await supabase
        .from('survey_invitations')
        .select('*')
        .eq('survey_id', survey.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setInvitations(data);
    } catch (error) {
      console.error('Error fetching invitations:', error);
    } finally {
      setIsLoadingInvites(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicLink);
    toast({ title: 'Link Copied', description: 'Survey link copied to clipboard.', className: "bg-green-500 text-white" });
  };

  const handleSendInvite = async () => {
    if (!inviteEmail.trim()) {
        toast({ title: 'Validation Error', description: 'Please enter at least one email address.', variant: 'destructive' });
        return;
    }

    setIsSending(true);
    try {
        const emails = inviteEmail.split(',').map(e => e.trim()).filter(e => e);
        
        // 1. Create invitations using new RPC that supports codes
        const { data: createData, error: createError } = await supabase.rpc('create_survey_invitations_with_codes', {
            p_survey_id: survey.id,
            p_emails: emails
        });

        if (createError) throw createError;
        if (!createData.success) throw new Error(createData.message);

        // 2. Call Edge Function just to send emails (best effort)
        // We pass the created tokens/codes if the edge function supports it, 
        // or just the emails and let it know we already created records (if it's smart enough),
        // but for now we follow the existing pattern and hope it handles deduplication or we accept slightly redundant logic if edge function recreates.
        // Actually, since we can't update edge function easily, we just trigger it.
        // However, we now have codes in DB!
        
        const { error: emailError } = await supabase.functions.invoke('send-survey-invite', {
            body: {
                surveyId: survey.id,
                emails: emails,
                subject: inviteSubject,
                message: inviteMessage,
                siteUrl: window.location.origin,
                // Pass the pre-generated data just in case the edge function was updated to use it
                preGeneratedInvites: createData.invitations 
            }
        });

        if (emailError) {
            console.warn("Email sending failed, but invites created", emailError);
            toast({ variant: 'warning', title: 'Invites Created, Email Failed', description: 'Codes generated, but email service encountered an error.' });
        } else {
            toast({ title: 'Invitations Sent', description: `Successfully queued ${emails.length} invitation(s).` });
        }

        setInviteEmail('');
        fetchInvitations();

    } catch (error) {
        console.error('Send Error:', error);
        toast({ title: 'Error Creating Invites', description: error.message, variant: 'destructive' });
    } finally {
        setIsSending(false);
    }
  };

  const getStatusBadge = (status) => {
      const styles = {
          pending: 'bg-yellow-500/10 text-yellow-600 border-yellow-200',
          sent: 'bg-blue-500/10 text-blue-600 border-blue-200',
          opened: 'bg-purple-500/10 text-purple-600 border-purple-200',
          clicked: 'bg-indigo-500/10 text-indigo-600 border-indigo-200',
          completed: 'bg-green-500/10 text-green-600 border-green-200',
      };
      return <Badge variant="outline" className={styles[status] || ''}>{status}</Badge>;
  };

  if (!survey) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Distribute Survey</DialogTitle>
          <DialogDescription>
            Share your survey "{survey.title}" via a public link or email invitations.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="link"><LinkIcon className="w-4 h-4 mr-2"/> Share Link</TabsTrigger>
            <TabsTrigger value="email"><Mail className="w-4 h-4 mr-2"/> Email Invite</TabsTrigger>
          </TabsList>
          
          <TabsContent value="link" className="space-y-4 py-4">
            <div className="space-y-4">
                <div className="bg-secondary/30 p-4 rounded-lg border">
                    <h4 className="font-semibold mb-2 flex items-center"><LinkIcon className="w-4 h-4 mr-2"/> Public Link</h4>
                    <p className="text-sm text-muted-foreground mb-4">
                        Anyone with this link can respond to your survey. Responses will be anonymous unless you ask for identification in the questions.
                    </p>
                    <div className="flex space-x-2">
                        <Input value={publicLink} readOnly className="font-mono text-sm bg-background" />
                        <Button onClick={handleCopyLink} variant="secondary">
                            <Copy className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            </div>
          </TabsContent>
          
          <TabsContent value="email" className="space-y-6 py-4">
             <div className="grid gap-4">
                <div className="space-y-2">
                    <Label>Recipients</Label>
                    <Input 
                        placeholder="email@example.com, another@example.com" 
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Separate multiple emails with commas.</p>
                </div>
                <div className="space-y-2">
                    <Label>Subject</Label>
                    <Input 
                        value={inviteSubject}
                        onChange={(e) => setInviteSubject(e.target.value)}
                    />
                </div>
                <div className="space-y-2">
                    <Label>Message</Label>
                    <Textarea 
                        value={inviteMessage}
                        onChange={(e) => setInviteMessage(e.target.value)}
                        rows={4}
                    />
                </div>
                <Button onClick={handleSendInvite} disabled={isSending}>
                    {isSending ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Send className="w-4 h-4 mr-2"/>}
                    Send Invitations
                </Button>
             </div>

             <div className="pt-4 border-t">
                 <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-sm">Recent Invitations</h4>
                    <Button variant="ghost" size="sm" onClick={fetchInvitations} disabled={isLoadingInvites}>
                        <RefreshCw className={`w-4 h-4 ${isLoadingInvites ? 'animate-spin' : ''}`}/>
                    </Button>
                 </div>
                 
                 <div className="border rounded-md overflow-hidden">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Email</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Code</TableHead>
                                <TableHead className="text-right">Sent Date</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {invitations.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={4} className="text-center py-4 text-muted-foreground">No invitations sent yet.</TableCell>
                                </TableRow>
                            ) : (
                                invitations.map((invite) => (
                                    <TableRow key={invite.id}>
                                        <TableCell className="font-medium">{invite.email}</TableCell>
                                        <TableCell>{getStatusBadge(invite.status)}</TableCell>
                                        <TableCell>
                                            {invite.survey_code ? (
                                                <div className="flex items-center space-x-1">
                                                    <span className="font-mono text-xs bg-muted px-1 rounded">{invite.survey_code}</span>
                                                    <Button 
                                                        variant="ghost" 
                                                        size="icon" 
                                                        className="h-6 w-6"
                                                        onClick={() => navigator.clipboard.writeText(invite.survey_code)}
                                                    >
                                                        <Copy className="h-3 w-3"/>
                                                    </Button>
                                                </div>
                                            ) : '-'}
                                        </TableCell>
                                        <TableCell className="text-right text-muted-foreground text-xs">
                                            {invite.sent_at ? format(new Date(invite.sent_at), 'MMM d, h:mm a') : 
                                             invite.created_at ? format(new Date(invite.created_at), 'MMM d, h:mm a') : '-'}
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                 </div>
                 <p className="text-xs text-muted-foreground mt-2">
                    Tip: You can share the Survey Code with candidates via chat or SMS if they cannot access their email.
                 </p>
             </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default SurveyDistributionDialog;
