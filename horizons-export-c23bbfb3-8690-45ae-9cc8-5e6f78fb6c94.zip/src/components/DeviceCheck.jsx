import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { CheckCircle, XCircle, Video, Mic, Volume2 } from "lucide-react";

const DeviceCheck = ({ onComplete }) => {
  const [checks, setChecks] = React.useState({
    camera: null, 
    microphone: null,
    speaker: null,
  });
  const [micPlaybackUrl, setMicPlaybackUrl] = React.useState(null);
  const videoRef = React.useRef(null);
  const { toast } = useToast();
  const [stream, setStream] = React.useState(null);

  const runDeviceCheck = async (device) => {
    setChecks(prev => ({ ...prev, [device]: 'testing' }));
    try {
      switch (device) {
        case "camera": {
            const videoConstraints = [
                { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
                { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
                true
            ];
            let streamAttempt = null;
            for (const constraint of videoConstraints) {
                try {
                    streamAttempt = await navigator.mediaDevices.getUserMedia({ video: constraint });
                    if (streamAttempt) break;
                } catch (e) {
                    console.warn(`Video constraint failed: ${JSON.stringify(constraint)}`);
                }
            }

            if (!streamAttempt) throw new Error("Could not access camera with any constraint.");

            setStream(streamAttempt);
            if (videoRef.current) {
                videoRef.current.srcObject = streamAttempt;
            }
            setChecks(prev => ({ ...prev, camera: true }));
            break;
        }
        case "microphone":
          const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const mediaRecorder = new MediaRecorder(audioStream);
          const audioChunks = [];
          mediaRecorder.ondataavailable = event => audioChunks.push(event.data);
          mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            const audioUrl = URL.createObjectURL(audioBlob);
            setMicPlaybackUrl(audioUrl);
            setChecks(prev => ({ ...prev, microphone: true }));
            audioStream.getTracks().forEach(track => track.stop());
          };
          mediaRecorder.start();
          setTimeout(() => {
            if (mediaRecorder.state === "recording") mediaRecorder.stop();
          }, 3000); 
          break;
        case "speaker":
          const audio = new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZRA0PVqzn77BdGAg+ltryxnMpBSl+zPLaizsIGGS57OihUBELTKXh8bllHgU2jdXzzn0vBSF1xe/glEILElyx6OyrWBUIQ5zd8sFuJAUuhM/z1YU2Bhxqvu7mnEYODlOq5O+zYBoGPJPY88p2KwUme8rx3I4+CRZiturqpVITC0mi4PK8aB8GM4nU8tGAMQYfcsLu45ZFDBFYr+ftrVoXCECY3PLEcSYELIHO8diJOQgZaLvt559NEAxPqOPwtmMcBjiP1/PMeS0GI3fH8N2RQAoUXrTp66hVFApGnt/yvmwhBTCG0fPTgjQGHW/A7eSaRQ0PVqzl77BeGQc+ltrzxnUoBSh+zPDaizsIGGS56+mjTxELTKXh8bllHgU1jdT0z3wvBSJ0xe/glEILElyx6OyrWRUIRJve8sFuJAUug8/y1oU2Bhxqvu3mnUYODlOq5O+zYRsGPJLZ88p3KgUme8rx3I4+CRVht+rqpVMSC0mh4fK8aiAFM4nU8tGAMQYfccPu45ZFDBFYr+ftrVwWCECY3PLEcSYGK4DN8tiIOQgZZ7zs56BODwxPp+PxtmQcBjiP1/PMeywGI3fH8N+RQAoUXrTp66hWEwlGnt/yv2wiBDCG0fPTgzQHHG/A7eSaSw0PVqzl77BeGQc+ltvyxnUoBSh9y/HajDsIF2W56+mjUREKTKPi8blnHgU1jdTy0HwvBSJ0xPDglEQKElux6eyrWRUJQ5vd88FwJAQug8/y1oY2Bhxqvu3mnUYODlKp5e+zYRsGOpPY88p3KgUmecnw3Y4/CBVht+rqpVMSC0mh4fK9aiAFM4nS89GAMQYfccLv45dGCxFYrufur1sYB0CY3PLEcSYGK4DN8tiIOQgZZ7vt56BODwxPp+PxtmQdBTiP1/PMeywGI3bH8d+RQQkUXrTp66hWEwlGnt/yv2wiBDCG0fPTgzQHHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3Bhxqvu3mnUYODlKp5e+zYRsGOpPY88p3KwUlecnw3Y8/CBVht+rqpVMSC0mh4fK9aiAFMojT89GBMgUfccLv45dGDBBYrufur1sYB0CX3fLEcicFKoDN8tiKOQgZZ7vt56BODwxPp+PxtmQdBTeP1/PMey0FI3bH8d+RQQsUXbPq66hWEwlGnt/yv2wiBDCG0fPTgzUGHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3Bhxqvu3mnUgNDlKp5e+zYRsGOpPY88p3KwUlecnw3Y8/CBVht+rqpVMSC0mh4fK9aiAFMojT89GBMgUfccLv45dGDBBYrufur1sYB0CX3fLEcicFKoDN8tiKOQgZZ7vt56BODwxPp+PxtmQdBTeP1/PMey0FI3bH8d+RQQsUXbPq66hWFAlEnt/yv2wiBDCG0fPTgzUGHG3A7uSaSw0PVKzm77BeGQc+ltrzyHQpBSh9y/HajDwIF2S46+qkUBALTKPi8blnHwU1jdTy0H4wBSF0xPDglEQKElux6eyrWRUJQ5vd88FwJAUtg8/y1oY3BhxpvuzmnnsPGy4=");
          audio.setAttribute("aria-label", "Speaker test sound");
          await audio.play();
          setChecks(prev => ({ ...prev, speaker: true }));
          break;
        default:
          break;
      }
    } catch (error) {
      console.error(error);
      setChecks(prev => ({ ...prev, [device]: false }));
      toast({
        title: "Device Check Failed",
        description: `Unable to access ${device}. Please check browser permissions and ensure no other app is using it.`,
        variant: "destructive",
        duration: 9000,
      });
    }
  };

  React.useEffect(() => {
    if (checks.camera === true && checks.microphone === true && checks.speaker === true) {
      onComplete(true);
    }
  }, [checks, onComplete]);
  
  React.useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    }
  }, [stream]);

  const CheckItem = ({ deviceName, status, onTest, icon, children, testId }) => (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-slate-700 rounded-lg border border-slate-600">
      <div className="flex items-center space-x-3 mb-2 sm:mb-0">
        {React.cloneElement(icon, {'aria-hidden': true})}
        <span className="text-slate-200" id={`${testId}-label`}>{deviceName}</span>
      </div>
      <div className="flex items-center space-x-2 self-end sm:self-center">
        {status === 'testing' && <span className="text-xs text-sky-400 italic" aria-live="polite">Testing {deviceName}...</span>}
        {status === true && <CheckCircle className="w-6 h-6 text-green-400" aria-hidden="true" />}
        {status === false && <XCircle className="w-6 h-6 text-red-400" aria-hidden="true" />}
        {(status === null || status === false) && (
          <Button 
            onClick={onTest} 
            variant="outline" 
            size="sm" 
            className="text-sky-400 border-sky-400 hover:bg-sky-400 hover:text-slate-900"
            aria-labelledby={`${testId}-label`}
            aria-describedby={status === false ? `${testId}-error` : undefined}
          >
            Test
          </Button>
        )}
      </div>
      {children && <div className="w-full mt-2 sm:mt-0 sm:ml-4 sm:flex-1">{children}</div>}
    </div>
  );

  return (
    <motion.section
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-lg mx-auto bg-slate-800 rounded-xl shadow-2xl p-4 sm:p-6 md:p-8 border border-slate-700"
      aria-labelledby="device-check-title"
    >
      <h1 id="device-check-title" className="text-2xl sm:text-3xl font-bold text-sky-400 mb-6 sm:mb-8 text-center">
        Device Check
      </h1>
      <p className="text-slate-400 mb-6 text-center text-sm sm:text-base">Let's make sure your equipment is ready for the interview.</p>

      <div className="space-y-4 sm:space-y-6">
        <CheckItem deviceName="Camera" status={checks.camera} onTest={() => runDeviceCheck("camera")} icon={<Video className="w-5 h-5 sm:w-6 sm:h-6 text-sky-400" />} testId="camera-check">
          {(checks.camera === 'testing' || checks.camera === true) && (
            <div className="w-full mt-2 aspect-video bg-slate-600 rounded overflow-hidden flex items-center justify-center" aria-live="polite">
              {stream ? (
                 <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover transform scaleX(-1)" aria-label="Camera preview"></video>
              ) : (
                <p className="text-slate-400 text-sm">Initializing camera...</p>
              )}
            </div>
          )}
           {checks.camera === true && <p className="text-xs text-green-400 w-full mt-1" aria-live="polite">Camera detected successfully!</p>}
           {checks.camera === false && <p id="camera-check-error" className="text-xs text-red-400 w-full mt-1" aria-live="assertive">Camera test failed. Try again or check permissions.</p>}
        </CheckItem>

        <CheckItem deviceName="Microphone" status={checks.microphone} onTest={() => runDeviceCheck("microphone")} icon={<Mic className="w-5 h-5 sm:w-6 sm:h-6 text-sky-400" />} testId="mic-check">
          {micPlaybackUrl && checks.microphone === true && (
            <div className="w-full mt-2" aria-live="polite">
              <p className="text-xs text-slate-300 mb-1">Listen to your recording:</p>
              <audio src={micPlaybackUrl} controls className="w-full h-10" aria-label="Microphone recording playback"></audio>
            </div>
          )}
          {checks.microphone === true && !micPlaybackUrl && <p className="text-xs text-green-400 w-full mt-1" aria-live="polite">Microphone detected. Playback will appear shortly.</p>}
          {checks.microphone === false && <p id="mic-check-error" className="text-xs text-red-400 w-full mt-1" aria-live="assertive">Microphone test failed. Try again or check permissions.</p>}
        </CheckItem>

        <CheckItem deviceName="Speaker" status={checks.speaker} onTest={() => runDeviceCheck("speaker")} icon={<Volume2 className="w-5 h-5 sm:w-6 sm:h-6 text-sky-400" />} testId="speaker-check">
          {checks.speaker === true && <p className="text-xs text-green-400 w-full mt-1" aria-live="polite">Speaker test sound played. Did you hear it?</p>}
          {checks.speaker === false && <p id="speaker-check-error" className="text-xs text-red-400 w-full mt-1" aria-live="assertive">Speaker test failed. Ensure volume is up and try again.</p>}
        </CheckItem>
      </div>

      <div className="mt-8 sm:mt-10 text-center" aria-live="polite">
        {Object.values(checks).every(s => s === true) ? (
          <motion.p initial={{opacity:0}} animate={{opacity:1}} className="text-green-400 font-semibold">All checks passed! You will be redirected shortly.</motion.p>
        ) : (
          <p className="text-sm text-slate-500">
            Please complete all device checks to proceed.
          </p>
        )}
      </div>
       {Object.values(checks).some(s => s === false) && (
         <div role="alert" className="mt-4 p-3 bg-yellow-900/30 border border-yellow-700 rounded-md text-yellow-300 text-xs sm:text-sm">
            <h3 className="font-semibold mb-1">Troubleshooting Tips:</h3>
            <ul className="list-disc list-inside space-y-1">
                <li>Ensure your browser has permission to access your camera and microphone.</li>
                <li>Check if other applications are using your camera/microphone.</li>
                <li>Make sure your devices are properly connected and selected in system settings.</li>
                <li>Try refreshing the page or restarting your browser.</li>
            </ul>
         </div>
       )}
    </motion.section>
  );
};

export default DeviceCheck;