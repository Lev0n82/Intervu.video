
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { getDeviceFingerprint } from '@/lib/deviceFingerprint';
import { rememberMeManager } from '@/lib/RememberMeManager';

/**
 * Validates invitations for both Teams and Participants.
 * Acts as a router guard / data fetcher before rendering children.
 */
const InvitationTokenValidator = ({ type = 'team', children }) => {
  const { token, submissionToken } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const location = useLocation();
  
  const [isValidating, setIsValidating] = useState(true);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const validate = async () => {
      const activeToken = token || submissionToken;

      if (!activeToken) {
        setError('No token provided');
        setIsValidating(false);
        return;
      }

      try {
        if (type === 'team') {
            // Check for "Remember Me" session first
            const fingerprint = await getDeviceFingerprint();
            const session = await rememberMeManager.validateSession(fingerprint);
            
            if (session?.valid) {
                 toast({ title: "Welcome back!", description: "Auto-logging you in..." });
                 // If we have a valid session, we might skip full validation or just redirect to dashboard
                 // However, we still need to process the invite if it hasn't been used.
            }

            // Validate Team Invitation
            const { data: invite, error: inviteError } = await supabase
                .from('team_invitations')
                .select('*, organizations(name)')
                .or(`token.eq.${activeToken},invitation_code.eq.${activeToken}`)
                .single();

            if (inviteError || !invite) {
                throw new Error('Invalid or expired invitation link.');
            }

            if (invite.status === 'accepted' && !session?.valid) {
                // Determine if we should redirect to login or dashboard based on auth state
                const { data: { session: authSession } } = await supabase.auth.getSession();
                if (authSession) {
                    navigate('/dashboard');
                    return;
                } else {
                    throw new Error('This invitation has already been used. Please log in.');
                }
            }

            if (new Date(invite.expires_at) < new Date()) {
                throw new Error('This invitation has expired. Please ask your administrator for a new one.');
            }

            setData(invite);
        } else if (type === 'participant') {
            // Validate Participant (Interview or Survey)
            // Determine sub-type based on route usually, but here we check both tables or specific param
            
            let targetRoute = '';
            
            // Check Interview Submission
            const { data: interviewSub, error: intError } = await supabase
                .from('interview_submissions')
                .select('*, interviews(*)')
                .eq('submission_token', activeToken)
                .single();

            if (interviewSub) {
                if (interviewSub.status === 'completed') {
                    throw new Error('This interview has already been completed.');
                }
                // Redirect logic handled in parent or here
                // For this component, we just pass data down or redirect
                if (location.pathname.includes('/device-check')) {
                     // We are already at the destination
                     setData({ type: 'interview', ...interviewSub });
                } else {
                     navigate(`/interview/device-check/${activeToken}`);
                     return;
                }
            } else {
                // Check Survey Invitation
                // Note: Surveys use 'token' usually
                const { data: surveyInvite, error: survError } = await supabase
                    .from('survey_invitations')
                    .select('*, surveys(*)')
                    .eq('token', activeToken)
                    .single();
                
                if (surveyInvite) {
                     if (surveyInvite.status === 'completed') {
                         throw new Error('This survey has already been completed.');
                     }
                     setData({ type: 'survey', ...surveyInvite });
                } else {
                     throw new Error('Invalid invitation token.');
                }
            }
        }
      } catch (err) {
        console.error("Validation Error:", err);
        setError(err.message);
        toast({
            variant: "destructive",
            title: "Invitation Error",
            description: err.message
        });
      } finally {
        setIsValidating(false);
      }
    };

    validate();
  }, [token, submissionToken, type, navigate, toast, location]);

  if (isValidating) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
        <p className="text-gray-500">Validating invitation...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4 text-center">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
            <h2 className="text-xl font-bold text-red-600 mb-2">Invitation Error</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <button 
                onClick={() => navigate('/')}
                className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90 transition-colors"
            >
                Return Home
            </button>
        </div>
      </div>
    );
  }

  // Clone children and inject data
  return React.Children.map(children, child => {
      if (React.isValidElement(child)) {
          return React.cloneElement(child, { invitationData: data });
      }
      return child;
  });
};

export default InvitationTokenValidator;
