
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Check, Copy } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';

const CopyableCode = ({ 
    code, 
    label = "Shareable Code", 
    description, 
    className,
    containerClassName 
}) => {
    const [copied, setCopied] = useState(false);
    const { toast } = useToast();

    const handleCopy = () => {
        if (!code) return;
        navigator.clipboard.writeText(code);
        setCopied(true);
        toast({
            title: "Copied to clipboard",
            description: "The code has been copied to your clipboard.",
            className: "bg-green-600 text-white border-green-700"
        });
        
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className={cn("space-y-2", containerClassName)}>
            {label && <Label>{label}</Label>}
            <div className={cn("flex items-center space-x-2", className)}>
                <div className="relative flex-1">
                    <div className="flex h-10 w-full rounded-md border border-input bg-muted/50 px-3 py-2 text-sm font-mono text-foreground shadow-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 items-center overflow-x-auto whitespace-nowrap">
                        {code}
                    </div>
                </div>
                <Button 
                    type="button" 
                    variant="outline" 
                    size="icon" 
                    onClick={handleCopy}
                    className="shrink-0"
                >
                    {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                </Button>
            </div>
            {description && (
                <p className="text-xs text-muted-foreground">
                    {description}
                </p>
            )}
        </div>
    );
};

export default CopyableCode;
