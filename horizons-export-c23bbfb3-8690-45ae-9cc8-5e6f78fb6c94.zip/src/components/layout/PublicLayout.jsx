import React from 'react';
import { Link, useNavigate, Outlet } from 'react-router-dom';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { LanguageToggle } from './LanguageToggle';
import { ThemeToggle } from './ThemeToggle';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { LayoutDashboard, LogOut, Settings } from 'lucide-react';
import { versionHistory } from '@/lib/versionHistory';
import LayoutHelmet from './LayoutHelmet';
import SkipToContent from '@/components/SkipToContent';

const PublicLayout = () => {
  const { t } = useTranslation();
  const { user, userProfile, signOut } = useAuth();
  const navigate = useNavigate();

  const getInitials = (name = '') => name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  
  const handleLogout = async () => {
    await signOut();
    navigate('/auth');
  };

  const homePath = user ? '/dashboard' : '/';
  const latestBuild = versionHistory.sort((a, b) => new Date(b.date) - new Date(a.date))[0];

  return (
    <>
      <LayoutHelmet />
      <SkipToContent />
      <div className="min-h-screen flex flex-col bg-background font-sans antialiased">
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60" role="banner">
          <div className="container flex h-14 items-center">
            <Link to={homePath} className="mr-6 flex items-center space-x-2" aria-label="Intervu.video Home">
              <Logo className="h-8 w-auto" aria-hidden="true" />
            </Link>
            <div className="flex flex-1 items-center justify-end space-x-2">
              <nav className="flex items-center space-x-2" aria-label="Main Navigation">
                {user ? (
                   <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="relative h-10 w-10 rounded-full" aria-label="User menu">
                           <Avatar className="h-9 w-9" aria-hidden="true">
                            <AvatarImage src={userProfile?.avatar_url} alt={userProfile?.full_name || 'User'} />
                            <AvatarFallback>{getInitials(userProfile?.full_name)}</AvatarFallback>
                          </Avatar>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56" align="end" forceMount>
                        <DropdownMenuLabel className="font-normal">
                            <p className="text-sm font-semibold leading-none">{userProfile?.full_name || 'User'}</p>
                            <p className="text-xs text-muted-foreground pt-1">{user.email}</p>
                        </DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to="/dashboard" className="cursor-pointer">
                            <LayoutDashboard className="w-4 h-4 mr-2" aria-hidden="true" />
                            <span>{t('mainLayout.nav.dashboard')}</span>
                          </Link>
                        </DropdownMenuItem>
                         <DropdownMenuItem asChild>
                          <Link to="/settings" className="cursor-pointer">
                            <Settings className="w-4 h-4 mr-2" aria-hidden="true" />
                            <span>{t('mainLayout.nav.settings')}</span>
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={handleLogout} className="text-red-400 focus:bg-red-900/50 focus:text-red-300 cursor-pointer">
                          <LogOut className="w-4 h-4 mr-2" aria-hidden="true" />
                          <span>{t('mainLayout.header.logout')}</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                ) : (
                  <>
                    <Button variant="ghost" asChild>
                      <Link to="/auth?tab=login">{t('publicLayout.header.signIn')}</Link>
                    </Button>
                    <Button asChild>
                      <Link to="/auth?tab=signup">{t('publicLayout.header.signUp')}</Link>
                    </Button>
                  </>
                )}
                <ThemeToggle />
                <LanguageToggle />
              </nav>
            </div>
          </div>
        </header>
        <main id="main-content" className="flex-1" tabIndex="-1">
          <Outlet />
        </main>
        <footer className="bg-background/95 border-t border-border/40" role="contentinfo">
          <div className="container py-8 text-muted-foreground text-sm">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center mb-6">
              <div role="navigation" aria-label="Product Links">
                <p className="font-bold text-foreground mb-2">{t('publicLayout.footer.product')}</p>
                <nav className="flex flex-col gap-1">
                  <Link to="/requirements" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.requirements')}</Link>
                  <Link to="/user-stories" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.userStories')}</Link>
                  <Link to="/feature-status" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.featureStatus')}</Link>
                </nav>
              </div>
              <div role="navigation" aria-label="Company Links">
                <p className="font-bold text-foreground mb-2">{t('publicLayout.footer.company')}</p>
                <nav className="flex flex-col gap-1">
                  <Link to="/about-us" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.aboutUs')}</Link>
                  <Link to="/technical-details" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.technicalDetails')}</Link>
                </nav>
              </div>
              <div role="navigation" aria-label="Legal Links">
                <p className="font-bold text-foreground mb-2">{t('publicLayout.footer.legal')}</p>
                <nav className="flex flex-col gap-1">
                  <Link to="/terms-and-conditions" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.terms')}</Link>
                  <Link to="/privacy-policy" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.privacy')}</Link>
                  <Link to="/modern-slavery-statement" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.slaveryStatement')}</Link>
                </nav>
              </div>
              <div role="navigation" aria-label="Compliance Links">
                <p className="font-bold text-foreground mb-2">{t('publicLayout.footer.compliance')}</p>
                <nav className="flex flex-col gap-1">
                  <Link to="/environmental-policy" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.environmental')}</Link>
                  <Link to="/accessibility-compliance" className="hover:text-primary focus-visible:text-primary">{t('publicLayout.footer.accessibility')}</Link>
                </nav>
              </div>
            </div>
            <div className="mt-6 text-center">
              <p>
                <span className="font-bold">intervu.video</span> &copy; {new Date().getFullYear()}. {t('publicLayout.footer.copyright')}
              </p>
              {latestBuild && (
                <p className="text-xs mt-2">
                  <Link to="/version-history" className="hover:text-primary transition-colors">
                    Build: {latestBuild.build}
                  </Link>
                </p>
              )}
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default PublicLayout;