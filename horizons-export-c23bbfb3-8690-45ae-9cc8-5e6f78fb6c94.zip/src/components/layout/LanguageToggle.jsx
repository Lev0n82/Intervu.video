import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';

export function LanguageToggle() {
  const { i18n } = useTranslation();

  const handleLanguageChange = () => {
    const newLang = i18n.language === 'en' ? 'fr' : 'en';
    i18n.changeLanguage(newLang);
  };

  const buttonText = i18n.language === 'en' ? 'Français' : 'English';

  return (
    <Button
      variant="ghost"
      onClick={handleLanguageChange}
      aria-label={`Switch to ${buttonText}`}
      className="text-sm font-medium text-muted-foreground hover:text-foreground"
    >
      {buttonText}
    </Button>
  );
}