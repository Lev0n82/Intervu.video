import React from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import Logo from '@/components/Logo';
import { Toaster } from "@/components/ui/toaster";
import { LayoutDashboard, Info, LogOut, Menu, X, Building2, Mail, Users, FileText, Briefcase, ClipboardCheck, Settings, Video, PlusCircle, ChevronsUpDown, Shield } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuGroup, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { LanguageToggle } from './LanguageToggle';
import { ThemeToggle } from './ThemeToggle';
import { useTranslation } from 'react-i18next';
import LayoutHelmet from './LayoutHelmet';
import SkipToContent from '@/components/SkipToContent'; // Added Skip Link

const MainLayout = ({ children }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const { user, userProfile, activeOrganization, signOut, switchOrganization } = useAuth();
  const { t } = useTranslation();

  const handleLogout = async () => {
    await signOut();
    toast({ title: 'Logged Out', description: 'You have been successfully logged out.' });
    navigate('/auth', { replace: true });
  };

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  const getInitials = (name = '') => name?.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'U';

  const userRole = userProfile?.team_memberships?.find(m => m.organization_id === activeOrganization?.id)?.role?.name;
  const canCreateContent = userRole === 'Admin' || userRole === 'Manager';

  const navLinks = [
    { href: '/dashboard', label: t('mainLayout.nav.dashboard'), icon: LayoutDashboard, roles: ['Admin', 'Manager', 'Interviewer', 'Coordinator'] },
    { href: '/interviews', label: t('mainLayout.nav.interviews'), icon: Briefcase, roles: ['Admin', 'Manager', 'Interviewer', 'Coordinator'] },
    { href: '/templates', label: t('mainLayout.nav.templates'), icon: FileText, roles: ['Admin', 'Manager', 'Interviewer'] },
    { href: '/surveys', label: t('mainLayout.nav.surveys'), icon: ClipboardCheck, roles: ['Admin', 'Manager'] },
    { href: '/team', label: t('mainLayout.nav.team'), icon: Users, roles: ['Admin', 'Manager'] },
    { href: '/reports', label: t('mainLayout.nav.reports'), icon: LayoutDashboard, roles: ['Admin', 'Manager'] },
    { href: '/personas', label: t('mainLayout.nav.personas'), icon: Users, roles: ['Admin', 'Manager', 'Interviewer'] },
    { href: '/organization', label: t('mainLayout.nav.organization'), icon: Building2, roles: ['Admin'] },
  ];

  const filteredNavLinks = navLinks.filter(link => link.roles.includes(userRole));

  return (
    <>
      <LayoutHelmet />
      <SkipToContent />
      <div className="flex min-h-screen w-full bg-transparent text-foreground">
          <aside className="w-64 flex-col border-r border-border/40 bg-background/60 backdrop-blur-md p-4 hidden md:flex" aria-label="Sidebar Navigation">
            <div className="p-4 mb-4">
                <Link to="/dashboard" aria-label="Go to Dashboard"><Logo /></Link>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full justify-between mb-4" aria-label={`Switch Organization, currently selected: ${activeOrganization?.name || 'None'}`}>
                  <span className="truncate pr-2">{activeOrganization?.name || 'No Organization'}</span>
                  <ChevronsUpDown className="h-4 w-4 opacity-50" aria-hidden="true"/>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                  <DropdownMenuLabel>{t('mainLayout.header.organizations')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {userProfile?.team_memberships?.map(membership => (
                      <DropdownMenuItem key={membership.organization_id} onSelect={() => switchOrganization(membership.organization)}>
                          {membership.organization.name}
                      </DropdownMenuItem>
                  ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <nav className="flex flex-col space-y-2 flex-grow">
                {filteredNavLinks.map(link => {
                    const isActive = location.pathname.startsWith(link.href);
                    return (
                        <Button
                            key={link.href}
                            asChild
                            variant={isActive ? 'secondary' : 'ghost'}
                            className="justify-start"
                            aria-current={isActive ? 'page' : undefined}
                        >
                            <Link to={link.href}>
                                <link.icon className="mr-2 h-4 w-4" aria-hidden="true" />
                                {link.label}
                            </Link>
                        </Button>
                    );
                })}
            </nav>

            <div className="mt-auto">
                <Button asChild variant="ghost" className="justify-start w-full">
                    <Link to="/accessibility-compliance">
                        <Shield className="mr-2 h-4 w-4" aria-hidden="true" />
                        {t('mainLayout.nav.accessibility')}
                    </Link>
                </Button>
                <Button asChild variant="ghost" className="justify-start w-full">
                    <Link to="/settings">
                        <Settings className="mr-2 h-4 w-4" aria-hidden="true" />
                        {t('mainLayout.nav.settings')}
                    </Link>
                </Button>
            </div>
          </aside>
        
          <div className="flex flex-col flex-1">
            <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border/40 bg-background/60 backdrop-blur-md px-4 sm:px-6" role="banner">
                {/* Mobile Nav Trigger */}
                <div className="md:hidden">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="icon" aria-label={t('mainLayout.header.toggleNav')}>
                                <Menu className="h-5 w-5" aria-hidden="true" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                            {filteredNavLinks.map(link => (
                                <DropdownMenuItem key={link.href} asChild>
                                    <Link to={link.href}>
                                        <link.icon className="mr-2 h-4 w-4" aria-hidden="true" />
                                        {link.label}
                                    </Link>
                                </DropdownMenuItem>
                            ))}
                             <DropdownMenuSeparator />
                             <DropdownMenuItem asChild><Link to="/accessibility-compliance"><Shield className="mr-2 h-4 w-4" aria-hidden="true"/>{t('mainLayout.nav.accessibility')}</Link></DropdownMenuItem>
                             <DropdownMenuItem asChild><Link to="/settings"><Settings className="mr-2 h-4 w-4" aria-hidden="true"/>{t('mainLayout.nav.settings')}</Link></DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>

                <div className="flex-1 justify-end flex items-center gap-4">
                    {canCreateContent && (
                      <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                              <Button aria-label={t('mainLayout.header.createNew')}>
                                  <PlusCircle className="h-4 w-4 mr-2" aria-hidden="true" />
                                  {t('mainLayout.header.createNew')}
                              </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-56">
                              <DropdownMenuLabel>{t('mainLayout.header.create')}</DropdownMenuLabel>
                              <DropdownMenuGroup>
                                  <DropdownMenuItem onSelect={() => navigate('/interviews/new')}>{t('mainLayout.header.newInterview')}</DropdownMenuItem>
                                  <DropdownMenuItem onSelect={() => navigate('/surveys/new')}>{t('mainLayout.header.newTextSurvey')}</DropdownMenuItem>
                                  <DropdownMenuItem onSelect={() => navigate('/surveys/video/new')}>{t('mainLayout.header.newVideoSurvey')}</DropdownMenuItem>
                              </DropdownMenuGroup>
                          </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                    <LanguageToggle />
                    <ThemeToggle />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="relative h-8 w-8 rounded-full" aria-label="User menu">
                                <Avatar aria-hidden="true">
                                    <AvatarImage src={userProfile?.avatar_url} alt={userProfile?.full_name} />
                                    <AvatarFallback>{getInitials(userProfile?.full_name)}</AvatarFallback>
                                </Avatar>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-64">
                            <DropdownMenuLabel>
                                <p className="font-semibold">{userProfile?.full_name}</p>
                                <p className="text-xs text-muted-foreground font-normal">{user.email}</p>
                            </DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem asChild><Link to="/settings"><Settings className="mr-2 h-4 w-4" aria-hidden="true" />{t('mainLayout.header.accountSettings')}</Link></DropdownMenuItem>
                            <DropdownMenuItem asChild><Link to="/diagnostics/video"><Video className="mr-2 h-4 w-4" aria-hidden="true" />{t('mainLayout.header.videoDiagnostics')}</Link></DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500 focus:bg-destructive/10">
                                <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                                {t('mainLayout.header.logout')}
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </header>
            
            <main id="main-content" className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8" tabIndex="-1">
                <motion.div
                    key={location.pathname}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                >
                    <Outlet />
                    {children}
                </motion.div>
            </main>
            <Toaster />
        </div>
      </div>
    </>
  );
};

export default MainLayout;