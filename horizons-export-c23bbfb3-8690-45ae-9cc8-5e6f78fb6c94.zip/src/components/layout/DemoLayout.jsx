import React from 'react';
    import { Link, useLocation, useNavigate, Outlet } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Home, Users, Settings, Briefcase, ChevronsUpDown, ClipboardCheck, FileText, PlusCircle, Shield, LogIn, Menu, Video, Bot } from 'lucide-react';
    import { useTranslation } from 'react-i18next';
    import { Button } from '@/components/ui/button';
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuGroup } from '@/components/ui/dropdown-menu';
    import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
    import { ThemeToggle } from './ThemeToggle';
    import { LanguageToggle } from './LanguageToggle';
    import Logo from '@/components/Logo';
    import LayoutHelmet from './LayoutHelmet';

    const DemoLayout = () => {
        const location = useLocation();
        const navigate = useNavigate();
        const { t } = useTranslation();

        const navLinks = [
            { href: '/demo/dashboard', label: t('mainLayout.nav.dashboard'), icon: Home },
            { href: '/demo/interviews', label: t('mainLayout.nav.interviews'), icon: Briefcase },
            { href: '/demo/templates', label: t('mainLayout.nav.templates'), icon: FileText },
            { href: '/demo/surveys', label: t('mainLayout.nav.surveys'), icon: ClipboardCheck },
            { href: '/demo/team', label: t('mainLayout.nav.team'), icon: Users },
        ];

        const activeOrganization = { name: 'Demo Organization' };
        const userProfile = { full_name: 'Demo User', avatar_url: '' };

        return (
            <>
            <LayoutHelmet />
            <div className="flex min-h-screen w-full bg-transparent text-foreground">
                <aside className="w-64 flex-col border-r border-border/40 bg-background/60 backdrop-blur-md p-4 hidden md:flex">
                    <div className="p-4 mb-4">
                        <Link to="/demo/dashboard"><Logo /></Link>
                    </div>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="w-full justify-between mb-4">
                                <span className="truncate pr-2">{activeOrganization.name}</span>
                                <ChevronsUpDown className="h-4 w-4 opacity-50"/>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56">
                            <DropdownMenuLabel>{t('mainLayout.header.organizations')}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                {activeOrganization.name}
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <nav className="flex flex-col space-y-2 flex-grow">
                        {navLinks.map(link => {
                            const isActive = location.pathname.startsWith(link.href);
                            return (
                                <Button
                                    key={link.href}
                                    asChild
                                    variant={isActive ? 'secondary' : 'ghost'}
                                    className="justify-start"
                                >
                                    <Link to={link.href}>
                                        <link.icon className="mr-2 h-4 w-4" />
                                        {link.label}
                                    </Link>
                                </Button>
                            );
                        })}
                    </nav>
                     <div className="mt-auto">
                         <Button asChild variant="ghost" className="justify-start w-full">
                            <Link to="/accessibility-compliance">
                                <Shield className="mr-2 h-4 w-4" />
                                {t('mainLayout.nav.accessibility')}
                            </Link>
                        </Button>
                        <Button asChild variant="ghost" className="justify-start w-full">
                            <Link to="/settings">
                                <Settings className="mr-2 h-4 w-4" />
                                {t('mainLayout.nav.settings')}
                            </Link>
                        </Button>
                    </div>
                </aside>

                <div className="flex flex-col flex-1">
                    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border/40 bg-background/60 backdrop-blur-md px-4 sm:px-6">
                        <div className="md:hidden">
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline" size="icon">
                                        <Menu className="h-5 w-5" />
                                        <span className="sr-only">{t('mainLayout.header.toggleNav')}</span>
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start">
                                    {navLinks.map(link => (
                                        <DropdownMenuItem key={link.href} asChild>
                                            <Link to={link.href}><link.icon className="mr-2 h-4 w-4"/>{link.label}</Link>
                                        </DropdownMenuItem>
                                    ))}
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem asChild><Link to="/accessibility-compliance"><Shield className="mr-2 h-4 w-4"/>{t('mainLayout.nav.accessibility')}</Link></DropdownMenuItem>
                                    <DropdownMenuItem asChild><Link to="/settings"><Settings className="mr-2 h-4 w-4"/>{t('mainLayout.nav.settings')}</Link></DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                         <div className="flex-1 justify-end flex items-center gap-4">
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button>
                                        <PlusCircle className="h-4 w-4 mr-2" />
                                        {t('mainLayout.header.createNew')}
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-56">
                                    <DropdownMenuLabel>{t('mainLayout.header.create')}</DropdownMenuLabel>
                                    <DropdownMenuGroup>
                                        <DropdownMenuItem onSelect={() => navigate('/demo/templates/new')}><Briefcase className="mr-2 h-4 w-4"/>{t('mainLayout.header.newInterview')}</DropdownMenuItem>
                                        <DropdownMenuItem onSelect={() => navigate('/demo/surveys/new')}><ClipboardCheck className="mr-2 h-4 w-4"/>{t('mainLayout.header.newTextSurvey')}</DropdownMenuItem>
                                        <DropdownMenuItem onSelect={() => navigate('/demo/surveys/video/new')}><Video className="mr-2 h-4 w-4"/>{t('mainLayout.header.newVideoSurvey')}</DropdownMenuItem>
                                    </DropdownMenuGroup>
                                </DropdownMenuContent>
                            </DropdownMenu>
                            <LanguageToggle />
                            <ThemeToggle />
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                                        <Avatar>
                                            <AvatarImage src={userProfile.avatar_url} alt="Demo User Avatar" />
                                            <AvatarFallback>D</AvatarFallback>
                                        </Avatar>
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-56">
                                    <DropdownMenuLabel>{userProfile.full_name}</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onSelect={() => navigate('/auth')}>
                                        <LogIn className="mr-2 h-4 w-4" />
                                        <span>Sign Up / Log In</span>
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                    </header>
                    
                    <div className="sticky top-16 z-10 bg-primary/90 text-primary-foreground text-center p-2 text-sm shadow-md backdrop-blur-sm">
                        You are in Demo Mode. <Link to="/auth" className="font-bold underline hover:text-white transition-colors">Sign up</Link> to save your work.
                    </div>

                    <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                        <motion.div
                            key={location.pathname}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.3 }}
                        >
                            <Outlet/>
                        </motion.div>
                    </main>
                </div>
            </div>
            </>
        );
    };

    export default DemoLayout;