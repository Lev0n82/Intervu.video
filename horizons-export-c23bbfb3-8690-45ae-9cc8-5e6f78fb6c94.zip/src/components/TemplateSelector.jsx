import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Layers } from 'lucide-react';

const TemplateSelector = ({ templates, onSelectTemplate }) => {
  if (!templates || templates.length === 0) {
    return null;
  }
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  };

  return (
    <Card>
        <CardHeader>
            <CardTitle className="flex items-center text-xl">
                <Layers className="mr-3 h-5 w-5 text-primary" />
                Start with a Template
            </CardTitle>
            <CardDescription>
                Choose a pre-made template to get started quickly. You can customize it after selecting.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
                {templates.map(template => {
                    const Icon = template.icon;
                    return (
                        <motion.div key={template.id} variants={itemVariants}>
                            <Card className="flex flex-col h-full hover:border-primary/80 transition-colors group">
                                <CardHeader className="flex-grow">
                                    <div className="flex items-center mb-2">
                                        <Icon className="w-6 h-6 mr-3 text-primary/80 group-hover:text-primary transition-colors"/>
                                        <CardTitle className="text-lg">{template.name}</CardTitle>
                                    </div>
                                    <CardDescription>{template.description}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Button className="w-full" variant="outline" onClick={() => onSelectTemplate(template)}>
                                        Use Template
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>
                    );
                })}
            </motion.div>
        </CardContent>
    </Card>
  );
};

export default TemplateSelector;