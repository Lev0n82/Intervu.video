import React, { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';

const GenerationTimer = ({ startTime, estimatedDuration = 120 }) => {
  const [timeLeft, setTimeLeft] = useState(estimatedDuration);

  useEffect(() => {
    const interval = setInterval(() => {
      const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
      const remaining = Math.max(0, estimatedDuration - elapsedSeconds);
      setTimeLeft(remaining);
      
      if (remaining <= 0) {
        // Just stay at 0 or show "Processing..."
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime, estimatedDuration]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center space-x-2 text-sm font-medium text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 px-3 py-1.5 rounded-full border border-amber-200 dark:border-amber-800">
      <Loader2 className="w-3 h-3 animate-spin" />
      <span>AI Video Generation Pending</span>
      <span className="font-mono bg-white dark:bg-black/20 px-1.5 rounded ml-1">
        {formatTime(timeLeft)}
      </span>
    </div>
  );
};

export default GenerationTimer;