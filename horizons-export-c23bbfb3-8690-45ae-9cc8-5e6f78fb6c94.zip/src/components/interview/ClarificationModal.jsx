
import React, { useRef, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const ClarificationModal = ({ open, onOpenChange, videoUrl, questionText, onComplete }) => {
    const videoRef = useRef(null);
    const [hasPlayed, setHasPlayed] = useState(false);

    const handleEnded = () => {
        setHasPlayed(true);
        // Optional: Auto-close after a delay? Or let user close.
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[700px] bg-slate-900 border-slate-800 text-slate-100">
                <DialogHeader>
                    <DialogTitle className="text-slate-100 mb-2">Clarification</DialogTitle>
                    <p className="text-sm text-slate-400">{questionText}</p>
                </DialogHeader>
                
                <div className="aspect-video bg-black rounded-lg overflow-hidden border border-slate-800 mt-4">
                    {videoUrl ? (
                        <video
                            ref={videoRef}
                            src={videoUrl}
                            className="w-full h-full object-contain"
                            controls
                            autoPlay
                            onEnded={handleEnded}
                        />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-500">
                            No clarification video available.
                        </div>
                    )}
                </div>

                <div className="flex justify-end mt-4">
                    <Button onClick={() => onOpenChange(false)}>
                        {hasPlayed ? "Return to Question" : "Close"}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ClarificationModal;
