
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Video, RefreshCw, Check } from 'lucide-react';
import VideoRecorder from '@/components/VideoRecorder';

const AnswerRecorder = ({ onAnswerSubmitted, isActive, bucketName = "template-videos", storagePath = "interview-responses" }) => {
    const [isRecorderOpen, setIsRecorderOpen] = useState(false);
    const [recordedData, setRecordedData] = useState(null);

    const handleRecordClick = () => {
        setIsRecorderOpen(true);
    };

    const handleUploadComplete = (data) => {
        setRecordedData(data);
        // We don't auto-submit here, user explicitly clicks "Submit Answer" on the main UI
        // Or we could auto-close recorder and show preview
    };

    const handleSubmit = () => {
        if (recordedData) {
            onAnswerSubmitted(recordedData);
        }
    };

    return (
        <div className="w-full flex flex-col items-center gap-4">
            {recordedData ? (
                <div className="w-full max-w-md space-y-4 animate-in fade-in zoom-in-95 duration-300">
                    <div className="aspect-video bg-black rounded-lg overflow-hidden border border-slate-700 shadow-lg relative group">
                        <video src={recordedData.url} className="w-full h-full object-cover" controls />
                        <div className="absolute top-2 right-2 bg-green-500/90 text-white text-xs px-2 py-1 rounded-md flex items-center shadow-sm">
                            <Check className="w-3 h-3 mr-1" /> Recorded
                        </div>
                    </div>
                    
                    <div className="flex gap-3 justify-center">
                        <Button 
                            variant="outline" 
                            onClick={handleRecordClick}
                            disabled={!isActive}
                            className="border-slate-600 hover:bg-slate-800 text-slate-300"
                        >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Retake
                        </Button>
                        <Button 
                            onClick={handleSubmit}
                            disabled={!isActive}
                            className="bg-green-600 hover:bg-green-700 text-white min-w-[140px]"
                        >
                            Submit Answer
                        </Button>
                    </div>
                </div>
            ) : (
                <Button 
                    size="lg" 
                    onClick={handleRecordClick}
                    disabled={!isActive}
                    className="h-16 px-8 rounded-full text-lg bg-red-600 hover:bg-red-700 shadow-lg shadow-red-900/20 hover:scale-105 transition-all"
                >
                    <Video className="w-6 h-6 mr-2" />
                    Record Answer
                </Button>
            )}

            <VideoRecorder 
                open={isRecorderOpen}
                onOpenChange={setIsRecorderOpen}
                onUploadComplete={handleUploadComplete}
                bucketName={bucketName}
                storagePath={storagePath}
            />
        </div>
    );
};

export default AnswerRecorder;
