
import React from 'react';
import { useInterviewState } from '@/hooks/useInterviewState';
import IntroductionSection from './IntroductionSection';
import QuestionDisplay from './QuestionDisplay';
import ReviewAnswers from './ReviewAnswers';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ParticipantInterviewFlow = ({ interviewData, submissionToken, submissionId }) => {
    const navigate = useNavigate();
    const { 
        currentState, 
        currentQuestion, 
        currentQuestionIndex, 
        totalQuestions,
        answers,
        introductionWatched,
        videoPlayCounts,
        clarificationCounts,
        isSubmitting,
        actions 
    } = useInterviewState(interviewData, submissionId);

    const questions = interviewData?.interviews?.interview_templates?.template_questions || [];
    const introductionVideoUrl = interviewData?.interviews?.interview_templates?.introduction_video_url;

    const handleAnswerSubmitted = (data) => {
        actions.submitAnswer(currentQuestion.id, data);
        actions.moveToNextQuestion();
    };

    const handleComplete = async () => {
        const result = await actions.completeInterview(submissionToken);
        if (result.success) {
             // Redirect handled in parent usually, or we show a success screen here
             // Using currentState 'completed' for now
        }
    };

    if (currentState === 'completed') {
        return (
             <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 animate-in fade-in zoom-in-95 duration-500">
                <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center">
                    <div className="w-10 h-10 border-4 border-green-500 rounded-full border-t-transparent animate-[spin_3s_linear_infinite]" />
                </div>
                <h1 className="text-3xl font-bold text-white">Interview Submitted!</h1>
                <p className="text-slate-400">Thank you for your time. You may now close this window.</p>
                <button onClick={() => window.close()} className="text-blue-400 hover:underline">Close Window</button>
            </div>
        );
    }
    
    if (isSubmitting) {
         return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-slate-400">
                <Loader2 className="w-10 h-10 animate-spin mb-4 text-blue-500" />
                <p>Submitting your interview...</p>
            </div>
        );
    }

    return (
        <div className="w-full max-w-5xl mx-auto px-4 py-8">
            <AnimatePresence mode="wait">
                {currentState === 'introduction' && (
                    <motion.div 
                        key="intro"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                    >
                        <IntroductionSection 
                            videoUrl={introductionVideoUrl}
                            watched={introductionWatched}
                            onWatched={actions.markIntroductionWatched}
                            onStart={actions.startQuestions}
                        />
                    </motion.div>
                )}

                {currentState === 'questions' && currentQuestion && (
                    <motion.div 
                        key={`q-${currentQuestion.id}`}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                    >
                        <QuestionDisplay 
                            question={currentQuestion}
                            index={currentQuestionIndex}
                            total={totalQuestions}
                            onAnswerSubmitted={handleAnswerSubmitted}
                            trackVideoPlay={actions.trackVideoPlay}
                            trackClarification={actions.trackClarificationUsage}
                            videoPlayCount={videoPlayCounts[`${currentQuestion.id}_question`] || 0}
                            clarificationUsed={clarificationCounts[currentQuestion.id] || 0}
                        />
                    </motion.div>
                )}

                {currentState === 'review' && (
                    <motion.div 
                        key="review"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                    >
                        <ReviewAnswers 
                            questions={questions}
                            answers={answers}
                            onComplete={handleComplete}
                        />
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default ParticipantInterviewFlow;
