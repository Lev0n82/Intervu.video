
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, Eye, Trash2, Bot, Calendar, Clock, AlertTriangle, Cpu } from 'lucide-react';
import { Button } from './ui/button';
import { format, differenceInSeconds } from 'date-fns';
import { processVideoQueue } from '@/lib/queueProcessor';

const VideoGenerationQueue = () => {
    const { activeOrganization } = useAuth();
    const { toast } = useToast();
    const [queue, setQueue] = useState([]);
    const [loading, setLoading] = useState(true);
    const [elapsedTimes, setElapsedTimes] = useState({});
    const processorInterval = useRef(null);

    const fetchQueue = useCallback(async (showLoading = false) => {
        if (!activeOrganization?.id) {
            setLoading(false);
            return;
        }
        if (showLoading) setLoading(true);
        try {
            const { data, error } = await supabase
                .from('video_generation_queue')
                .select('*')
                .eq('organization_id', activeOrganization.id)
                .order('created_at', { ascending: false });

            if (error) throw error;
            setQueue(data);
        } catch (error) {
            console.error("Fetch queue error:", error);
            toast({ title: "Error fetching queue", description: error.message, variant: "destructive" });
        } finally {
            if (showLoading) setLoading(false);
        }
    }, [activeOrganization, toast]);

    // Initial fetch, Polling, and Processor
    useEffect(() => {
        fetchQueue(true);
        
        // 1. Realtime Subscription
        let channel = null;
        if (activeOrganization?.id) {
            channel = supabase
                .channel('video-queue-updates')
                .on(
                    'postgres_changes',
                    {
                        event: '*',
                        schema: 'public',
                        table: 'video_generation_queue',
                        filter: `organization_id=eq.${activeOrganization.id}`
                    },
                    (payload) => {
                        console.log('Realtime update received:', payload.eventType);
                        fetchQueue(false); 
                    }
                )
                .subscribe();
        }

        // 2. Queue Processor (Polling Background Job)
        // Runs every 10 seconds to pick up pending items and check status
        processorInterval.current = setInterval(() => {
            if (activeOrganization?.id) {
                processVideoQueue(activeOrganization.id);
                // Also refresh list periodically to ensure sync if realtime fails
                fetchQueue(false);
            }
        }, 10000);

        return () => {
            if (channel) supabase.removeChannel(channel);
            if (processorInterval.current) clearInterval(processorInterval.current);
        };
    }, [fetchQueue, activeOrganization]);

    // Timer for elapsed time display
    useEffect(() => {
        const timer = setInterval(() => {
            const now = new Date();
            const newTimes = {};
            
            queue.forEach(item => {
                const created = new Date(item.created_at);
                const seconds = differenceInSeconds(now, created);
                
                const h = Math.floor(seconds / 3600);
                const m = Math.floor((seconds % 3600) / 60);
                const s = seconds % 60;
                
                let timeString = '';
                if (h > 0) timeString += `${h}h `;
                if (m > 0 || h > 0) timeString += `${m}m `;
                timeString += `${s}s`;
                
                newTimes[item.id] = timeString;
            });
            
            setElapsedTimes(newTimes);
        }, 1000);

        return () => clearInterval(timer);
    }, [queue]);


    const getStatusVariant = (status) => {
        switch (status) {
            case 'completed': return 'success'; // mapped to green in UI usually, or use custom class
            case 'processing': return 'default'; // blue/primary
            case 'failed': return 'destructive'; // red
            case 'queued': return 'warning'; // yellow/orange
            default: return 'secondary';
        }
    };
    
    // Custom badge colors since variant might not cover all
    const getStatusBadgeClass = (status) => {
        switch (status) {
            case 'completed': return 'bg-green-100 text-green-800 hover:bg-green-200 border-green-200';
            case 'processing': return 'bg-blue-100 text-blue-800 hover:bg-blue-200 border-blue-200 animate-pulse';
            case 'failed': return 'bg-red-100 text-red-800 hover:bg-red-200 border-red-200';
            case 'queued': return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-yellow-200';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const handleRetry = async (id) => {
        try {
            await supabase
                .from('video_generation_queue')
                .update({ status: 'queued', error_message: null, progress: 0 })
                .eq('id', id);
            
            toast({ title: "Retrying", description: "Task requeued successfully." });
            fetchQueue(false);
        } catch (e) {
            toast({ title: "Retry Failed", description: e.message, variant: "destructive" });
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Are you sure you want to remove this task?")) return;
        try {
            await supabase.from('video_generation_queue').delete().eq('id', id);
            toast({ title: "Deleted", description: "Task removed from queue." });
            setQueue(prev => prev.filter(i => i.id !== id));
        } catch (e) {
            toast({ title: "Delete Failed", description: e.message, variant: "destructive" });
        }
    };

    const formatDate = (dateString) => {
        try {
            return format(new Date(dateString), 'MMM dd HH:mm');
        } catch (e) {
            return dateString;
        }
    };
    
    // Determine provider label
    const getProviderLabel = (item) => {
        const provider = item.metadata?.provider || 'luma';
        return provider === 'fallai' ? 'Fall.ai' : 'Luma';
    };

    return (
        <Card className="h-full flex flex-col max-h-[600px] shadow-md">
            <CardHeader className="flex flex-row items-center justify-between pb-2 bg-slate-50/50 border-b">
                <div>
                    <CardTitle className="flex items-center text-lg"><Bot className="mr-2 h-5 w-5 text-indigo-600" aria-hidden="true"/>Generation Queue</CardTitle>
                    <CardDescription>Real-time status of AI video tasks.</CardDescription>
                </div>
                <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => fetchQueue(true)} disabled={loading} aria-label="Refresh">
                        <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="flex-grow overflow-auto p-0">
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow className="bg-slate-50">
                                <TableHead className="w-[45%]">Task</TableHead>
                                <TableHead className="w-[15%]">Status</TableHead>
                                <TableHead className="w-[20%] text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading && queue.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center h-32">
                                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                                            <Loader2 className="w-6 h-6 animate-spin mb-2 text-indigo-500" />
                                            <span>Syncing queue...</span>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ) : queue.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center h-32 text-muted-foreground">
                                        <div className="flex flex-col items-center justify-center opacity-60">
                                            <Bot className="w-8 h-8 mb-2" />
                                            <span>No active generation tasks.</span>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                queue.map(item => (
                                    <TableRow key={item.id} className="group hover:bg-slate-50/50 transition-colors">
                                        <TableCell>
                                            <div className="flex flex-col gap-1.5">
                                                <div className="flex items-center gap-2">
                                                    <Badge variant="outline" className="text-[10px] h-5 px-1.5 bg-slate-100 text-slate-600 border-slate-200">
                                                        <Cpu className="w-3 h-3 mr-1"/>
                                                        {getProviderLabel(item)}
                                                    </Badge>
                                                    <span className="font-medium text-sm truncate max-w-[140px]" title={item.prompt}>
                                                        {item.prompt || "No prompt provided"}
                                                    </span>
                                                </div>
                                                
                                                <div className="flex items-center text-xs text-muted-foreground gap-3">
                                                    <span className="flex items-center" title="Created At">
                                                        <Calendar className="w-3 h-3 mr-1 opacity-70"/>
                                                        {formatDate(item.created_at)}
                                                    </span>
                                                    <span className="flex items-center font-mono" title="Time Elapsed">
                                                        <Clock className="w-3 h-3 mr-1 opacity-70"/>
                                                        {elapsedTimes[item.id] || '0s'}
                                                    </span>
                                                </div>

                                                {(item.status === 'processing' || item.status === 'queued') && (
                                                   <div className="w-full max-w-[200px] mt-1">
                                                        <Progress value={item.status === 'processing' ? 60 : 10} className="h-1" />
                                                   </div>
                                                )}
                                                
                                                {item.error_message && (
                                                    <div className="flex items-start text-xs text-red-600 mt-1 bg-red-50 p-1.5 rounded">
                                                        <AlertTriangle className="w-3 h-3 mr-1 shrink-0 mt-0.5" />
                                                        <span className="leading-tight">{item.error_message}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant="outline" className={`${getStatusBadgeClass(item.status)} capitalize whitespace-nowrap`}>
                                                {item.status === 'processing' && <Loader2 className="w-3 h-3 mr-1 animate-spin"/>}
                                                {item.status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                {item.status === 'completed' && item.generated_video_url && (
                                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-indigo-600 hover:bg-indigo-50" onClick={() => window.open(item.generated_video_url, '_blank')}>
                                                        <Eye className="w-4 h-4" />
                                                    </Button>
                                                )}
                                                
                                                {item.status === 'failed' && (
                                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-orange-600 hover:bg-orange-50" onClick={() => handleRetry(item.id)} title="Retry Task">
                                                        <RefreshCw className="w-4 h-4" />
                                                    </Button>
                                                )}

                                                <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-red-600 hover:bg-red-50" onClick={() => handleDelete(item.id)} title="Delete Task">
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
};

export default VideoGenerationQueue;
