import {
        Toast,
        ToastClose,
        ToastDescription,
        ToastProvider,
        ToastTitle,
        ToastViewport,
    } from '@/components/ui/toast';
    import { useToast } from '@/components/ui/use-toast';
    import React from 'react';

    export function Toaster() {
        const { toasts } = useToast();

        return (
            <ToastProvider>
                {toasts.map(({ id, title, description, action, ...props }) => {
                    const titleId = title ? `toast-${id}-title` : undefined;
                    const descriptionId = description ? `toast-${id}-description` : undefined;
                    return (
                        <Toast key={id} {...props} aria-labelledby={titleId} aria-describedby={descriptionId}>
                            <div className="grid gap-1">
                                {title && <ToastTitle id={titleId}>{title}</ToastTitle>}
                                {description && (
                                    <ToastDescription id={descriptionId}>{description}</ToastDescription>
                                )}
                            </div>
                            {action}
                            <ToastClose />
                        </Toast>
                    );
                })}
                <ToastViewport />
            </ToastProvider>
        );
    }