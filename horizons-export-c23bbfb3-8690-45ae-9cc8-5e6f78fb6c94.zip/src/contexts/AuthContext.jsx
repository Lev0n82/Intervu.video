import React, { useState, useEffect, createContext, useContext, useCallback } from "react";
import { supabase } from '@/lib/supabaseClient';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);

  const fetchUserProfileAndSetUser = useCallback(async (authUser, isInitialSignIn = false) => {
    let teamMembership = null;
    let profile = null;

    const { data: profileData, error: profileError } = await supabase
      .from('users')
      .select('*')
      .eq('id', authUser.id)
      .maybeSingle();
    if (profileError) console.error("Error fetching public user profile:", profileError.message);
    profile = profileData;

    const fetchTeamMembership = async () => {
      const { data, error } = await supabase
        .from('team_members')
        .select('*, roles(name), organizations(id, name)')
        .eq('user_id', authUser.id)
        .limit(1)
        .maybeSingle();
      if (error) {
        console.warn("Error fetching team membership:", error.message);
        return { data: null, error };
      }
      return { data, error: null };
    };

    if (isInitialSignIn) {
      const retries = 8;
      const delay = 1500;
      for (let i = 0; i < retries; i++) {
        const { data } = await fetchTeamMembership();
        if (data) {
          teamMembership = data;
          break;
        }
        if (i < retries - 1) {
          await new Promise(res => setTimeout(res, delay));
        } else {
          console.error("Failed to fetch team membership after multiple retries. User might not have correct permissions.");
        }
      }
    } else {
      const { data } = await fetchTeamMembership();
      teamMembership = data;
    }

    const fullUser = {
      ...authUser,
      ...(profile || {}),
      full_name: profile?.full_name || authUser.user_metadata?.full_name,
      avatar_url: profile?.avatar_url || authUser.user_metadata?.avatar_url,
      roles: (teamMembership && teamMembership.roles) ? teamMembership.roles : { name: 'Candidate' },
      organizations: teamMembership?.organizations || null,
      team_member_id: teamMembership?.id || null,
    };

    setUser(fullUser);
    setLoading(false);
  }, []);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session: currentSession } } = await supabase.auth.getSession();
      setSession(currentSession);
      if (currentSession?.user) {
        await fetchUserProfileAndSetUser(currentSession.user, false);
      } else {
        setLoading(false);
      }
    };
    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      const isInitialSignIn = _event === 'SIGNED_IN' && !session;
      setSession(newSession);
      if (newSession?.user) {
        await fetchUserProfileAndSetUser(newSession.user, isInitialSignIn);
      } else {
        setUser(null);
        setLoading(false);
      }
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, [fetchUserProfileAndSetUser, session]);

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    if (error) {
      console.warn('Logout error:', error.message);
    }
  };

  const value = { user, session, loading, logout };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};