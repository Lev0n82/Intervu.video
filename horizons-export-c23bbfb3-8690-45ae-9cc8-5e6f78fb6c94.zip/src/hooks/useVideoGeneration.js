
import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { processVideoQueue } from '@/lib/queueProcessor';
import logger from '@/lib/logger';

export const useVideoGeneration = (activeOrganizationId, onGenerationComplete) => {
  const [generations, setGenerations] = useState({});
  const { toast } = useToast();
  const pollingInterval = useRef(null);
  
  // Track bulk operations to send notifications
  const [activeQueueGroup, setActiveQueueGroup] = useState(null);

  // Helper to construct a unique key for tracking
  const getKey = (questionId, field) => `${questionId}-${field}`;

  const handleError = (error, defaultMsg) => {
      logger.error(defaultMsg, error);
      toast({ 
          title: "Generation Error", 
          description: error.message || defaultMsg, 
          variant: "destructive" 
      });
  };

  /**
   * Starts video generation with support for multiple providers.
   * options: { provider: 'luma' | 'fallai', duration, style, quality }
   */
  const startGenerationWithPersona = async (
      questionId, 
      field, 
      prompt, 
      userId, 
      templateQuestionId, 
      personaId = null,
      options = {}
  ) => {
       if (!activeOrganizationId) {
           toast({ title: "Configuration Error", description: "No active organization found.", variant: "destructive" });
           return;
       }
       if (!userId) {
           toast({ title: "Authentication Error", description: "You must be logged in.", variant: "destructive" });
           return;
       }
       if (!prompt || typeof prompt !== 'string' || prompt.trim() === '') {
           toast({ title: "Invalid Input", description: "Prompt cannot be empty.", variant: "destructive" });
           return;
       }

       const provider = options.provider || 'luma';
       const key = getKey(questionId, field);
       
       logger.video.request(prompt, { context: 'useVideoGeneration hook', questionId, field, provider });
      
      setGenerations(prev => ({
          ...prev,
          [key]: {
              status: 'pending',
              startTime: Date.now(),
              estimatedDuration: provider === 'fallai' ? 30 : 120, 
              prompt,
              questionId,
              field,
              provider,
              callbackFired: false
          }
      }));

      try {
        // 1. Insert into Queue with provider metadata
        const { data: queueData, error: dbError } = await supabase.from('video_generation_queue').insert({
            organization_id: activeOrganizationId,
            template_question_id: templateQuestionId || (String(questionId).startsWith('temp-') ? null : questionId),
            prompt: prompt.trim(),
            created_by: userId,
            status: 'queued',
            progress: 0,
            metadata: { // Store provider options here
                provider,
                duration: options.duration,
                style: options.style,
                quality: options.quality,
                personaId // Tracking persona context
            }
        }).select().single();

        if (dbError) throw dbError;
        
        const queueId = queueData.id;
        logger.info(`Video Queued successfully: ${queueId} (${provider})`);

        setGenerations(prev => ({
            ...prev,
            [key]: { ...prev[key], queueId }
        }));
        
        toast({ title: "Queued", description: `Video generation request sent to ${provider === 'fallai' ? 'Fall.ai' : 'Luma'}.` });

        // 2. Trigger Queue Processor Immediately (Optimistic Start)
        processVideoQueue(activeOrganizationId);

        // Start Polling for updates
        if (!pollingInterval.current) {
            pollingInterval.current = setInterval(checkQueueStatus, 5000);
        }

      } catch (error) {
        setGenerations(prev => {
            const next = { ...prev };
            delete next[key];
            return next;
        });
        handleError(error, "Failed to queue generation");
      }
  };

  const trackQueueCompletion = (queueIds, notificationDetails) => {
      setActiveQueueGroup({
          ids: queueIds,
          details: notificationDetails,
          completedIds: []
      });
      if (!pollingInterval.current) {
          pollingInterval.current = setInterval(checkQueueStatus, 5000);
      }
  };

  const checkQueueStatus = useCallback(async () => {
    if (!activeOrganizationId) return;

    processVideoQueue(activeOrganizationId);

    const activeKeys = Object.entries(generations)
      .filter(([_, gen]) => (gen.status === 'pending' || gen.status === 'processing' || gen.status === 'queued') && gen.queueId)
      .map(([key]) => key);
      
    let idsToCheck = activeKeys.map(key => generations[key].queueId);
    
    if (activeQueueGroup) {
        const pendingBulkIds = activeQueueGroup.ids.filter(id => !activeQueueGroup.completedIds.includes(id));
        idsToCheck = [...new Set([...idsToCheck, ...pendingBulkIds])];
    }

    if (idsToCheck.length === 0) {
      if (!activeQueueGroup) stopPolling();
      return;
    }

    try {
      const { data, error } = await supabase
        .from('video_generation_queue')
        .select('id, status, generated_video_url, error_message, prompt')
        .in('id', idsToCheck);

      if (error) throw error;

      if (data && data.length > 0) {
        // Update local state
        for (const item of data) {
             const keyEntry = Object.entries(generations).find(([_, val]) => val.queueId === item.id);
             if (keyEntry) {
                 const [key] = keyEntry;
                 if (item.status === 'completed') {
                      setGenerations(prev => ({
                          ...prev,
                          [key]: { ...prev[key], status: 'success', url: item.generated_video_url }
                      }));
                 } else if (item.status === 'failed') {
                      setGenerations(prev => ({
                          ...prev,
                          [key]: { ...prev[key], status: 'error', error: item.error_message }
                      }));
                 }
             }
        }

        // Update bulk group
        if (activeQueueGroup) {
            const newlyCompleted = data
                .filter(item => (item.status === 'completed' || item.status === 'failed') && activeQueueGroup.ids.includes(item.id))
                .map(item => item.id);
            
            if (newlyCompleted.length > 0) {
                setActiveQueueGroup(prev => {
                    const nextCompleted = [...new Set([...prev.completedIds, ...newlyCompleted])];
                    if (nextCompleted.length === prev.ids.length) {
                        supabase.functions.invoke('notify-video-generation-complete', { body: prev.details });
                        return null; 
                    }
                    return { ...prev, completedIds: nextCompleted };
                });
            }
        }
      }
    } catch (err) {
      logger.error("Polling error", err);
    }
  }, [generations, toast, activeOrganizationId, activeQueueGroup]);

  const stopPolling = useCallback(() => {
    if (pollingInterval.current) {
      clearInterval(pollingInterval.current);
      pollingInterval.current = null;
    }
  }, []);

  useEffect(() => {
    return () => stopPolling();
  }, [stopPolling]);
  
  useEffect(() => {
    Object.keys(generations).forEach(key => {
        const gen = generations[key];
        if (gen.status === 'success' && !gen.callbackFired) {
             logger.video.success(gen.queueId, gen.url);
             setGenerations(prev => ({
                 ...prev,
                 [key]: { ...prev[key], callbackFired: true }
             }));
             if (onGenerationComplete) {
                 onGenerationComplete(gen.questionId, gen.field, gen.url);
             }
        }
    });
  }, [generations, onGenerationComplete]);

  return {
    generations,
    startGeneration: startGenerationWithPersona,
    trackQueueCompletion
  };
};
