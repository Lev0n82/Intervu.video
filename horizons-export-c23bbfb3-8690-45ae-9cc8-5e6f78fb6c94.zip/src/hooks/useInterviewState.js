
import { useState, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useInterviewState = (interviewData, submissionId) => {
    const [currentState, setCurrentState] = useState('introduction'); // 'introduction', 'questions', 'review', 'completed'
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState({}); // { questionId: { videoUrl, duration, ... } }
    const [introductionWatched, setIntroductionWatched] = useState(false);
    const [videoPlayCounts, setVideoPlayCounts] = useState({}); // { questionId_type: count }
    const [clarificationCounts, setClarificationCounts] = useState({}); // { questionId: count }
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Derived state
    const questions = interviewData?.interviews?.interview_templates?.template_questions || [];
    const currentQuestion = questions[currentQuestionIndex];
    const totalQuestions = questions.length;

    const markIntroductionWatched = useCallback(async () => {
        setIntroductionWatched(true);
        // Optimistically update DB
        if (submissionId) {
             await supabase
                .from('interview_submissions')
                .update({ introduction_watched_at: new Date().toISOString() })
                .eq('id', submissionId);
        }
    }, [submissionId]);

    const trackVideoPlay = useCallback((id, type) => {
        const key = `${id}_${type}`;
        setVideoPlayCounts(prev => ({
            ...prev,
            [key]: (prev[key] || 0) + 1
        }));
    }, []);

    const trackClarificationUsage = useCallback((questionId) => {
        setClarificationCounts(prev => ({
            ...prev,
            [questionId]: (prev[questionId] || 0) + 1
        }));
    }, []);

    const submitAnswer = useCallback((questionId, answerData) => {
        setAnswers(prev => ({
            ...prev,
            [questionId]: {
                ...answerData,
                timestamp: new Date().toISOString(),
                clarification_count: clarificationCounts[questionId] || 0
            }
        }));
    }, [clarificationCounts]);

    const moveToNextQuestion = useCallback(() => {
        if (currentQuestionIndex < totalQuestions - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
        } else {
            setCurrentState('review');
        }
    }, [currentQuestionIndex, totalQuestions]);

    const startQuestions = useCallback(() => {
        if (introductionWatched) {
            setCurrentState('questions');
        }
    }, [introductionWatched]);

    const completeInterview = useCallback(async (token) => {
        setIsSubmitting(true);
        try {
            // Transform answers object to array for storage if needed, or keep as JSONB object
            // Currently storing as the raw answers object
            
            const { data, error } = await supabase.rpc('save_interview_submission', {
                p_submission_token: token,
                p_responses: answers,
                p_status: 'completed'
            });

            if (error) throw error;
            if (!data.success) throw new Error(data.message);
            
            setCurrentState('completed');
            return { success: true };
        } catch (error) {
            console.error("Submission error:", error);
            return { success: false, error: error.message };
        } finally {
            setIsSubmitting(false);
        }
    }, [answers]);

    return {
        currentState,
        currentQuestionIndex,
        currentQuestion,
        totalQuestions,
        answers,
        introductionWatched,
        videoPlayCounts,
        clarificationCounts,
        isSubmitting,
        actions: {
            markIntroductionWatched,
            startQuestions,
            trackVideoPlay,
            trackClarificationUsage,
            submitAnswer,
            moveToNextQuestion,
            completeInterview,
            setCurrentState // Exposed for navigating back from review if needed
        }
    };
};
