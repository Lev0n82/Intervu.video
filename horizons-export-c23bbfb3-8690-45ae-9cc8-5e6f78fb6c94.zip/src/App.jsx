
import React, { useEffect, Suspense } from 'react';
import { BrowserRouter as Router, useNavigate, useLocation, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { DemoProvider } from '@/contexts/DemoContext';
import AppRoutes from '@/routing/AppRoutes';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from './components/ui/toaster';
import { useToast } from './components/ui/use-toast';
import Preloader from './components/Preloader';
import { I18nextProvider } from 'react-i18next';
import i18n from './i18n';

// Component to handle OAuth redirects and URL hash processing
const UrlHandler = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { session, loading, userProfile } = useAuth();

  useEffect(() => {
    // We only want to run this logic if we are NOT loading
    if (loading) return;

    // Extract hash parameters (used by Supabase for OAuth/Magic Links)
    const hashParams = new URLSearchParams(location.hash.substring(1)); 

    // 1. Handle Authentication Errors
    if (hashParams.has('error') || hashParams.has('error_code')) {
      const errorCode = hashParams.get('error_code');
      const errorDescription = hashParams.get('error_description');
      
      console.error("UrlHandler: Auth error detected in URL:", errorCode, errorDescription);

      let title = 'Authentication Error';
      let description = errorDescription ? errorDescription.replace(/\+/g, ' ') : 'An unexpected error occurred.';

      if (errorCode === 'otp_expired') {
         title = 'Link Expired';
         description = 'This verification link has expired. Please request a new one.';
      }

      toast({
        variant: 'destructive',
        title: title,
        description: description,
        duration: 6000,
      });

      // Clear the error from URL so the user doesn't see it forever
      navigate(location.pathname, { replace: true });
      return;
    }

    // 2. Handle Successful OAuth/Link Redirects
    if (hashParams.has('access_token')) {
       console.log("UrlHandler: Access token detected in URL");
       // Note: Supabase client automatically handles the token. 
       // We monitor 'session' and 'userProfile' in AppContent for the actual redirect.
    }
  }, [location, navigate, toast, session, loading, userProfile]);

  return null;
};

// Wrapper component to use hooks inside Router context
const AppContent = () => {
  const { session, loading, userProfile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Global Redirect Logic for Authenticated Users
  useEffect(() => {
    if (!loading && session && userProfile) {
      const currentPath = location.pathname;
      const isAuthPage = currentPath === '/auth' || currentPath === '/' || currentPath === '/forgot-password';
      
      if (isAuthPage) {
        console.log("AppContent: Authenticated user on public page, redirecting...");
        const destination = userProfile.user_type === 'Candidate' ? '/candidate-home' : '/dashboard';
        navigate(destination, { replace: true });
      }
    }
  }, [session, loading, userProfile, navigate, location.pathname]);
  
  const handlePreloaderTimeout = () => {
      console.warn("AppContent: Preloader timed out. Auth state might be stuck.");
  };

  if (loading) {
    return <Preloader onTimeout={handlePreloaderTimeout} />;
  }

  return (
    <>
      <UrlHandler />
      <div className="aurora-background"></div>
      <div className="relative z-0">
        <AppRoutes />
      </div>
      <Toaster />
    </>
  );
}

function App() {
  return (
    <HelmetProvider>
      <I18nextProvider i18n={i18n}>
        <Router>
          <ThemeProvider defaultTheme="dark" storageKey="intervu-ui-theme">
            <AuthProvider>
              <DemoProvider>
                <Suspense fallback={<Preloader />}>
                  <AppContent />
                </Suspense>
              </DemoProvider>
            </AuthProvider>
          </ThemeProvider>
        </Router>
      </I18nextProvider>
    </HelmetProvider>
  );
}

export default App;
